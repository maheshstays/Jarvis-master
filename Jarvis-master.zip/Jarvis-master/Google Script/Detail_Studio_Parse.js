//Detail view of studios and projects
function generateStudioDetail(uid)
{  
  //Search Params
  var maxStudios = 200;
  var maxProjects = 10;
  
  var conn = fetchConnection();
  
  //Testing
  if (uid == undefined)
    uid = 1; 
  
  //Create SQL statement
  var stmt = conn.createStatement();
  var pc_stmt = conn.createStatement();
  var bank_stmt = conn.createStatement();
  var std_exp_stmt = conn.createStatement();
  stmt.setMaxRows(maxStudios);
  
  //SQL Query
  var results = stmt.executeQuery('SELECT * FROM studio WHERE uid=' + qstr(uid));
  
  //Base HTML table
  var html = '<table id="main-data-table" class="main-table-blank"><tr><td>';
  
  html += HtmlService.createTemplateFromFile("detail_Studio").evaluate().getContent();

  var platforms_stmt = conn.createStatement();
  var platforms_rslt = platforms_stmt.executeQuery('SELECT * FROM platform');
  var platforms = {};
  while(platforms_rslt.next())
  {
    var platform = {};
    platform.uid = platforms_rslt.getString("uid");
    platform.name = platforms_rslt.getString("name");
    platform.logo_url = platforms_rslt.getString("logo_url");
    platforms[platform.uid] = platform;
  }

  while (results.next()) 
  {
    var uid = results.getString('uid');
    var logo_url = results.getString('logo_url');
    var name = results.getString('name');
    var address = results.getString('address_first');
    var city = results.getString('address_city');
    var state = results.getString('address_state');
    var zipcode = results.getString('address_zipcode');
    var country = results.getString('address_country');
    var thread_id = results.getInt('thread_id');
    
    var contact_name = '';
    var contact_email = '';
    
    html = html.replace('#game_css', generateStudioImageCSS(uid, logo_url));
    html = html.replace('#studio_id', uid);
    html = html.replace('#studio_name', name);
    html = html.replace('#studio_address', address);
    html = html.replace('#studio_city', city);
    html = html.replace('#studio_state', state);
    html = html.replace('#studio_country', country);
    html = html.replace('#studio_zipcode', zipcode);
    html = html.replace('#studio_comment_thread', generateCommentPopupHtml(thread_id, "studio", uid));
    
    var contacts = getContacts("studio", uid);
    for(var i = 0; i < contacts.length; i++)
    {
      contact_name = contacts[i].name;
      contact_email = contacts[i].email;
      
      html = html.replace('#primary_contact_name', contact_name);
      html = html.replace('#primary_contact_email', contact_email);
    }
    
    //Bank information
    var bank_results = bank_stmt.executeQuery('SELECT * FROM bank WHERE uid =' + qstr(uid));
    while (bank_results.next()) 
    {
      var b_name = bank_results.getString('name');
      var b_routing = bank_results.getString('routing_number');
      var b_account = bank_results.getString('account_number');
      var b_address = bank_results.getString('address_first');
      var b_city = bank_results.getString('address_city');
      var b_state = bank_results.getString('address_state');
      var b_zipcode = bank_results.getString('address_zipcode');
      var b_country = bank_results.getString('address_country');
    
      var b_sort = bank_results.getString('sort_code');
      var b_beneficiary = bank_results.getString('beneficiary');
      var b_swift = bank_results.getString('swift_code');
      var b_taxid = bank_results.getString('tax_id');
      var b_uid = bank_results.getString('uid');
      var b_viability = bank_results.getString('viability');
      var b_thread_id = bank_results.getInt('thread_id');
      
      html = html.replace('#bank_name', b_name);
      html = html.replace('#bank_address', b_address);
      html = html.replace('#bank_city', b_city);
      html = html.replace('#bank_state', b_state);
      html = html.replace('#bank_country', b_country);
      html = html.replace('#bank_zipcode', b_zipcode);
      html = html.replace('#bank_tax_id', b_taxid);
      html = html.replace('#bank_routing_number', b_routing);
      html = html.replace('#bank_account_number', b_account);
      html = html.replace('#bank_beneficiary', b_beneficiary);
      html = html.replace('#bank_sort_code', b_sort);
      html = html.replace('#bank_swift_code', b_swift);
      html = html.replace('#financial_viability', b_viability);
      html = html.replace('#bank_comment_thread', generateCommentPopupHtml(b_thread_id, "bank", b_uid));
    } 

    //Studio experience  
    var std_exp_results = std_exp_stmt.executeQuery('SELECT * FROM studio_experience WHERE studio_uid =' + qstr(uid));
    while(std_exp_results.next())
    {
      var e_uid = std_exp_results.getInt("studio_uid");
      var exp_thread_id = std_exp_results.getInt("thread_id");

      var e_game_name = std_exp_results.getString("success_game_name");
      var e_platform_id = std_exp_results.getInt("success_game_platform");
      var e_game_url = std_exp_results.getString("success_game_url");
      var e_game_rating = std_exp_results.getInt("success_game_rating");
      var e_games_launched = std_exp_results.getInt("games_launched");
      var e_has_f2p_exp = std_exp_results.getBoolean("has_f2p_exp");
      var e_has_live_ops_exp = std_exp_results.getBoolean("has_live_ops_exp");

      var platform = null;
      if(e_platform_id > 0)
        platform = platforms[e_platform_id];

      html = html.replace("#studio_experience_section", generateStudioExperience(e_game_name, platform, e_game_url, e_game_rating, e_games_launched, e_has_f2p_exp, e_has_live_ops_exp));
      html = html.replace('#studio_experience_comment_thread', generateCommentPopupHtml(exp_thread_id, "studio_experience", e_uid));
    }
    

    //SQL Project Query
    var proj_stmt = conn.createStatement();
    proj_stmt.setMaxRows(maxProjects);
    var proj_results = proj_stmt.executeQuery('SELECT title, logo_url, studio, location, status, phase, tier, uid FROM project WHERE studio=' + qstr(uid)); 
    var newhtml = ''; 
    //Add all projects
    while (proj_results.next()) 
    {
      var p_uid = proj_results.getInt('uid');
      var title = proj_results.getString('title');
      var logo = proj_results.getString('logo_url');
      var location = proj_results.getString('location');
      var status = proj_results.getString('status');
      var phase = proj_results.getString('phase');
      var tier = proj_results.getString('tier');
      var is_last = proj_results.isLast();

      var producerName = "";
      var producers = getContacts("project", p_uid, "Nutaku Producer");
      if(producers.length > 0)
        producerName = producers[0].name;
      
      //Add new studio row
      newhtml += parseProjectRow(p_uid, title, logo, producerName, location, status, phase, tier, is_last);
    }  
    
    html = html.replace('#project-rows', newhtml);
    
    //End project row
    //html += "</td></tr>";
  }
  
  //Close HTML table
  html += '</td></tr></table>';
    
  //Close connections
  results.close();
  stmt.close();
  
  return html;
}

function generateStudioExperience(e_game_name, platform, e_game_url, e_game_rating, e_games_launched, e_has_f2p_exp, e_has_live_ops_exp)
{
  var html = 
  "<div id='se_platform_container' class='sd_p2_body_colum'>" +
    "<div class='sd_p2_body_row'>" +
      "<img id='se_title_platform' data-uid='" + platform.uid + "' class='sd_p2_platform_icon' src='" + platform.logo_url + "'>" +
      "<div class='sd_p2_platform_title'>" +
        platform.name +
      "</div>" +
    "</div>" +
  "</div>" +

  "<div class='sd_p2_body_colum'>" +
    "<div class='sd_p2_body_row'>" +
      "<div class='sd_p2_body_title'>" +
        "Previous Game Refference" +
      "</div>" +
      "<div id='se_success_game_name' class='sd_p2_body_text'>" +
        e_game_name +
      "</div>" +
      "<div class='sd_p2_body_link'>" +
        "<a id='se_success_game_url' href='" + e_game_url + "' target'_blank'>" + e_game_url + "</a>" +
      "</div>" +
      "<div class='sd_p2_body_text'>" +
        generateStarsControl("se_success_game_rating", 10, e_game_rating, false) +
      "</div>" +
    "</div>" +
  "</div>" +

  "<div class='sd_p2_body_colum'>" +
    "<div class='sd_p2_body_row'>" +
      "<div class='sd_p2_body_title'>" +
        "Games Launched" +
      "</div>" +
      "<div id='se_titles_count' class='sd_p2_body_text'>" +
        e_games_launched +
      "</div>" +
    "</div>" +
  "</div>" +

  "<div class='sd_p2_body_colum'>" +
    "<div class='sd_p2_body_row'>" +
      "<div class='sd_p2_body_title'>" +
        "Experience with F2P" +
      "</div>" +
      "<div id='se_has_f2p_exp' class='sd_p2_body_text'>" +
        ((e_has_f2p_exp) ? "Yes" : "No") +
      "</div>" +
    "</div>" +
  "</div>" +

  "<div class='sd_p2_body_colum'>" +
    "<div class='sd_p2_body_row'>" +
      "<div class='sd_p2_body_title'>" +
        "Experience with live-ops" +
      "</div>" +
      "<div id='se_has_live_opt_exp' class='sd_p2_body_text'>" +
        ((e_has_live_ops_exp) ? "Yes" : "No") +
      "</div>" +
    "</div>" +
  "</div>";

  return html;
}

function generateStudioExperiencePopup()
{
  var conn = fetchConnection();
  var platforms_stmt = conn.createStatement();
  var platforms_rslt = platforms_stmt.executeQuery('SELECT * FROM platform');
  var platforms = {};
  while(platforms_rslt.next())
  {
    var platform = {};
    platform.uid = platforms_rslt.getString("uid");
    platform.name = platforms_rslt.getString("name");
    platform.logo_url = platforms_rslt.getString("logo_url");
    platforms[platform.uid] = platform;
  }

  var html =
  "<div id='dialog-edit-studio-experience' data-uid=''>" +
    "<form id='edit-studio-experience'>" +
      "<fieldset>" +
        "<div>" +
          "<label for='sep_title_name' class='text-field-label'>Title Name</label>" +
          "<input id='sep_title_name' name='title_name' type='text' class='ui-text' placeholder='Title Name'>" +
          
          "<label for='sep_title_platform' class='text-field-label'>Platform</label>" +
          "<select id='sep_title_platform' class='ui-selectmenu' name='platform'>" +
            "<option disabled selected value='0'>Select One</option>";
  Object.keys(platforms).forEach(function(key)
  {
    html += "<option value='" + platforms[key].uid + "'>" + platforms[key].name + "</option>";
  });

  html +=
          "</select>" +
          
          "<label for='sep_title_url' class='text-field-label'>URL</label>" +
          "<input id='sep_title_url' name='title_url' type='text' class='ui-text' placeholder='http://'>" +
          "<label for='sep_title_url' class='text-field-label'>Rating</label>" +
          generateStarsControl("sep_success_game_rating", 10, -1, true) +
        "</div>" +
        "<div>" +
          "<label class='text-field-label'>Number of Games Launched</label>" +
          "<input id='sep_titles_count' name='titles_launched' type='number' class='ui-text' placeholder='0'>" +
        "</div>" +
        "<div class='sep_toggles_container'>" +
          "<div>" +
            "<label class='text-field-label'>Experience With F2P?</label>" +
            "<div class='ui-toggle'>" +
              "<input type='radio' class='ui-toggle-input' name='f2p_exp' value='yes' id='f2p_exp_yes' checked='checked'>" +
              "<label for='f2p_exp_yes' class='ui-toggle-label ui-toggle-label-on'>Yes</label>" +
              "<input type='radio' class='ui-toggle-input' name='f2p_exp' value='no' id='f2p_exp_no'>" +
              "<label for='f2p_exp_no' class='ui-toggle-label ui-toggle-label-off'>No</label>" +
              "<span class='ui-toggle-selection'></span>" +
            "</div>" +
          "</div>" +
          "<div>" +
            "<label class='text-field-label'>Experience With Live-Ops?</label>" +
            "<div class='ui-toggle'>" +
              "<input type='radio' class='ui-toggle-input' name='live_ops_exp' value='yes' id='live_ops_exp_yes' checked='checked'>" +
              "<label for='live_ops_exp_yes' class='ui-toggle-label ui-toggle-label-on'>Yes</label>" +
              "<input type='radio' class='ui-toggle-input' name='live_ops_exp' value='no' id='live_ops_exp_no'>" +
              "<label for='live_ops_exp_no' class='ui-toggle-label ui-toggle-label-off'>No</label>" +
              "<span class='ui-toggle-selection'></span>" +
            "</div>" +
          "</div>" +
        "</div>" +
      "</fieldset>" +
    "</form>" +
  "</div>";

  return html;
}