//Utility object to handle properties in general
var _properties_handler = {
    properties: null,

    getProperty: function(key)
    {
        if(this.properties == null)
        this.properties = PropertiesService.getUserProperties();
        
        var property = this.properties.getProperty(key);
        if(property == null)
            Logger.log("Property with key '" + key + "' doesn't exist. Did you forget to generate it?.");
        return (property);
    },

    getPropertyObj: function(key)
    {
        return JSON.parse(this.getProperty(key));
    },

    setProperty: function(key, value)
    {
        if(this.properties == null)
        this.properties = PropertiesService.getUserProperties();

        var stringValue = (typeof value === 'string' || value instanceof String) ? value : JSON.stringify(value);
        this.properties.setProperty(key, stringValue);
    }
};