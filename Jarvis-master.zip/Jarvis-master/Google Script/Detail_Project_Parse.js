//Detail view of studios and projects
function generateProjectDetail(uid)
{  
  //Search Params
  var maxStudios = 200;
  var maxProjects = 10;
  
  var conn = fetchConnection();
  
  //Testing
  if (uid == undefined)
    uid = 1; 
  
  //Create SQL statement
  var project_stmt = conn.createStatement();
  project_stmt.setMaxRows(1);
  var studio_stmt = conn.createStatement();
  studio_stmt.setMaxRows(1);
  var pc_stmt = conn.createStatement();
  var milestone_stmt = conn.createStatement();
  var contract_stmt = conn.createStatement();

  
  //SQL Query
  var proj_results = project_stmt.executeQuery('SELECT * FROM project WHERE uid=' + qstr(uid));
  var milestone_results = milestone_stmt.executeQuery('SELECT * FROM milestone WHERE project=' + qstr(uid));
  
  //Base HTML table
  var html = '<table id="main-data-table" class="main-table-blank"><tr><td>';
  
  html += HtmlService.createTemplateFromFile("detail_Game").evaluate().getContent();
  
  while (proj_results.next()) 
  {
    var uid = proj_results.getInt('uid');
    var studio_uid = proj_results.getString('studio');
    var title = proj_results.getString('title');
    var genre = proj_results.getString('genres');
    var logo_url = proj_results.getString('logo_url');
    
    var platforms = proj_results.getString('platform_types');
    var languages = proj_results.getString('languages');
    var location = proj_results.getString('location');
    
    var status = proj_results.getString('status');
    var phase = proj_results.getString('phase');
    var tier = proj_results.getString('tier');
    
    var drive = proj_results.getString('drive_url');
    var jira = proj_results.getString('jira_url');
    var build = proj_results.getString('build_url');
    var playfab = proj_results.getString('playfab_url');
    var discord = proj_results.getString('discord_url');
    var play = proj_results.getString('play_url');
    var kpis = proj_results.getString('kpis_url');

    var game_information_thread_id = proj_results.getInt('game_information_thread_id');
    var previous_performance_thread_id = proj_results.getInt('previous_performance_thread_id');
    var technical_information_thread_id = proj_results.getInt('technical_information_thread_id');
    var milestones_thread_id = proj_results.getInt('milestones_thread_id');
    var gate1_thread_id = proj_results.getInt('gate1_thread_id');

    var recoupPeriod = proj_results.getInt('recoup_period');
    var gameClosureDate = proj_results.getString('game_closure_date');
    
    //Tracking variables
    var totalInvestment = 0;
    var recoupableBalance = 0;
    
    html = html.replace('#studio_id', studio_uid);
    html = html.replace('#game_id', uid);
    html = html.replace('#game_title', title);
    html = html.replace('#tier', tier);
    html = html.replace('#phase', phase);
    html = html.replace('#game_logo', logo_url);
    html = html.replace('#game_logo', logo_url);
    html = html.replace("#drive-url", drive);
    html = html.replace("#jira-url", jira);
    html = html.replace("#build-url", build);
    
    html = html.replace("#drive-link", generateProjectPanelLink("drive_url_link", "link_drive", drive, "Project Drive", "https://nutaku-jarvis.s3.us-east-2.amazonaws.com/images/sd_icon_drive.png", false));
    html = html.replace("#jira-link", generateProjectPanelLink("jira_url_link", "link_jira", jira, "Jira Project", "https://nutaku-jarvis.s3.us-east-2.amazonaws.com/images/sd_icon_jira.png", true));
    html = html.replace("#build-link", generateProjectPanelLink("build_url_link", "link_build", build, "Game Build", "https://nutaku-jarvis.s3.us-east-2.amazonaws.com/images/sd_icon_build.png", true));
    html = html.replace("#playfab-link", generateProjectPanelLink("playfab_url_link", "link_playfab", playfab, "Playfab", "https://nutaku-jarvis.s3.us-east-2.amazonaws.com/images/sd_icon_playfab.png", false));
    html = html.replace("#discord-link", generateProjectPanelLink("discord_url_link", "link_discord", discord, "Discord", "https://nutaku-jarvis.s3.us-east-2.amazonaws.com/images/sd_icon_discord.png", true));
    
    html = html.replace("#game_information_section", generateGameInformation(uid));
    html = html.replace("#previous_performance_section", generatePreviousPerformance(uid));
    html = html.replace("#technical_information_section", generateTechnicalInformation(uid));
    html = html.replace("#legal_information_section", generateLegalInformation(uid));

    html = html.replace('#game_information_comment_thread', generateCommentPopupHtml(game_information_thread_id, "game_information", uid));
    html = html.replace('#previous_performance_comment_thread', generateCommentPopupHtml(previous_performance_thread_id, "previous_performance", uid));
    html = html.replace('#technical_information_comment_thread', generateCommentPopupHtml(technical_information_thread_id, "technical_information", uid));
    html = html.replace('#milestones_comment_thread', generateCommentPopupHtml(milestones_thread_id, "milestones", uid));
    html = html.replace('#gate1_comment_thread', generateCommentPopupHtml(gate1_thread_id, "gate1", uid));
    html = html.replace("#project_uid", uid);

    html = html.replace('#recoupperiod', recoupPeriod);
    html = html.replace('#gameclosuredate', gameClosureDate == "1970-01-01" ? "None" : gameClosureDate);
    
    var legal_stmt = conn.createStatement();
    var legal_results = legal_stmt.executeQuery('SELECT thread_id FROM legal_information WHERE project_uid=' + uid);
    while(legal_results.next())
    {
      html = html.replace('#legal_information_comment_thread', generateCommentPopupHtml(legal_results.getInt("thread_id"), "legal_information", uid));
    }

    //Studio SQL qeury 
    var studio_results = studio_stmt.executeQuery('SELECT * FROM studio WHERE uid=' + qstr(studio_uid));
    
    while (studio_results.next())
    {
      var s_uid = studio_results.getString('uid');
      var studio_logo_url = studio_results.getString('logo_url');
      var name = studio_results.getString('name');
      var address = studio_results.getString('address_first');
      var city = studio_results.getString('address_city');
      var state = studio_results.getString('address_state');
      var zipcode = studio_results.getString('address_zipcode');
      var country = studio_results.getString('address_country');
    
      var contact_name = '';
      var contact_email = '';
    
      html = html.replace('#studio_css', generateStudioImageCSS(studio_uid, studio_logo_url));
      html = html.replace('#game_css', generateGameImageCSS(uid, logo_url));
      html = html.replace('#studio_name', name);
      html = html.replace('#studio-id', s_uid);
      html = html.replace('#studio_address', address);
      html = html.replace('#studio_city', city);
      html = html.replace('#studio_state', state);
      html = html.replace('#studio_country', country);
      html = html.replace('#studio_zipcode', zipcode);
      
      var contacts = getContacts("studio", s_uid);
      for(var i = 0; i < contacts.length; i++)
      {
        contact_name = contacts[i].name;
        contact_email = contacts[i].email;
        
        html = html.replace('#primary_contact_name', contact_name);
        html = html.replace('#primary_contact_email', contact_email);
      }
      
      //Create new row for studio table
      //html += "<tr><td>";
    
      //Add new studio row
      //html += parseStudioDetailRow(name, address, city, state, zipcode, country, contact_name, contact_email, s_uid); 
    
      //End studio row
      //html += "</td></tr>"; 
    }
       
    //Milestone SQL query
    var ms_html = '';
    var investment = 0;
    var recoupable = 0;
    
    while (milestone_results.next())
    {  
     var ms_uid = milestone_results.getString('uid');
     var ms_new_html = HtmlService.createTemplateFromFile("milestones_table").evaluate().getContent();
     var cost = parseInt(milestone_results.getString('payment_amount'));
      
     investment += cost;
      
     if (milestone_results.getString('paid') == 'Paid')
      recoupable += cost;
      
     ms_new_html = ms_new_html.replace('#name', milestone_results.getString('name'));
     ms_new_html = ms_new_html.replace('#due_date', milestone_results.getString('due_date'));
     ms_new_html = ms_new_html.replace('#approval_date', milestone_results.getString('approval_date'));
     ms_new_html = ms_new_html.replace('#payment_amount', intToCurrencyString(cost));
     ms_new_html = ms_new_html.replace('#paid_status', milestone_results.getString('paid'));
     ms_new_html = ms_new_html.replace('#milestone_uid', milestone_results.getString('uid'));
     ms_new_html = ms_new_html.replace('#milestone_uid', milestone_results.getString('uid'));
     ms_new_html = ms_new_html.replace('#milestone_uid', milestone_results.getString('uid'));
     ms_new_html = ms_new_html.replace('#muid', milestone_results.getString('uid'));
     ms_new_html = ms_new_html.replace('#muid', milestone_results.getString('uid'));
     ms_new_html = ms_new_html.replace('#muid', milestone_results.getString('uid'));
     ms_new_html = ms_new_html.replace('#muid', milestone_results.getString('uid'));
     ms_new_html = ms_new_html.replace('#muid', milestone_results.getString('uid'));
      
      
     var approval_stmt = conn.createStatement();
     var approval_results = approval_stmt.executeQuery('SELECT * FROM approval WHERE milestone=' + qstr(ms_uid));
     var deliverable_stmt = conn.createStatement();
     var deliverable_results = deliverable_stmt.executeQuery('SELECT * FROM deliverable WHERE milestone=' + qstr(ms_uid));
      
     //Deliverables 
     var ms_d_html = '';
     
     var ms_d_stmt = conn.createStatement();
     var ms_d_results = ms_d_stmt.executeQuery('SELECT * FROM deliverable WHERE milestone =' + qstr(ms_uid));
      
     while (ms_d_results.next())
     {
       ms_d_html += HtmlService.createTemplateFromFile("milestones_deliverable_row").evaluate().getContent();
       
       ms_d_html = ms_d_html.replace('#name', ms_d_results.getString('name'));
       ms_d_html = ms_d_html.replace('#status', ms_d_results.getString('complete'));
       ms_d_html = ms_d_html.replace('#uid', ms_d_results.getString('uid'));
       ms_d_html = ms_d_html.replace('#uid', ms_d_results.getString('uid'));
       ms_d_html = ms_d_html.replace('#uid', ms_d_results.getString('uid'));
       ms_d_html = ms_d_html.replace('#uid', ms_d_results.getString('uid'));
       
       //Set comment
       var comment = ms_d_results.getString('comment');
       
       if (comment == null)
       {
         comment = '';
       }
       
       ms_d_html = ms_d_html.replace('#comment', comment);
       
       //Set light
       var light_class = ms_d_results.getBoolean('Complete') ? 'ms_go_light_fill' : 'ms_light_fill';
       
       ms_d_html = ms_d_html.replace('#light_class', light_class);
     }
      
     //Approvals 
     var ms_a_html = '';
     
     var ms_a_stmt = conn.createStatement();
     var ms_a_results = ms_a_stmt.executeQuery('SELECT * FROM approval WHERE milestone =' + qstr(ms_uid));
      
     while (ms_a_results.next())
     {
       ms_a_html += HtmlService.createTemplateFromFile("milestones_approval_row").evaluate().getContent();
       
       ms_a_html = ms_a_html.replace('#name', ms_a_results.getString('name'));
       ms_a_html = ms_a_html.replace('#title', ms_a_results.getString('title'));
       ms_a_html = ms_a_html.replace('#status', ms_a_results.getString('complete'));
       ms_a_html = ms_a_html.replace('#uid', ms_a_results.getString('uid'));
       ms_a_html = ms_a_html.replace('#uid', ms_a_results.getString('uid'));
       ms_a_html = ms_a_html.replace('#uid', ms_a_results.getString('uid'));
       ms_a_html = ms_a_html.replace('#uid', ms_a_results.getString('uid'));
       ms_a_html = ms_a_html.replace('#uid', ms_a_results.getString('uid'));
       
       //Set comment
       var comment = ms_a_results.getString('comment');
       
       if (comment == null)
       {
         comment = '';
       }
       
       ms_a_html = ms_a_html.replace('#comment', comment);
       
       //Set light
       var light_text = ms_a_results.getString('complete');
       var light_image = 'https://nutaku-jarvis.s3.us-east-2.amazonaws.com/images/ms-icon-default.png';
       
       switch (light_text)
       {
         case 'Approved':
           light_image = 'https://nutaku-jarvis.s3.us-east-2.amazonaws.com/images/ms-icon-approved.png';
           break;
           
         case 'Hold':
           light_image = 'https://nutaku-jarvis.s3.us-east-2.amazonaws.com/images/ms-icon-nil.png';
           break;
           
         case 'Declined':
           light_image = 'https://nutaku-jarvis.s3.us-east-2.amazonaws.com/images/ms-icon-fail.png';
           break;
       }
       
       ms_a_html = ms_a_html.replace('#light_image', light_image);
     } 
       
     //Update HTML
     ms_new_html = ms_new_html.replace('#deliverables', ms_d_html);
     ms_new_html = ms_new_html.replace('#approvals', ms_a_html);
     ms_html += ms_new_html;
    }
    
    html = html.replace('#milestones', ms_html);
    html = html.replace("#gate1_section", generateGateHtml(1, uid));
    html = html.replace('#investment', intToCurrencyString(investment));
    html = html.replace('#recoupable', intToCurrencyString(recoupable));
    
    //Contract SQL qeury 
    var contract_results = contract_stmt.executeQuery('SELECT * FROM contract WHERE uid=' + qstr(uid));
    
    while (contract_results.next())
    {
      var rev_share = contract_results.getString('rev_share');
      var advance = contract_results.getInt('advance');
    
      if(rev_share == null || rev_share == "" || rev_share == "0")
        rev_share = "0/0/0";
      html = html.replace('#revenue', rev_share);
      html = html.replace('#advance', intToCurrencyString(advance));
      
    }
    
    //Start game information row
    //html += "<tr><td>";
    
    //html += parseGameInformation(uid, title, genre, '', '', location, '', '', '', status, phase, tier, platforms, languages, drive, jira, playfab, discord, play, kpis);
    
    //End game information row
    //html += "</td></tr>";
    
    //Start milestone row
    //html += "<tr><td>";
    
    //html += parseMilestoneTable(uid);
    
    //End milestone row
    //html += "</td></tr>";
  }
  
  //Close HTML table
  html += '</td></tr></table>';
  
  //Close connections
  proj_results.close();
  studio_results.close();
  project_stmt.close();
  studio_stmt.close();
  
  return html;
}

function generateProjectPanelLink(aId, divId, aUrl, text, icon_url, add_margin)
{
  var hasLink = aUrl != null && aUrl != "" && aUrl != "http://";

  var bgClass = (hasLink) ? 'sd_link_icon_background' : 'sd_link_icon_inactive_background';
  var html = "";
  if(hasLink)
    html += '<a id="' + aId + '" href="' + aUrl + '" target="_blank">';

  html += '<div id="' + divId + '" class="sd_link_cell"';
  
  if(add_margin)
    html += 'style="margin-top: 30px"'

  html += '>' +
            '<div class="' + bgClass + '">' +
              '<img class="sd_link_icon" src="' + icon_url + '">' +
            '</div>' +
            '<div class="sd_link_text">' +
              text +
            '</div>' +
          '</div>';
  
  if(hasLink)
    html += '</a>';

  return html;
}

function ddp()
{
  generateGameInformation(1);
}

function generateGameInformation(uid)
{
  var contacts = getRoles("project", uid);
  var all_contacts = getContacts();

  var html = 
    "<script>" +
      "var CONTACTS = " + JSON.stringify(all_contacts) + ";" + //Let's insert all the contacts data to make it available on frontend
      "var CONTACTS_RAW = " + JSON.stringify(getRawContacts()) + ";" + //Let's insert all the contacts data to make it available on frontend
      "var ROLES = " + JSON.stringify(getRoles()) + ";" + //Insert all roles available to make them available on frontend
    "</script>" +
    "<table class='sd_p_table'>" +
      "<tr>" +
        "<td width='370' align='left' valign='top'>" +
          //Some while space I don't know the purpose of
        "</td>" +
        "<td align='center' valign='top'>" +
          "<div class='sd_p_tabular_row'>" +
            "<div class='sd_p_cell'>" +
              "<div class='sd_gt_title'>" +
                "Title" +
              "</div>" +
            "</div>" +
            "<div class='sd_p_cell'>" +
              "<div class='sd_gt_title'>" +
                "Name" +
              "</div>" +
            "</div>" +
            "<div class='sd_p_cell'>" +
              "<div class='sd_gt_title'>" +
                "Skype" +
              "</div>" +
            "</div>" +
          "</div>";

  for(var i = 0; i < contacts.length; i++)
  {
    var curContact = contacts[i];
    html +=
          "<div class='gi_contact'>" +
            "<div class='sd_p_tabular_row'>" +
              "<div class='sd_p_cell'>" +
                "<div class='sd_p_item_title'>" +
                  curContact.roleName +
                "</div>" +
              "</div>" +
              "<div class='sd_p_cell'>" +
                "<div class='sd_p_item_name'>" +
                  "<a href='mailto:" + curContact.email + "'>" + curContact.displayName + "</a>" +
                "</div>" +
              "</div>" +
              "<div class='sd_p_cell'>" +
                "<div class='sd_p_item_skype'>" +
                  "<img src='https://nutaku-jarvis.s3.us-east-2.amazonaws.com/images/skype_icon.png'>" +
                  curContact.skypeId +
                "</div>" +
              "</div>" +
            "</div>" +
          "</div>";
  }

  html +=
        "</td>" +
      "</tr>" +
    "</table>" +
  "</div>";

  return html;
}

function generatePreviousPerformance(uid) 
{
  var conn = fetchConnection();
  var previous_project_stmt = conn.createStatement();
  previous_project_stmt.setMaxRows(1);
  var ppp_stmt = conn.createStatement();
  var platforms_stmt = conn.createStatement();
  var notable_titles_stmt = conn.createStatement();
  var previous_project_rslt = previous_project_stmt.executeQuery('SELECT * FROM previous_project WHERE project_id=' + qstr(uid));
  var ppp_rslt = ppp_stmt.executeQuery('SELECT * FROM previous_project_platforms WHERE project_id=' + qstr(uid));
  var notable_titles_stmt = notable_titles_stmt.executeQuery('SELECT * FROM previous_project_notable_titles WHERE project_id=' + qstr(uid));
  var platforms_rslt = platforms_stmt.executeQuery('SELECT * FROM platform');

  var platforms = {};
  while(platforms_rslt.next())
  {
    var platform = {};
    platform.uid = platforms_rslt.getString("uid");
    platform.name = platforms_rslt.getString("name");
    platform.logo_url = platforms_rslt.getString("logo_url");
    platforms[platform.uid] = platform;
  }

  var html = "";
  while(previous_project_rslt.next())
  {
    var reference_url = previous_project_rslt.getString("reference_url");
    var trailer_url = previous_project_rslt.getString("trailer_url");
    
    html +=
    // Col 1
    "<div class='pr_p2_body_colum'>" +
      "<div class='sd_p2_body_row'>" +
        "<div class='sd_p2_body_title'>" +
          "Previous Game Refference" +
        "</div>" +
        "<div class='sd_p2_body_link'>" +
          "<a id='inf_gp_reference' href='" + reference_url + "' target='_blank'>" + reference_url + "</a>" +
        "</div>" +
      "</div>" +
      "<div class='sd_p2_body_row'>" +
        "<div class='sd_p2_body_title'>" +
          "Previous Game Trailer" +
        "</div>" +
        "<div class='sd_p2_body_link'>" +
          "<a id='inf_gp_trailer' href='" + trailer_url + "' target='_blank'>" + trailer_url + "</a>" +
        "</div>" +
      "</div>" +
    "</div>";

    html += 
    // Col 2
    "<div class='pr_p2_body_colum'>" +
      "<div class='sd_p2_body_row'>" +
        "<div class='sd_p2_body_title'>" +
          "Built on existing game code" +
        "</div>" +
        "<div class='sd_p2_body_text'>" +
          "<span id='gd_tech_info_built_on_existing_game_code' class='gd_tech_info_text'>" + ((previous_project_rslt.getBoolean("built_on_existing_game_code")) ? "Yes" : "No") + "</span>" +
        "</div>" +
      "</div>" +
      "<div class='sd_p2_body_row'>" +
        "<div class='sd_p2_body_title'>Notable titles</div>";

    var notableTitlesExist = false;
    while(notable_titles_stmt.next()) 
    {
      if(notable_titles_stmt.isFirst()) 
      {
        notableTitlesExist = true;
        html += 
        "<div class='sd_p2_body_text'>" +
            "<nav id='prev_perf_notable_titles_nav'>" +
              "<ul>";
      }

      var url = notable_titles_stmt.getString("url");
      html +=
                "<li>" + url + "</li>";

      if(notable_titles_stmt.isLast()) 
      {
        html += 
              "</ul>" +
            "</nav>" +
        "</div>";
      }
    }

    if(!notableTitlesExist) 
    {
      html += 
        "<div class='sd_p2_body_text'>" +
          "<span class='gd_tech_info_text'>None</span>" +
        "</div>";
    }

    html += 
      "</div>" +
    "</div>";

    while(ppp_rslt.next())
    {
      // Col 3, ... until all previous platforms are displayed
      var platform = platforms[ppp_rslt.getInt("platform_id")];
      html +=
      "<div class='pr_p2_body_colum'>" +
        "<div class='sd_p2_body_row'>" +
          "<img id='' class='sd_p2_platform_icon' src='" + platform.logo_url + "'>" +
          "<div class='sd_p2_platform_title'>" +
            platform.name +
          "</div>" +
          "<div class='sd_p2_body_title'>" +
            "Downloads" +
          "</div>" +
          "<div id='inf_gp_" + platform.name + "_downloads' class='sd_p2_body_text'>" +
            parseToThousandsString(ppp_rslt.getInt("downloads")) + 
          "</div>" +
        "</div>" +
        "<div class='sd_p2_body_row'>" +
          "<div class='sd_p2_body_text'>" +
            generateStarsControl("inf_gp_" + platform.name + "_rating", 10, ppp_rslt.getInt("rating"), false) +
          "</div>" +
        "</div>" +
      "</div>";
    }
  }
  return html;
}

function generatePreviousPerformancePopup()
{
  var conn = fetchConnection();
  var platforms_stmt = conn.createStatement();
  var platforms_rslt = platforms_stmt.executeQuery('SELECT * FROM platform');

  var html = 
  "<div id='dialog-edit-game-performance' data-uid=''>" +
    "<form id='edit-game-performance' data-platforms='#platforms'>" +
      "<fieldset>" +
        "<label class='text-field-label' for='f_gp_title'>Previous Game Title</label>" +
        "<input type='text' name='title' id='f_gp_title' class='ui-text'>" +
        "<label class='text-field-label' for='f_gp_reference'>Previous Game Reference</label>" +
        "<input type='text' name='reference' id='f_gp_reference' class='ui-text'>" +
        "<label class='text-field-label' for='f_gp_trailer'>Previous Game Trailer</label>" +
        "<input type='text' name='trailer' id='f_gp_trailer' class='ui-text'>" +
        "<div class='gp_platforms_container'>";
  
  var platforms = [];
  while(platforms_rslt.next())
  {
    var platform_name = platforms_rslt.getString("name");
    platforms.push(platform_name);
    html += 
          "<div class='gp_platform'>" +
            "<img class='gp_platform_icon' src='" + platforms_rslt.getString("logo_url") + "'>" +
            "<div class='gp_platform_name'>" +
              platform_name +
            "</div>" +
            "<div class='gp_downloads'>" +
              "<label class='text-field-label' for='f_gp_downloads'>Downloads</label>" +
              "<input type='text' name='" + platform_name + "_downloads' id='" + platform_name + "_downloads' class='ui-thousands-input'>" +
            "</div>" +
            generateStarsControl(platform_name + "_rating", 10, 0, true) +
          "</div>";
  }
  html +=
        "</div>";

  html += 
        "<div>" +
          "<label class='text-field-label'>Built on existing game code</label>" +
          "<div class='ui-toggle'>" +
            "<input type='radio' class='ui-toggle-input' name='built_on_existing_game_code' value='yes' id='built-on-existing-game-code_yes'>" +
            "<label for='built-on-existing-game-code_yes' class='ui-toggle-label ui-toggle-label-on'>Yes</label>" +
            "<input type='radio' class='ui-toggle-input' name='built_on_existing_game_code' value='no' id='built-on-existing-game-code_no'>" +
            "<label for='built-on-existing-game-code_no' class='ui-toggle-label ui-toggle-label-off'>No</label>" +
            "<span class='ui-toggle-selection'></span>" +
          "</div>" +
        "</div>";

  html += 
        "<label class='text-field-label' for='f_gp_notabletitles'>Notable titles</label>" +
        "<div id='f_gp_notabletitle_rows' for='f_gp_notabletitle_rows'>" +
          "<input type='text' name='notable_title_1' id='f_gp_notabletitle_firstrow' class='ui-text gp_notable_titles_row'>" +
        "</div>" +
        "<div>" +
          "<button type='button' class='ui-button gp_notable_titles_row_button' id='f_gp_notabletitle_rows_plus' onclick='onNotableTitleRowsBtnClick(true)'>+</button>" +
          "<button type='button' class='ui-button gp_notable_titles_row_button' id='f_gp_notabletitle_rows_minus' onclick='onNotableTitleRowsBtnClick(false)'>-</button>" +
        "</div>";

  html +=
      "</fieldset>" +
    "</form>" +
  "</div>";

  html = html.replace("#platforms", platforms.join(","));
  return html;
}

function generateLegalInformation(uid)
{
  var conn = fetchConnection();
  var stmt = conn.createStatement();
  stmt.setMaxRows(1);
  var rslt = stmt.executeQuery('SELECT is_exclusive, publisher, ip_holder, ntku_pays_free_gold, is_publishing_agreement_signed, publishing_contract_date, is_ntku_dot_net_agreement_signed, ntku_dot_net_signature_date, has_biz_dev_commision, advance_by, project_uid FROM legal_information WHERE project_uid=' + uid);
  
  while(rslt.next())
  {
    var html =
    //Col 1
    "<div class='pr_p2_body_colum'>" +
      "<div class='sd_p2_body_row'>" +
        "<div class='sd_p2_body_title'>" +
          "Publishing Agreement" +
        "</div>" +
        "<div class='sd_p2_body_text'>" +
          "<div>" +
            "<span class='li_contract_title'>Signed: </span>" +
            "<span class='li_contract_status' id='li_is_publishing_signed'>" + ((rslt.getBoolean("is_publishing_agreement_signed")) ? "Yes" : "No") + "</span>" +
          "</div>" +
          "<div>" +
            "<span class='li_contract_title'>Signature Date: </span>" +
            "<span class='li_contract_status' id='li_publishing_signature_date'>" + rslt.getString("publishing_contract_date") + "</span>" +
          "</div>" +
        "</div>" +
      "</div>" +
      "<div class='sd_p2_body_row'>" +
        "<div class='sd_p2_body_title'>" +
          "Nutaku.net Agreement" +
        "</div>" +
        "<div class='sd_p2_body_text'>" +
          "<div>" +
            "<span class='li_contract_title'>Signed: </span>" +
            "<span class='li_contract_status' id='li_ntku_net_signed'>" + ((rslt.getBoolean("is_ntku_dot_net_agreement_signed")) ? "Yes" : "No") + "</span>" +
          "</div>" +
          "<div>" +
            "<span class='li_contract_title'>Signature Date: </span>" +
            "<span class='li_contract_status' id='li_ntku_net_signature_date'>" + rslt.getString("ntku_dot_net_signature_date") + "</span>" +
          "</div>" +
        "</div>" +
      "</div>" +
    "</div>" +

    //Col 2
    "<div class='pr_p2_body_colum'>" +
      "<div class='sd_p2_body_row'>" +
        "<div class='sd_p2_body_title'>" +
          "Publisher" +
        "</div>" +
        "<div class='sd_p2_body_text'>" +
          "<span id='li_publisher'>" + rslt.getString("publisher") + "</span>" +
        "</div>" +
      "</div>" +
      "<div class='sd_p2_body_row'>" +
        "<div class='sd_p2_body_title'>" +
          "Is Exclusive" +
        "</div>" +
        "<div class='sd_p2_body_text'>" +
        "<span id='li_is_exclusive'>" + ((rslt.getBoolean("is_exclusive")) ? "Yes" : "No") + "</span>" +
        "</div>" +
      "</div>" +
    "</div>" +
    
    //Col 3
    "<div class='pr_p2_body_colum'>" +
      "<div class='sd_p2_body_row'>" +
        "<div class='sd_p2_body_title'>" +
          "IP Holder" +
        "</div>" +
        "<div class='sd_p2_body_text'>" +
          "<span id='li_ip_holder'>" + rslt.getString("ip_holder") + "</span>" +
        "</div>" +
      "</div>" +
      "<div class='sd_p2_body_row'>" +
        "<div class='sd_p2_body_title'>" +
          "Nutaku Pays Free Gold" +
        "</div>" +
        "<div class='sd_p2_body_text'>" +
          "<span id='li_nutaku_pays_gold'>" + ((rslt.getBoolean("ntku_pays_free_gold")) ? "Yes" : "No") + "</span>" +
        "</div>" +
      "</div>" +
    "</div>" +

    //Col 4
    "<div class='pr_p2_body_colum'>" +
      "<div class='sd_p2_body_row'>" +
        "<div class='sd_p2_body_title'>" +
          "Advance by:" +
        "</div>" +
        "<div class='sd_p2_body_text'>" +
          "<span id='li_advance_by'>" + rslt.getString("advance_by") + "</span>" +
        "</div>" +
      "</div>" +
      "<div class='sd_p2_body_row'>" +
        "<div class='sd_p2_body_title'>" +
          "Has BizDev Commision" +
        "</div>" +
        "<div class='sd_p2_body_text'>" +
          "<span id='li_has_biz_dev_commission'>" + ((rslt.getBoolean("has_biz_dev_commision")) ? "Yes" : "No") + "</span>" +
        "</div>" +
      "</div>" +
    "</div>";
  }

  return html;
}


function generateLegalInformationPopup()
{
  var html =
  "<div id='dialog-edit-game-legal' data-uid=''>" +
    "<form id='edit-game-legal'>" +
      "<fieldset>" +
        "<div>" +
          "<label class='text-field-label' for='lip_publisher'>Publisher</label>" +
          "<input type='text' name='publisher' id='lip_publisher' class='ui-text'>" +
        "</div>" +
        "<div>" +
          "<label class='text-field-label' for='lip_holder'>IP Holder</label>" +
          "<input type='text' name='ip-holder' id='lip_holder' class='ui-text'>" +
        "</div>" +
        "<div>" +
          "<label class='text-field-label' for='lip_advance'>Advance By</label>" +
          "<input type='text' name='advance' id='lip_advance' class='ui-text'>" +
        "</div>" +
        "<div>" +
          "<label class='text-field-label'>Publishing Agreement</label>" +
          "<div class='lip_agreement_container'>" +
            "<div class='lip_agreement_date_toggle_container'>" +
              "<label class='lip_agreement_label'>Signed</label>" +
              "<div class='ui-toggle'>" +
                "<input type='radio' class='ui-toggle-input' name='is_publishing_signed' value='yes' id='publishing_signed_yes'>" +
                "<label for='publishing_signed_yes' class='ui-toggle-label ui-toggle-label-on'>Yes</label>" +
                "<input type='radio' class='ui-toggle-input' name='is_publishing_signed' value='no' id='publishing_signed_no'>" +
                "<label for='publishing_signed_no' class='ui-toggle-label ui-toggle-label-off'>No</label>" +
                "<span class='ui-toggle-selection'></span>" +
              "</div>" +
            "</div>" +
            "<div>" +
              "<label for='lip_publishing_agreement_date' class='lip_agreement_label'>Signature Date</label>" +
              "<input type='date' name='publishing_date' id='lip_publishing_agreement_date' class='text ui-widget-content ui-corner-all'></input>" +
            "</div>" +
          "</div>" +
        "</div>" +
        "<div>" +
          "<label class='text-field-label'>Nutaku.net Agreement</label>" +
          "<div class='lip_agreement_container'>" +
            "<div class='lip_agreement_date_toggle_container'>" +
              "<label class='lip_agreement_label'>Signed</label>" +
              "<div class='ui-toggle'>" +
                "<input type='radio' class='ui-toggle-input' name='is_nutaku_net_signed' value='yes' id='nutaku_net_signed_yes'>" +
                "<label for='nutaku_net_signed_yes' class='ui-toggle-label ui-toggle-label-on'>Yes</label>" +
                "<input type='radio' class='ui-toggle-input' name='is_nutaku_net_signed' value='no' id='nutaku_net_signed_no'>" +
                "<label for='nutaku_net_signed_no' class='ui-toggle-label ui-toggle-label-off'>No</label>" +
                "<span class='ui-toggle-selection'></span>" +
              "</div>" +
            "</div>" +
            "<div>" +
              "<label for='lip_nutaku_net_agreement_date' class='lip_agreement_label'>Signature Date</label>" +
              "<input type='date' name='nutaku_net_date' id='lip_nutaku_net_agreement_date' class='text ui-widget-content ui-corner-all'></input>" +
            "</div>" +
          "</div>" +
        "</div>" +
        "<div class='lip_toggles_container'>" +
          "<div class='lip_toggle_container'>" +
            "<label class='text-field-label'>Is Exclusive?</label>" +
            "<div class='ui-toggle'>" +
              "<input type='radio' class='ui-toggle-input' name='is_exclusive' value='yes' id='exclusive_yes'>" +
              "<label for='exclusive_yes' class='ui-toggle-label ui-toggle-label-on'>Yes</label>" +
              "<input type='radio' class='ui-toggle-input' name='is_exclusive' value='no' id='exclusive_no'>" +
              "<label for='exclusive_no' class='ui-toggle-label ui-toggle-label-off'>No</label>" +
              "<span class='ui-toggle-selection'></span>" +
            "</div>" +
          "</div>" +
          "<div class='lip_toggle_container'>" +
            "<label class='text-field-label'>Nutaku Pays Free Gold</label>" +
            "<div class='ui-toggle'>" +
              "<input type='radio' class='ui-toggle-input' name='nutaku_pays_free_gold' value='yes' id='nutaku_pays_free_gold_yes'>" +
              "<label for='nutaku_pays_free_gold_yes' class='ui-toggle-label ui-toggle-label-on'>Yes</label>" +
              "<input type='radio' class='ui-toggle-input' name='nutaku_pays_free_gold' value='no' id='nutaku_pays_free_gold_no'>" +
              "<label for='nutaku_pays_free_gold_no' class='ui-toggle-label ui-toggle-label-off'>No</label>" +
              "<span class='ui-toggle-selection'></span>" +
            "</div>" +
          "</div>" +
          "<div class='lip_toggle_container'>" +
            "<label class='text-field-label'>Has Bizdev Commision</label>" +
            "<div class='ui-toggle'>" +
              "<input type='radio' class='ui-toggle-input' name='has_bizdev_commission' value='yes' id='has_bizdev_commission_yes'>" +
              "<label for='has_bizdev_commission_yes' class='ui-toggle-label ui-toggle-label-on'>Yes</label>" +
              "<input type='radio' class='ui-toggle-input' name='has_bizdev_commission' value='no' id='has_bizdev_commission_no'>" +
              "<label for='has_bizdev_commission_no' class='ui-toggle-label ui-toggle-label-off'>No</label>" +
              "<span class='ui-toggle-selection'></span>" +
            "</div>" +
          "</div>" +
        "</div>" +
      "</fieldset>" +
    "</form>" +
  "</div>";
  return html;
}

function generateTechnicalInformation(uid)
{
  var conn = fetchConnection();
  var stmt = conn.createStatement();
  stmt.setMaxRows(1);
  var rslt = stmt.executeQuery('SELECT platform_types, categories, genres, game_engine, ntku_engine_category, cross_save, requirements_to_launch, languages, distribution, technology, app_id, monetization, adult_content FROM project WHERE uid=' + uid);

  while(rslt.next())
  {
    // Prepare dropdown values
    var monetizationDropdownId = rslt.getInt("monetization");
    var adultContentDropdownId = rslt.getInt("adult_content");

    var html =
    //Col 1
    "<div class='pr_p2_body_colum'>" +
      "<div class='sd_p2_body_row'>" +
        "<div class='sd_p2_body_title'>" +
          "Languages" +
        "</div>" +
        "<div class='sd_p2_body_text'>" +
          generateTags("language", rslt.getString("languages")) +
        "</div>" +
      "</div>" +
      "<div class='sd_p2_body_row'>" +
        "<div class='sd_p2_body_title'>" +
          "Platforms" +
        "</div>" +
        "<div class='sd_p2_body_text'>" +
          generateTags("platform_type", rslt.getString("platform_types")) +
        "</div>" +
      "</div>" +
      "<div class='sd_p2_body_row'>" +
        "<div class='sd_p2_body_title'>" +
          "Distribution" +
        "</div>" +
        "<div class='sd_p2_body_text'>" +
        "<span id='gd_tech_info_distribution' class='gd_tech_info_text'>" + rslt.getString("distribution") + "</span>" +
        "</div>" +
      "</div>" +
      "<div class='sd_p2_body_row'>" +
        "<div class='sd_p2_body_title'>" +
          "Adult content" +
        "</div>" +
        "<div class='sd_p2_body_text'>" +
        "<span id='gd_tech_info_adult_content' class='gd_tech_info_text' data-id='" + adultContentDropdownId + "'>" + getAdultContentDropdownOption(adultContentDropdownId) + "</span>" +
        "</div>" +
      "</div>" +
    "</div>" +

    //Col 2
    "<div class='pr_p2_body_colum'>" +
      "<div class='sd_p2_body_row'>" +
        "<div class='sd_p2_body_title'>" +
          "Category" +
        "</div>" +
        "<div class='sd_p2_body_text'>" +
          generateTags("project_category", rslt.getString("categories")) +
        "</div>" +
      "</div>" +
      "<div class='sd_p2_body_row'>" +
        "<div class='sd_p2_body_title'>" +
          "Genre" +
        "</div>" +
        "<div class='sd_p2_body_text'>" +
          generateTags("project_genre", rslt.getString("genres")) +
        "</div>" +
      "</div>" +
      "<div class='sd_p2_body_row'>" +
        "<div class='sd_p2_body_title'>" +
          "Tech" +
        "</div>" +
        "<div class='sd_p2_body_text'>" +
        "<span id='gd_tech_info_technology' class='gd_tech_info_text'>" + rslt.getString("technology") + "</span>" +
        "</div>" +
      "</div>" +
    "</div>" +

    //Col 3
    "<div class='pr_p2_body_colum'>" +
      "<div class='sd_p2_body_row'>" +
        "<div class='sd_p2_body_title'>" +
          "Engine Type" +
        "</div>" +
        "<div class='sd_p2_body_text'>" +
          generateTags("game_engine", rslt.getString("game_engine")) +
        "</div>" +
      "</div>" +
      "<div class='sd_p2_body_row'>" +
        "<div class='sd_p2_body_title'>" +
          "Nutaku Engine Category" +
        "</div>" +
        "<div class='sd_p2_body_text'>" +
        "<span id='gd_tech_info_ntku_engine_category' class='gd_tech_info_text'>" + rslt.getString("ntku_engine_category") + "</span>" +
        "</div>" +
      "</div>" +
      "<div class='sd_p2_body_row'>" +
        "<div class='sd_p2_body_title'>" +
          "App Id" +
        "</div>" +
        "<div class='sd_p2_body_text'>" +
        "<span id='gd_tech_info_app_id' class='gd_tech_info_text'>" + rslt.getString("app_id") + "</span>" +
        "</div>" +
      "</div>" +
    "</div>" +

    //Col 4
    "<div class='pr_p2_body_colum'>" +
      "<div class='sd_p2_body_row'>" +
        "<div class='sd_p2_body_title'>" +
          "Cross Save State" +
        "</div>" +
        "<div class='sd_p2_body_text'>" +
          "<span id='gd_tech_info_cross_save' class='gd_tech_info_text'>" + ((rslt.getBoolean("cross_save")) ? "Yes" : "No") + "</span>" +
        "</div>" +
      "</div>" +
      "<div class='sd_p2_body_row'>" +
        "<div class='sd_p2_body_title'>" +
          "Requirement to Launch" +
        "</div>" +
        "<div class='sd_p2_body_text'>" +
        "<span id='gd_tech_info_launch_requirements' class='gd_tech_info_text'>" + rslt.getString("requirements_to_launch") + "</span>" +
        "</div>" +
      "</div>" +
      "<div class='sd_p2_body_row'>" +
        "<div class='sd_p2_body_title'>" +
          "Monetization" +
        "</div>" +
        "<div class='sd_p2_body_text'>" +
        "<span id='gd_tech_info_monetization' class='gd_tech_info_text' data-id='" + monetizationDropdownId + "'>" + getMonetizationDropdownOption(monetizationDropdownId) + "</span>" +
        "</div>" +
      "</div>" +
    "</div>";
  }

  return html;
}

function generateTechnicalInformationPopup()
{
  var html =
  "<div id='dialog-edit-game-technical' data-uid=''>" +
    "<form id='edit-game-technical'>" +
      "<fieldset>" +
        "<div class='gd_checkbox_group_container'>" +
          "<div class='gd_checkbox_container'>Languages" +
            generateCheckboxList("language") +
          "</div>" +
          "<div class='gd_checkbox_container'>Platforms" +
            generateCheckboxList("platform_type") +
          "</div>" +
          "<div class='gd_checkbox_container'>Category" +
            generateCheckboxList("project_category") +
          "</div>" +
          "<div class='gd_checkbox_container'>Genre" +
            generateCheckboxList("project_genre") +
          "</div>" +
          "<div class='gd_checkbox_container'>Game Engine" +
            generateCheckboxList("game_engine") +
          "</div>" +
        "</div>" +
        "<div>" +
          "<label class='text-field-label'>Nutaku Engine Category</label>" +
          "<textarea id='gd_tech_popup_ntku_engine_category' name='ntku_engine_category' class='ui-text-area' placeholder='Nutaku Engine Category'></textarea>" +
        "</div>" +
        "<div>" +
          "<label class='text-field-label'>Requirement To Launch</label>" +
          "<textarea id='gd_tech_popup_launch_requirements' name='requirements_to_launch' class='ui-text-area' placeholder='Requirement To Launch'></textarea>" +
        "</div>" +
        "<div>" +
          "<label class='text-field-label'>Distribution</label>" +
          "<textarea id='gd_tech_popup_distribution' name='distribution' class='ui-text-area' placeholder='Distribution'></textarea>" +
        "</div>" +
        "<div>" +
          "<label class='text-field-label'>Tech</label>" +
          "<textarea id='gd_tech_popup_technology' name='technology' class='ui-text-area' placeholder='Tech'></textarea>" +
        "</div>" +
        "<div>" +
          "<label class='text-field-label'>App Id</label>" +
          "<textarea id='gd_tech_popup_app_id' name='app_id' class='ui-text-area' placeholder='App Id'></textarea>" +
        "</div>" +
        "<div>" +
          "<div class='gd_dropdown_container'>" +
          "<label class='text-field-label' for='selectmenu'>Monetization</label>" +
          "<select id='gd_dropdown_monetization' class='ui-selectmenu' name='monetization'>" +
            "<option disabled selected value='0'>Select One</option>" +
            "<option value='1'>" + getMonetizationDropdownOption(1) + "</option>" +
            "<option value='2'>" + getMonetizationDropdownOption(2) + "</option>" +
          "</select>" +
          "</div>" +
          "<div class='gd_dropdown_container'>" +
          "<label class='text-field-label' for='selectmenu'>Adult content</label>" +
          "<select id='gd_dropdown_adult_content' class='ui-selectmenu' name='adult_content'>" +
            "<option disabled selected value='0'>Select One</option>" +
            "<option value='1'>" + getAdultContentDropdownOption(1) + "</option>" +
            "<option value='2'>" + getAdultContentDropdownOption(2) + "</option>" +
            "<option value='3'>" + getAdultContentDropdownOption(3) + "</option>" +
            "<option value='4'>" + getAdultContentDropdownOption(4) + "</option>" +
          "</select>" +
          "</div>" +
        "</div>" +
        "<div>" +
          "<label class='text-field-label'>Cross Save</label>" +
          "<div class='ui-toggle'>" +
            "<input type='radio' class='ui-toggle-input' name='cross_save' value='yes' id='cross-save_yes'>" +
            "<label for='cross-save_yes' class='ui-toggle-label ui-toggle-label-on'>Yes</label>" +
            "<input type='radio' class='ui-toggle-input' name='cross_save' value='no' id='cross-save_no'>" +
            "<label for='cross-save_no' class='ui-toggle-label ui-toggle-label-off'>No</label>" +
            "<span class='ui-toggle-selection'></span>" +
          "</div>" +
        "</div>" +
      "</fieldset>" +
    "</form>" +
  "</div>";
  return html;
}

function getMonetizationDropdownOption(id) 
{
  switch(id) 
  {
    case 1:
      return "Premium";
    case 2:
      return "F2P";
  }
}

function getAdultContentDropdownOption(id) 
{
  switch(id) 
  {
    case 1:
      return "None";
    case 2:
      return "Softcore";
    case 3:
      return "Moderate";
    case 4:
      return "Hardcore";
  }
}

//table: string for the table name
//tableIds: comma-separated string of ids
function generateTags(table, tableIds)
{
  if(tableIds == null)
    return "";
  
  tableIds = tableIds.split(",");
  var conn = fetchConnection();
  var table_stmt = conn.createStatement();
  var table_rslt = table_stmt.executeQuery('SELECT small_name, uid FROM ' + table);

  var tableData = {};
  while(table_rslt.next())
  {
    tableData[table_rslt.getInt("uid")] = table_rslt.getString("small_name");
  }

  var html = 
  "<div id='" + table + "_tags' class='ui-tags'>";

  for(var i = 0; i < tableIds.length; i++)
  {
    var id = tableIds[i];
    var value = tableData[id];
    if(value == null)
      continue;

    html +=
    "<div class='ui-tag' data-tag_id='" + id + "'><label>" + value + "</label></div>";
  }

  html +=
  "</div>";

  return html;
}

function generateCheckboxList(table)
{
  var conn = fetchConnection();
  var stmt = conn.createStatement();
  var rslt = stmt.executeQuery('SELECT * FROM ' + table);

  var names = [];
  var ids = [];
  while(rslt.next())
  {
    names.push(rslt.getString("full_name"));
    ids.push(rslt.getInt("uid"));
  }

  var html = "";
  for(var i = 0; i < names.length; i++)
  {
    html +=
    "<label class='ui-checkbox_container'>" + names[i] +
      "<input type='checkbox' id='" + table + "_" + ids[i] + "' name='" + table + "_" + names[i] + "'>" +
      "<span class='ui-checkbox'></span>" +
    "</label>";
  }

  return html;
}

function generateStarsControl(stars_name, nbStars, score, selectable)
{
  if(score == -1) //Indicates an unknown score when the function is called
    score = 0;
  
  var html =  "<div class='ui-star'>";
  for (var i = nbStars; i >= 1; i--) {
    var id = stars_name + "-star" + i;
    var value = i;
    var classAtt = (i % 2 == 0) ? "full" : "half";
    html +=     "<input type='radio' id='" + id + "' name='" + stars_name + "' value='" + value + "'";
    if(value == score)
      html += "checked='checked'";
    if(!selectable)
      html += "disabled='true'";

    html += "/><label class = '" + classAtt + "' for='" + id + "'";
    if(!selectable)
      html += "style='pointer-events:none'";
    html += "></label>";
  }
  
  var idZero = stars_name + "-star0";
  html +=       "<input type='radio' id='" + idZero + "' name='" + stars_name + "' value='0' /><label class='zero' for='" + idZero + "'></label>";
  html +=     "</div>";
  return html;
}

function parseToThousandsString(value)
{
  if(typeof value !== "string")
    value = value.toString();
  
  var result = "";
  var count = 0;
  for(var i = value.length - 1; i >= 0; i--)
  {
    var char = value[i];
    if(isNaN(char)) //Skip non-numeric characters, comas and dots included
      continue;

    if(count % 3 == 0 && count != 0)
      result = char + "," + result;
    else
      result = char + result;
    
    count++;
  }

  return result;
}

function generateGateHtml(gate_uid, project_uid)
{
  var FEEDBACK_REQUIRED_UID = 1;

  var conn = fetchConnection();
  var feedback_template_stmt = conn.createStatement();
  var feedback_template_results = feedback_template_stmt.executeQuery('SELECT * FROM gate_feedback_template WHERE gate_uid=' + gate_uid);
  
  var feedback_stmt = conn.createStatement();
  var feedback_results = feedback_stmt.executeQuery('SELECT * FROM gate_feedback WHERE gate_uid=' + gate_uid + ' AND project_uid = ' + project_uid);

  var declaration_stmt = conn.createStatement();
  var declaration_results = declaration_stmt.executeQuery('SELECT * FROM gate_declaration');

  //Store declarations
  var declarations = {};
  while(declaration_results.next())
  {
    var declaration = {};
    declaration.uid = declaration_results.getInt("uid");
    declaration.name = declaration_results.getString("name");
    declaration.color = declaration_results.getInt("color");

    declarations[declaration.uid] = declaration;
  }

  //Store feedbacks
  var feedbacks = {};
  var domainUsers = getAllUsers();
  var rolesByUid = getRolesByUid();
  while(feedback_results.next())
  {
    var feedback = {};
    feedback.uid = feedback_results.getInt("uid");
    feedback.feedback = feedback_results.getString("feedback");
    feedback.todo = feedback_results.getString("todo");
    feedback.user_domain_email = feedback_results.getString("user_domain_email");
    feedback.date = feedback_results.getString("date");
    feedback.template_uid = feedback_results.getInt("template_uid");
    feedback.declaration_uid = feedback_results.getInt("declaration_uid");
    feedbacks[feedback.template_uid] = feedback;
  }


  //Generate html rows for each template
  var html = 
  "<div class='sd_p_body_row'>";
  while(feedback_template_results.next())
  {
    var template = {};
    template.uid = feedback_template_results.getInt("uid");
    template.role_uid = feedback_template_results.getInt("role_uid");

    var feedback = feedbacks[template.uid];
    var declaration = null;
    if(feedback != null) 
      declaration = declarations[feedback.declaration_uid];
    else
      declaration = declarations[FEEDBACK_REQUIRED_UID];

    html +=
    "<div class='gate_row'>" +
      "<div class='gate_cell'>";

    //Name
    if(feedback != null && domainUsers[feedback.user_domain_email] != null)
      html +=
        "<label>" + domainUsers[feedback.user_domain_email].name.fullName + "</label>";
    else
      html +=
        "<label>-</label>";
    
    //Role
    html +=
        "<label>" + rolesByUid[template.role_uid].name + "</label>";
    //HTML
    if(feedback != null)
      html +=
        "<label>" + feedback.date + "</label>";
    
    html += 
      "</div>" +
    //Declaration
      "<div class='gate_cell'>" +
        "<div class='gate_declaration_background' style='background-color:" + intToHexColor(declaration.color) + "'>" + declaration.name + "</div>" +
      "</div>";
    if(feedback != null)
      html +=
      //Feedback
      "<div class='gate_cell'>" +
        "<label>" + feedback.feedback + "</label>" +
      "</div>" +
      //Todo
      "<div class='gate_cell'>" +
        "<label>" + feedback.todo + "</label>" +
      "</div>";
    else
      html +=
      "<div class='gate_cell'>" +
        "<label>-</label>" +
      "</div>" +
      "<div class='gate_cell'>" +
        "<label>-</label>" +
      "</div>";

    html +=
    "</div>";
  }

  html +=
  "</div>";

  return html;
}

function intToHexColor(intColor) {
  var bbggrr =  ("000000" + intColor.toString(16)).slice(-6);
  var rrggbb =  bbggrr.substr(0, 2) + bbggrr.substr(2, 2) + bbggrr.substr(4, 2);
  return "#" + rrggbb;
}