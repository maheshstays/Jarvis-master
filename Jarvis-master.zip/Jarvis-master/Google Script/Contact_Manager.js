var CONTACTS_CACHE = null;

//source: "project", "studio" or "financial". If null, all contacts known are sent
//uid: optionnal. uid for source. If undefined, returns all the contacts for the source.
//role: optionnal. Role name if string, role uid if int. Default role names (aka those added to the database by default)
//  are "Nutaku Producer" (uid 1), "Developer Producer" (uid 2) and "Nutaku BizDev" (uid 3).
//Returns an array of contact, which have this format: 
//  {name:string, email:string, skype:string, uid:int, s_uid:int, role: { name:string, is_default:bool, uid:int } }
function getContacts(source, uid, role)
{
  return getContactsCache().getContacts(source, uid, role);
}

function getRawContacts()
{
  return getContactsCache().contacts;
}

//returns an object in this format:
//  { uid:int { name:string, is_default:bool, uid:int }, [...] }
function getRoles()
{
  return getContactsCache().roles;
}

//source: "project", "studio" or "financial"
//contacts: expects an array of contacts formatted in this way:
//  {name:string, email:string, skype:string, s_uid:int, role: { name:string, is_default:bool } }
function insertContacts(source, contacts)
{
  var cache = getContactsCache();
  for(var i = 0; i < contacts.length; i++)
  {
    cache.insertContact(source, contacts[i]);
  }
}

//Expects a role in this format
//  { name:string, is_default:bool }
function insertContactRole(role)
{
  getContactsCache().insertRole(role);
}

//Expects an array of contacts formatted in this way:
//  {name:string, email:string, skype:string, uid:int, s_uid:int, role: { name:string, is_default:bool, uid:int } }
function updateContacts(contacts)
{
  var cache = getContactsCache();
  for(var i = 0; i < contacts.length; i++)
  {
    cache.updateContact(contacts[i]);
  }
}

//Removes all the contacts for a source and add these ones instead
function updateContactsForSource(source, s_uid, contacts)
{
  getContactsCache().updateContactsForSource(source, s_uid, contacts);
}

function getContactsCache()
{
  if(CONTACTS_CACHE != null)
    return CONTACTS_CACHE;

  CONTACTS_CACHE = {};
  
  var conn = fetchConnection();
  var contact_stmt = conn.createStatement();
  var contact_rslt = contact_stmt.executeQuery('SELECT * FROM contact');
  var contact_role_stmt = conn.createStatement();
  var contact_role_rslt = contact_role_stmt.executeQuery('SELECT * FROM contact_role');
  var project_info_contact_stmt = conn.createStatement();
  var project_info_contact_rslt = project_info_contact_stmt.executeQuery('SELECT * FROM project_info_contact');
  var financial_info_contact_stmt = conn.createStatement();
  var financial_info_contact_rslt = financial_info_contact_stmt.executeQuery('SELECT * FROM financial_info_contact');
  var studio_info_contact_stmt = conn.createStatement();
  var studio_info_contact_rslt = studio_info_contact_stmt.executeQuery('SELECT * FROM studio_info_contact');

  //Adding contacts to cache
  CONTACTS_CACHE.contacts = {};
  while(contact_rslt.next())
  {
    var obj = {};
    obj.uid = contact_rslt.getInt("uid");
    obj.name = contact_rslt.getString("name");
    obj.email = contact_rslt.getString("email");
    obj.skype = contact_rslt.getString("skype");
    CONTACTS_CACHE.contacts[obj.uid] = obj;
  }
  
  //Adding contact roles to cache
  CONTACTS_CACHE.roles = {};
  while(contact_role_rslt.next())
  {
    var obj = {};
    obj.uid = contact_role_rslt.getString("uid");
    obj.name = contact_role_rslt.getString("name");
    obj.is_default = contact_role_rslt.getBoolean("is_default");
    CONTACTS_CACHE.roles[obj.uid] = obj;
  }
  
  //Adding project information contacts to cache
  CONTACTS_CACHE.project_contacts = [];
  while(project_info_contact_rslt.next())
  {
    var obj = {};
    obj.source_uid = project_info_contact_rslt.getInt("project_uid");
    obj.role_uid = project_info_contact_rslt.getInt("role_uid");
    obj.contact_uid = project_info_contact_rslt.getInt("contact_uid");
    CONTACTS_CACHE.project_contacts.push(obj);
  }
  
  //Adding financial information contacts to cache
  CONTACTS_CACHE.financial_contacts = [];
  while(financial_info_contact_rslt.next())
  {
    var obj = {};
    obj.source_uid = financial_info_contact_rslt.getInt("studio_uid");
    obj.role_uid = financial_info_contact_rslt.getInt("role_uid");
    obj.contact_uid = financial_info_contact_rslt.getInt("contact_uid");
    CONTACTS_CACHE.financial_contacts.push(obj);
  }
  
  //Adding studio information contacts to cache
  CONTACTS_CACHE.studio_contacts = [];
  while(studio_info_contact_rslt.next())
  {
    var obj = {};
    obj.source_uid = studio_info_contact_rslt.getInt("studio_uid");
    obj.role_uid = studio_info_contact_rslt.getInt("role_uid");
    obj.contact_uid = studio_info_contact_rslt.getInt("contact_uid");
    CONTACTS_CACHE.studio_contacts.push(obj);
  }

  //source: "project", "studio" or "financial"
  //s_uid: optionnal. uid for source. If undefined, returns all the contacts for the source.
  //role: optionnal. Role name if string, role uid if int. Default role names (aka those added to the database by default)
  //  are "Nutaku Producer" (uid 1), "Developer Producer" (uid 2) and "Nutaku BizDev" (uid 3).
  //Returns an array of contact, which have this format: 
  //  {name:string, email:string, skype:string, uid:int, s_uid:int, role: { name:string, is_default:bool, uid:int } }
  CONTACTS_CACHE.getContacts = function(source, s_uid, role)
  {
    if(source == null)
    {
      var projectContacts = CONTACTS_CACHE.getContactsForSource("project", s_uid, role);
      var studioContacts = CONTACTS_CACHE.getContactsForSource("studio", s_uid, role);
      var financialContacts = CONTACTS_CACHE.getContactsForSource("financial", s_uid, role);

      return projectContacts.concat(studioContacts).concat(financialContacts);
    }
    else
    {
      return CONTACTS_CACHE.getContactsForSource(source, s_uid, role);
    }
  }

  CONTACTS_CACHE.getContactsForSource = function(source, s_uid, role)
  {
    var sourceArray = null;
    if(source == "project")
      sourceArray = CONTACTS_CACHE.project_contacts;
    else if (source == "studio")
      sourceArray = CONTACTS_CACHE.studio_contacts;
    else if (source == "financial")
      sourceArray = CONTACTS_CACHE.financial_contacts;
    else
    {
      Logger.log("getContacts - Unknown contact source '" + source + "'.");
      return [];
    }

    var contacts = [];
    for(var i = 0; i < sourceArray.length; i++)
    {
      var curSource = sourceArray[i];

      //Validate role
      var isRoleOk = true;
      if(role != null)
      {
        if(isInt(role) && role == curSource.role_uid) //If role is int, check role's uid
          isRoleOk = true;
        else if(typeof role === "string" && role == CONTACTS_CACHE.roles[curSource.role_uid].name) //If role is string, check roles name
          isRoleOk = true;
        isRoleOk = false;
      }
      if(!isRoleOk)
        continue;
      
      //Validate uid
      var isValidSUid = true;
      if(isInt(s_uid) && s_uid > 0)
        isValidSUid = curSource.source_uid == s_uid;

      
      var contactCache = CONTACTS_CACHE.contacts[curSource.contact_uid];
      if(contactCache == null)
      {
        Logger.log("ERROR - Couldn't find contact with uid " + curSource.contact_uid + " in cache, while there's a source record for it.");
        continue;
      }

      var roleCache = CONTACTS_CACHE.roles[curSource.role_uid];
      if(roleCache == null)
      {
        Logger.log("ERROR - Couldn't find role with uid " + curSource.contact_uid + " in cache, while there's a source record for it.");
        continue;
      }

      if(isValidSUid)
      {
        var roleRsl = {};
        roleRsl.name = roleCache.name;
        roleRsl.is_default = roleCache.is_default;
        roleRsl.uid = roleCache.uid;

        var contactRslt = {};
        contactRslt.name = contactCache.name;
        contactRslt.email = contactCache.email;
        contactRslt.skype = contactCache.skype;
        contactRslt.uid = contactCache.uid;
        contactRslt.s_uid = s_uid;
        contactRslt.role = roleRsl;

        contacts.push(contactRslt);
      }
    }

    return contacts;
  }

  //Expects a contact formatted in this format:
  //  {name:string, email:string, skype:string, uid:int, s_uid:int, role: { name:string, is_default:bool, uid:int } }
  CONTACTS_CACHE.updateContact = function(contact)
  {
    if(contact == null)
      return;

    conn = fetchConnection();
    var stmt = conn.prepareStatement("UPDATE contact SET name=?, email=?, skype=? WHERE uid=?");
    stmt.setString(1, contact.name);
    stmt.setString(2, contact.email);
    stmt.setString(3, contact.skype);
    stmt.setInt(4, contact.uid);
    stmt.executeUpdate();
    
    //Update cache
    CONTACTS_CACHE.contacts[contact.uid] = contact;

    if(contact.role != null)
      CONTACTS_CACHE.updateRole(contact.role);
  }
  
  //Expects a contact formatted in this format:
  //  {name:string, email:string, skype:string, s_uid:int, role: { name:string, is_default:bool } }
  CONTACTS_CACHE.insertContact = function(source, contact)
  {
    if(contact == null)
      return;
    
    if(contact.role == null)
    {
      Logger.log("Can't insert contact without a role on contact with uid '" + contact.uid + "'.");
      return;
    }

    if(contact.s_uid == null)
    {
      Logger.log("s_uid is missing on contact with uid '" + contact.uid + "'.");
    }

    conn = fetchConnection();
    var stmt = conn.prepareStatement("INSERT INTO contact (name, email, skype) value (?, ?, ?)", 1);
    stmt.setString(1, contact.name);
    stmt.setString(2, contact.email);
    stmt.setString(3, contact.skype);
    stmt.executeUpdate();
    
    //Doesn't seem ideal to retreive the newly added uid, but it does work
    var keys = stmt.getGeneratedKeys(); //Get all the auto-generated keys, aka uid
    keys.last(); //Move to last entry
    contact.uid = keys.getInt(1); //Get value in 1st (and only) collumn
    
    //Add role
    var role = null;
    if(isValidUid(contact.role.uid))
      role = CONTACTS_CACHE.roles[contact.role.uid];
    else
      role = CONTACTS_CACHE.getRoleByName(contact.role.name);
    
    if(role != null)
      contact.role = role;
    else
    {
      CONTACTS_CACHE.insertRole(contact.role);
    }

    //Add source
    CONTACTS_CACHE.insertSourceRow(source, contact.s_uid, contact.role.uid, contact.uid);

    //Add new contact to cache
    CONTACTS_CACHE.contacts[contact.uid] = contact;
  }

  //Expects a role in this format:
  //  { name:string, is_default:bool, uid:int }
  CONTACTS_CACHE.updateRole = function(role)
  {
    if(role == null)
      return;

    conn = fetchConnection();
    var stmt = conn.prepareStatement("UPDATE contact_role SET name=? WHERE uid=?");
    stmt.setString(1, role.name);
    stmt.setInt(2, role.uid);
    stmt.executeUpdate();

    //Update cache
    CONTACTS_CACHE.roles[role.uid] = role;
  }

  //Expects a role in this format:
  //  { name:string, is_default:bool, uid:int }
  CONTACTS_CACHE.insertRole = function(role)
  {
    if(role == null)
      return;

    conn = fetchConnection();
    var stmt = conn.prepareStatement("INSERT INTO contact_role (name, is_default) values (?, ?)", 1);
    stmt.setString(1, role.name);
    stmt.setBoolean(2, role.is_default);
    stmt.executeUpdate();

    //Doesn't seem ideal to retreive the newly added uid, but it does work
    var keys = stmt.getGeneratedKeys(); //Get all the auto-generated keys, aka uid
    keys.last(); //Move to last entry
    role.uid = keys.getInt(1); //Get value in 1st (and only) collumn

    //Add new role to cache
    CONTACTS_CACHE.roles[role.uid] = role;
  }

  CONTACTS_CACHE.insertSourceRow = function(source, source_uid, role_uid, contact_uid)
  {
    var table = null;
    var sourceName = null;
    var sourceArray = null;
    if(source == "project")
    {
      table = "project_info_contact";
      sourceName = "project_uid";
      sourceArray = CONTACTS_CACHE.project_contacts;
    }
    else if (source == "studio")
    {
      table = "studio_info_contact";
      sourceName = "studio_uid";
      sourceArray = CONTACTS_CACHE.financial_contacts;
    }
    else if (source == "financial")
    {
      table = "financial_info_contact";
      sourceName = "studio_uid";
      sourceArray = CONTACTS_CACHE.studio_contacts;
    }
    else
    {
      Logger.log("insertSourceRow - Unknown contact source '" + source + "'.");
      return null;
    }

    conn = fetchConnection();
    var stmt = conn.prepareStatement("INSERT INTO " + table + " (" + sourceName + ", role_uid, contact_uid) values (?, ?, ?)", 1);
    stmt.setInt(1, source_uid);
    stmt.setInt(2, role_uid);
    stmt.setInt(3, contact_uid);
    stmt.executeUpdate();

    //Add new data to cache
    var obj = {};
    obj.source_uid = source_uid;
    obj.role_uid = role_uid;
    obj.contact_uid = contact_uid;
    sourceArray.push(obj);
  }

  CONTACTS_CACHE.getRoleByName = function(name)
  {
    var role = null;
    Object.keys(CONTACTS_CACHE.roles).forEach(function(key,index) {
      var curRole = CONTACTS_CACHE.roles[key];
      if(curRole == null)
        return;
      
      if(role == null && curRole.name == name)
        role = curRole;
    });
    return role;
  }

  CONTACTS_CACHE.updateContactsForSource = function(source, s_uid, contacts)
  {
    var table = null;
    var sourceName = null;
    var sourceArray = null;
    if(source == "project")
    {
      table = "project_info_contact";
      sourceName = "project_uid";
      sourceArray = CONTACTS_CACHE.project_contacts;
    }
    else if (source == "studio")
    {
      table = "studio_info_contact";
      sourceName = "studio_uid";
      sourceArray = CONTACTS_CACHE.financial_contacts;
    }
    else if (source == "financial")
    {
      table = "financial_info_contact";
      sourceName = "studio_uid";
      sourceArray = CONTACTS_CACHE.studio_contacts;
    }
    else
    {
      Logger.log("updateContactsForSource - Unknown contact source '" + source + "'.");
      return null;
    }

    var conn = fetchConnection();
    conn.createStatement().execute('DELETE FROM ' + table + " WHERE " + sourceName + " = " + s_uid);
    for(var i = sourceArray.length - 1; i >= 0; i--)
    {
      if(sourceArray[i][sourceName] == s_uid)
        sourceArray.splice(i, 1);
    }

    for(var i = 0; i < contacts.length; i++)
    {
      Logger.log("Source: " + source + " s_UID: " + s_uid + " role: " + contacts[i].role.uid + " contact: " + contacts[i].uid);
      CONTACTS_CACHE.insertSourceRow(source, s_uid, contacts[i].role.uid, contacts[i].uid);
    }
  }

  return CONTACTS_CACHE;
}

function isValidUid(uid)
{
  if(uid == null)
    return false;
  if(!isInt(uid))
    return false;
  if(uid <= 0)
    return false;

  return true;
}

function testInsert()
{
  insertContacts("project", [{name:"Temp Name", email:"temp@email.com", skype:"tempSkypeId", s_uid:1, role: { name:"Producer", is_default: false } }])
}

function testGet()
{
  Logger.log(JSON.stringify(getContacts("project")));
}

function logTables()
{
  var conn = fetchConnection();
  var stmt = conn.createStatement();
  stmt.setMaxRows(1000);

  Logger.log("## contact ##")
  var results = stmt.executeQuery('SELECT * FROM contact');
  var numCols = results.getMetaData().getColumnCount();
  while (results.next()) 
  {     
    var rowString = '';
    for (var col = 0; col < numCols; col++) 
    {
      rowString += results.getString(col + 1) + '\t';
    }
    
    Logger.log(rowString);
  }

  Logger.log("## contact_role ##")
  results = stmt.executeQuery('SELECT * FROM contact_role');
  numCols = results.getMetaData().getColumnCount();
  while (results.next()) 
  {     
    var rowString = '';
    for (var col = 0; col < numCols; col++) 
    {
      rowString += results.getString(col + 1) + '\t';
    }
    
    Logger.log(rowString);
  }

  Logger.log("## project_info_contact ##")
  results = stmt.executeQuery('SELECT * FROM project_info_contact');
  numCols = results.getMetaData().getColumnCount();
  while (results.next()) 
  {     
    var rowString = '';
    for (var col = 0; col < numCols; col++) 
    {
      rowString += results.getString(col + 1) + '\t';
    }
    
    Logger.log(rowString);
  }

  Logger.log("## financial_info_contact ##")
  results = stmt.executeQuery('SELECT * FROM financial_info_contact');
  numCols = results.getMetaData().getColumnCount();
  while (results.next()) 
  {     
    var rowString = '';
    for (var col = 0; col < numCols; col++) 
    {
      rowString += results.getString(col + 1) + '\t';
    }
    
    Logger.log(rowString);
  }

  Logger.log("## studio_info_contact ##")
  results = stmt.executeQuery('SELECT * FROM studio_info_contact');
  numCols = results.getMetaData().getColumnCount();
  while (results.next()) 
  {     
    var rowString = '';
    for (var col = 0; col < numCols; col++) 
    {
      rowString += results.getString(col + 1) + '\t';
    }
    
    Logger.log(rowString);
  }
}