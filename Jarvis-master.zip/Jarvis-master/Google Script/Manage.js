function generateManageView()
{
  var htmlSource = HtmlService.createTemplateFromFile("manage_View").evaluate().getContent();

  var conn = fetchConnection();
  var role_stmt = conn.createStatement();
  var role_rslt = role_stmt.executeQuery('SELECT * FROM role ORDER BY name');
  var permission_stmt = conn.createStatement();
  var permission_rslt = permission_stmt.executeQuery('SELECT * FROM permission');
  var role_permission_stmt = conn.createStatement();
  var role_permission_rslt = role_permission_stmt.executeQuery('SELECT * FROM role_permission');

  var permissionsPerRole = {};
  while(role_permission_rslt.next())
  {
    var role_uid = role_permission_rslt.getInt("role_uid");
    var permission_uid = role_permission_rslt.getInt("permission_uid");

    if(permissionsPerRole[role_uid] == null)
      permissionsPerRole[role_uid] = [];
    
    permissionsPerRole[role_uid].push(permission_uid);
  }

  var html =
  "<div id='main-data-table' class='mng_master_container'>" +
    "<div class='ui-editable-selectmenu-container'>" +
      "<label class='text-field-label' for='mng_role'>Role</label>" +
      "<div class='mng_role_input_container'>" +
        "<select id='mng_role' class='ui-editable-selectmenu' data-filter='true'>";
  
  var rolesUidsPerName = {};
  while(role_rslt.next())
  {
    
    var roleName = role_rslt.getString("name");
    rolesUidsPerName[roleName] = role_rslt.getInt("uid");
    html +=
          "<option value='" + role_rslt.getInt("uid") + "'>" + role_rslt.getString("name") + "</option>";
  }

  html +=
        "</select>" +
        "<button id='mng_add_btn' type='button' class='mng_role_btn ui-button'>Add Role</button>" + 
        "<button id='mng_update_btn' type='button' class='mng_role_btn ui-button'>Update Role</button>" + 
      "</div>" +
      "<label class='text-field-label'>Permissions</label>" +
      "<div>";
  while(permission_rslt.next())
  {
    html +=
        "<div class='mng_permission_container'>" +
          "<label class='ui-checkbox_container'>" + permission_rslt.getString("name") +
            "<input class='mng_permission_checkbox' data-uid='" + permission_rslt.getInt("uid") + "' type='checkbox'>" +
            "<span class='ui-checkbox'></span>" +
          "</label>" +
          "<a title='" + permission_rslt.getString("description") + "'><img class='mng_question_mark' src='https://nutaku-jarvis.s3.us-east-2.amazonaws.com/images/question_mark.png'></a>" +
        "</div>";
  }

  html +=
      "</div>" +
    "</div>" +
    "<div>" +
      "<labe>Company Roles</label>" +
      generateRolesTabsHtml(true, false) +
    "</div>" +
  "</div>" +
  
  "<script>" +
    "var PERMISSIONS_PER_ROLE = " + JSON.stringify(permissionsPerRole) + ";" +
    "var ROLE_UIDS_PER_NAME = " + JSON.stringify(rolesUidsPerName) + ";" +
  "</script>";

  htmlSource = htmlSource.replace('#permissions', html);
  return htmlSource;
}

function manageAddRole(data)
{
  var conn = fetchConnection();
  var role_stmt = conn.prepareStatement('INSERT INTO role (name, is_system) values (?, ?)', 1);
  role_stmt.setString(1, get_Validated_String(data.role));
  role_stmt.setBoolean(2, false);
  role_stmt.execute();

  //Doesn't seem ideal to retreive the newly added uid, but it does work
  var keys = role_stmt.getGeneratedKeys(); //Get all the auto-generated keys, aka uid
  keys.last(); //Move to last entry
  var role_uid = keys.getInt(1); //Get value in 1st (and only) collumn

  insertRolePermissions(data, role_uid);
}

function manageUpdateRole(data)
{
  Logger.log("Updating " + data.role);
  if(data.role_uid == null)
  {
    Logger.log("Trying to update role, but there's no role_uid provided. Data: " + JSON.stringify(data));
    return;
  }

  var conn = fetchConnection();
  var stmt = conn.prepareStatement('DELETE FROM role_permission WHERE role_uid = ' + get_Validated_Int(data.role_uid));
  stmt.execute();

  insertRolePermissions(data, data.role_uid);
}

function insertRolePermissions(data, role_uid)
{
  Logger.log("insertRolePermissions");
  var conn = fetchConnection();
  var role_permission_stmt = conn.prepareStatement('INSERT INTO role_permission (role_uid, permission_uid) values (?, ?)');
  for(var i = 0; i < data.permissions.length; i++)
  {
    Logger.log("role_uid: " + role_uid + " permission: " + data.permissions[i]);
    role_permission_stmt.setInt(1, role_uid);
    role_permission_stmt.setInt(2, get_Validated_Int(data.permissions[i]));
    role_permission_stmt.addBatch();
  }
  role_permission_stmt.executeBatch();
}