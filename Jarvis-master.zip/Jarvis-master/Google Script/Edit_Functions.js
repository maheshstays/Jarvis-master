/**********************************************************************
This is the main script for creation and editing of database entries 
**********************************************************************/

/**********************************************************************
Create Functions 
**********************************************************************/

function create(uid, studio_data, contact_data, project_data, contract_data) 
{  
  var studio_uid = uid;
  
  if (uid == 0)
    studio_uid = createNewStudio(studio_data, contact_data);
  
  createNewProject(studio_uid, project_data, contract_data);
  
  return studio_uid;
}

function deleteRecord(table, uid)
{ 
  var conn = fetchConnection();
    
  var stmt = conn.createStatement();
  
  stmt.executeUpdate("DELETE FROM " + table + " WHERE uid=" + uid);
}

function createNewStudio(sd, cd)
{
  var conn = fetchConnection();
    
  var studio_stmt = conn.prepareStatement('INSERT INTO studio (name, address_first, address_second, address_city, address_state, address_zipcode, address_country) values (?, ?, ?, ?, ?, ?, ?)', 1);
  
  //var sd = ["1BHK", "2BHK", "3BHK", "4BHK", "2BHK", "3BHK", "4BHK"];
  //var cd = ["1BHK", "2BHK"]; 
  
  //Create Studio
  studio_stmt.setString(1, sd[0].value);
  studio_stmt.setString(2, sd[1].value);
  studio_stmt.setString(3, sd[2].value);
  studio_stmt.setString(4, sd[3].value);
  studio_stmt.setString(5, sd[4].value);
  studio_stmt.setString(6, sd[5].value);
  studio_stmt.setString(7, sd[6].value);
  
  studio_stmt.executeUpdate();
  
  var uid_results = studio_stmt.getGeneratedKeys();
  var uid;
  
  while (uid_results.next())
  {
    uid = uid_results.getInt(1);
  }
  
  //Create Primary Contact
  insertContacts("studio", [{name:cd[0].value, mail:cd[1].value, skype:"tempSkypeId", s_uid:uid, role: { name:"Primary Contact", is_default: false } }]);
  
  //Create Blank Bank
  var bank_stmt = conn.prepareStatement('INSERT INTO bank (name, routing_number, account_number, sort_code, swift_code, beneficiary, tax_id, address_first, address_second, address_city, address_state, address_zipcode, address_country, viability, uid) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
  
  bank_stmt.setString(1, 'No Information');
  bank_stmt.setString(2, '');
  bank_stmt.setString(3, '');
  bank_stmt.setString(4, '');
  bank_stmt.setString(5, '');
  bank_stmt.setString(6, '');
  bank_stmt.setString(7, '');
  bank_stmt.setString(8, '');
  bank_stmt.setString(9, '');
  bank_stmt.setString(10, '');
  bank_stmt.setString(11, '');
  bank_stmt.setString(12, '');
  bank_stmt.setString(13, '');
  bank_stmt.setString(14, '');
  bank_stmt.setInt(15, uid);
  
  bank_stmt.executeUpdate();
  
  return uid;
}

function createNewProject(studio, pd)
{
  var conn = fetchConnection();
  var project_stmt = conn.prepareStatement('INSERT INTO project (title, logo_url, studio, location, status, phase, tier, genres, languages, drive_url, jira_url, playfab_url, discord_url, play_url, kpis_url, build_url, cross_save, recoup_period, game_closure_date) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)', 1);
  
  //Create Studio
  project_stmt.setString(1, pd[0].value);
  project_stmt.setString(2, '');
  project_stmt.setInt(3, studio);
  project_stmt.setString(4, "Montreal");
  project_stmt.setString(5, "On Track");
  project_stmt.setString(6, "Pre-Production");
  project_stmt.setString(7, '2');
  project_stmt.setString(8, '');
  project_stmt.setString(9, '');
  project_stmt.setString(10, '');
  project_stmt.setString(11, '');
  project_stmt.setString(12, '');
  project_stmt.setString(13, '');
  project_stmt.setString(14, '');
  project_stmt.setString(15, '');
  project_stmt.setBoolean(16, false);
  project_stmt.setInt(17, 0);
  project_stmt.setDate(18, get_Validated_JdbcDate("1970-01-01"));

  project_stmt.executeUpdate();
  
  var uid_results = project_stmt.getGeneratedKeys();
  var uid;
  
  while (uid_results.next())
  {
    uid = uid_results.getInt(1);
  }
  
  var contract_stmt = conn.prepareStatement('INSERT INTO contract (advance, development_months, live_ops_cost, live_ops_months, rev_share, expected_revenue_month, uid) values (?, ?, ?, ?, ?, ?, ?)');
  
  //Contracts
  contract_stmt.setInt(1, 0);
  contract_stmt.setString(2, 0);
  contract_stmt.setString(3, 0);
  contract_stmt.setString(4, 0);
  contract_stmt.setString(5, 0);
  contract_stmt.setString(6, 0);
  contract_stmt.setString(7, uid);
  contract_stmt.addBatch();
  
  contract_stmt.executeUpdate();

  createNewMilestones(uid);
}

/**********************************************************************
Edit Functions 
**********************************************************************/

//Create studio entry
function submit_Studio_Info (uid, sd) 
{
  var conn = fetchConnection();
  
  var studio_stmt = conn.prepareStatement('UPDATE studio SET name=?, logo_url=?, address_first=?, address_second=?, address_city=?, address_state=?, address_zipcode=?, address_country=? WHERE uid=?');
  
  //Create Studio
  studio_stmt.setString(1, sd[0].value);
  studio_stmt.setString(2, sd[1].value);
  studio_stmt.setString(3, sd[2].value);
  studio_stmt.setString(4, sd[3].value);
  studio_stmt.setString(5, sd[4].value);
  studio_stmt.setString(6, sd[5].value);
  studio_stmt.setString(7, sd[6].value);
  studio_stmt.setString(8, sd[7].value);
  studio_stmt.setString(9, uid);
  
  studio_stmt.executeUpdate(); 
  
}

//Create bank entry
function submit_Bank_Info (uid, bd) 
{
  var conn = fetchConnection();
  
  var stmt = conn.prepareStatement('UPDATE bank SET name=?, address_first=?, address_second=?, address_city=?, address_state=?, address_zipcode=?, address_country=?, tax_id=?, routing_number=?, account_number=?, beneficiary=?, sort_code=?, swift_code=?, viability=? WHERE uid=?');
  
  //Create Studio
  stmt.setString(1, bd[0].value);
  stmt.setString(2, bd[1].value);
  stmt.setString(3, bd[2].value);
  stmt.setString(4, bd[3].value);
  stmt.setString(5, bd[4].value);
  stmt.setString(6, bd[5].value);
  stmt.setString(7, bd[6].value);
  stmt.setString(8, bd[7].value);
  stmt.setString(9, bd[8].value);
  stmt.setString(10, bd[9].value);
  stmt.setString(11, bd[10].value);
  stmt.setString(12, bd[11].value);
  stmt.setString(13, bd[12].value);
  stmt.setString(14, bd[13].value);
  stmt.setString(15, uid);
  
  stmt.executeUpdate();
}

//Milestones
function submit_Milestone (uid, md) 
{
  var conn = fetchConnection();
  
  var stmt = conn.prepareStatement('UPDATE milestone SET name=?, due_date=?, approval_date=?, payment_amount=?, paid=? WHERE uid=?');
  
  //Create Milestone
  stmt.setString(1, md["name"]);
  stmt.setString(2, valid_Date(md["due_date"]));
  stmt.setString(3, valid_Date(md["app_date"]));
  stmt.setInt(4, valid_Currency(md["payment"]));
  stmt.setString(5, md["payment_status"]);
  stmt.setInt(6, uid);
  
  stmt.executeUpdate();
}

function submit_Add_Milestone (uid, md) 
{
  var conn = fetchConnection();
  
  var stmt = conn.prepareStatement('INSERT INTO milestone SET name=?, project=?, due_date=?, approval_date=?, payment_amount=?, paid=?');
  
  //Create Milestone  
  stmt.setString(1, md[0].value);
  stmt.setString(2, uid);
  stmt.setString(3, md[1].value);
  stmt.setString(4, '-');
  stmt.setInt(5, md[2].value);
  stmt.setString(6, '-');
  
  stmt.executeUpdate();
}

//Deliverables
function submit_Deliverable(uid, dd) 
{
  var conn = fetchConnection();
  
  var stmt = conn.prepareStatement('UPDATE deliverable SET name=?, comment=?, complete=? WHERE uid=?');

  Logger.log(uid);
  Logger.log(dd[0].value);
  Logger.log(dd[1].value);
  Logger.log(dd[2].value);
  
  //Create Milestone
  stmt.setString(1, dd[0].value);
  stmt.setString(2, dd[1].value);
  stmt.setBoolean(3, dd[2].value == "Complete" ? true : false);
  stmt.setInt(4, uid);
  
  stmt.executeUpdate();
}

function submit_Add_Deliverable (uid, dd) 
{
  var conn = fetchConnection();
  
  var stmt = conn.prepareStatement('INSERT INTO deliverable SET name=?, comment=?, complete=?, milestone=?');
  
  //Create Milestone  
  stmt.setString(1, dd[0].value);
  stmt.setString(2, '');
  stmt.setBoolean(3, false);
  stmt.setInt(4, uid);
  
  stmt.executeUpdate();
}

//Approvals
function submit_Approval (uid, ad) 
{
  var conn = fetchConnection();
  
  var stmt = conn.prepareStatement('UPDATE approval SET name=?, title=?, comment=?, complete=? WHERE uid=?');

  //Create Milestone
  stmt.setString(1, ad[0].value);
  stmt.setString(2, ad[1].value);
  stmt.setString(3, ad[2].value);
  stmt.setString(4, ad[3].value);
  stmt.setInt(5, uid);
  
  stmt.executeUpdate();
}

function submit_Add_Approval (uid, ad) 
{
  var conn = fetchConnection();
  
  var stmt = conn.prepareStatement('INSERT INTO approval SET name=?, title=?, comment=?, complete=?, milestone=?');
  
  //Create Milestone  
  stmt.setString(1, ad[0].value);
  stmt.setString(2, ad[1].value);
  stmt.setString(3, '');
  stmt.setString(4, 'Default');
  stmt.setInt(5, uid);
  
  stmt.executeUpdate();
}

//Create game entry
function submit_Game_Panel(uid, gd) 
{
  var conn = fetchConnection();
  
  var game_stmt = conn.prepareStatement('UPDATE project SET title=?, logo_url=?, tier=?, drive_url=?, jira_url=?, playfab_url=?, discord_url=?, build_url=?, recoup_period=?, game_closure_date=? WHERE uid=?');
  
  //Create Studio
  game_stmt.setString(1, get_Validated_String(gd["title"]));
  game_stmt.setString(2, get_Validated_String(gd["logo"]));
  game_stmt.setInt(3, get_Validated_Int(gd["tier"]));
  
  game_stmt.setString(4, get_Validated_String(gd["drive"]));
  game_stmt.setString(5, get_Validated_String(gd["jira"]));
  game_stmt.setString(6, get_Validated_String(gd["playfab"]));
  game_stmt.setString(7, get_Validated_String(gd["discord"]));
  game_stmt.setString(8, get_Validated_String(gd["build"]));
  game_stmt.setInt(9, get_Validated_Int(gd["recoup-period"]));
  game_stmt.setDate(10, get_Validated_JdbcDate(gd["game-closure-date"] ? gd["game-closure-date"] : "1970-01-01"));

  game_stmt.setInt(11, get_Validated_Int(uid));

  game_stmt.executeUpdate();
  
  //Update contract
  var contract_stmt = conn.prepareStatement('UPDATE contract SET rev_share=?, advance=? WHERE uid=?');
  
  var rev_share = get_Validated_Int(gd["rev_share_pl"]) + "/" + get_Validated_Int(gd["rev_share_np"]) + "/" + get_Validated_Int(gd["rev_share_dv"]);
  contract_stmt.setString(1, get_Validated_String(rev_share));
  contract_stmt.setInt(2, get_Validated_Int(gd["advance"]));
  contract_stmt.setInt(3, get_Validated_Int(uid));

  contract_stmt.executeUpdate();  
}

//Create game additional info entry
function submit_Game_Info (uid, contacts) 
{
  updateContactsForSource("project", uid, contacts);
}

//Create studio experience entry
function submit_Studio_Experience (uid, exp)
{
  var conn = fetchConnection();
  
  var stmt = conn.prepareStatement('UPDATE studio_experience SET success_game_name=?, success_game_platform=?, success_game_url=?, success_game_rating=?, games_launched=?, has_f2p_exp=?, has_live_ops_exp=? WHERE studio_uid=?');
  
  //Create Studio
  stmt.setString(1, get_Validated_String(exp["title_name"]));
  stmt.setInt(2, get_Validated_Int(exp["platform"]));
  stmt.setString(3, get_Validated_String(exp["title_url"]));
  stmt.setInt(4, get_Validated_Int(exp["sep_success_game_rating"]));
  stmt.setInt(5, get_Validated_Int(exp["titles_launched"]));
  stmt.setBoolean(6, get_Validated_Boolean(exp["f2p_exp"]));
  stmt.setBoolean(7, get_Validated_Boolean(exp["live_ops_exp"]));
  stmt.setString(8, get_Validated_Int(uid));
  
  stmt.executeUpdate();
}

//Create previous performance entry
function submit_Previous_Performance(uid, pgd)
{
  var conn = fetchConnection();
  
  //var stmt = conn.prepareStatement('UPDATE project SET prev_link=?, prev_trailer=?, google_down=?, google_rating=?, kong_down=?, kong_rating=?, steam_down=?, steam_rating=?, WHERE uid=?');
  var prev_proj_stmt = conn.prepareStatement("UPDATE previous_project SET title=?, reference_url=?, trailer_url=?, built_on_existing_game_code=? WHERE project_id=?");

  //Update previous performance
  prev_proj_stmt.setString(1, get_Validated_String(pgd["title"]));
  prev_proj_stmt.setString(2, get_Validated_String(pgd["reference"]));
  prev_proj_stmt.setString(3, get_Validated_String(pgd["trailer"]));
  prev_proj_stmt.setBoolean(4, get_Validated_Boolean(pgd["built_on_existing_game_code"]));
  prev_proj_stmt.setInt(5, uid);
  prev_proj_stmt.executeUpdate();

  //Gather all the platforms we know of
  var proj_stmt = conn.createStatement();
  var proj_rslt = proj_stmt.executeQuery("SELECT name, uid FROM platform");
  var platforms = [];
  while(proj_rslt.next())
  {
    var curPlatform = {};
    curPlatform.name = proj_rslt.getString("name");
    curPlatform.uid = proj_rslt.getInt("uid");
    platforms.push(curPlatform);
  }

  //For each platform, check if we have some data for it
  for(var i = 0; i < platforms.length; i++)
  {
    var curPlatform = platforms[i];
    var platformData = pgd[curPlatform.name];
    if(platformData == null)
      continue;

    var ppp_stmt = conn.prepareStatement("REPLACE INTO previous_project_platforms (rating, downloads, platform_id, project_id) values (?, ?, ?, ?)");
    ppp_stmt.setInt(1, get_Validated_Int(platformData.rating));
    ppp_stmt.setInt(2, get_Validated_Int(platformData.downloads));
    ppp_stmt.setInt(3, get_Validated_Int(curPlatform.uid));
    ppp_stmt.setInt(4, uid);
    ppp_stmt.execute();
  }

  // Gather all the notable titles we know of
  var prev_proj_nt = conn.createStatement();
  var prev_proj_nt = prev_proj_nt.executeQuery("SELECT * FROM previous_project_notable_titles WHERE project_id=" + uid);

  // Delete everything from the table
  var stmt = conn.createStatement();
  stmt.executeUpdate("TRUNCATE TABLE previous_project_notable_titles");

  // Add every notable titles
  if(pgd["notable_titles"] != null) 
  {
    pgd["notable_titles"].forEach(function(elementToAdd)
    {
      var stmt = conn.prepareStatement("INSERT INTO previous_project_notable_titles (url, project_id) values (?, ?)");
      stmt.setString(1, get_Validated_String(elementToAdd));
      stmt.setInt(2, uid);
      stmt.executeUpdate();
    });
  }
}

function submit_Game_Legal(uid, ld)
{
  var conn = fetchConnection();
  var stmt = conn.prepareStatement("UPDATE legal_information SET is_exclusive=?, publisher=?, ip_holder=?, ntku_pays_free_gold=?, is_publishing_agreement_signed=?, publishing_contract_date=?, is_ntku_dot_net_agreement_signed=?, ntku_dot_net_signature_date=?, has_biz_dev_commision=?, advance_by=? WHERE project_uid=?");

  stmt.setBoolean(1, get_Validated_Boolean(ld["is_exclusive"]));
  stmt.setString(2, get_Validated_String(ld["publisher"]));
  stmt.setString(3, get_Validated_String(ld["ip-holder"]));
  stmt.setBoolean(4, get_Validated_Boolean(ld["nutaku_pays_free_gold"]));
  stmt.setBoolean(5, get_Validated_Boolean(ld["is_publishing_signed"]));
  stmt.setDate(6, get_Validated_JdbcDate(ld["publishing_date"]));
  stmt.setBoolean(7, get_Validated_Boolean(ld["is_nutaku_net_signed"]));
  stmt.setDate(8, get_Validated_JdbcDate(ld["nutaku_net_date"]));
  stmt.setBoolean(9, get_Validated_Boolean(ld["has_bizdev_commission"]));
  stmt.setString(10, get_Validated_String(ld["advance"]));
  stmt.setInt(11, get_Validated_Int(uid));
  stmt.execute();
}

function submit_Game_Technical(uid, td)
{
  var conn = fetchConnection();
  var stmt = conn.prepareStatement("UPDATE project SET platform_types=?, categories=?, genres=?, game_engine=?, ntku_engine_category=?, cross_save=?, requirements_to_launch=?, languages=?, distribution=?, technology=?, app_id=?, monetization=?, adult_content=? WHERE uid=?");
  
  var tables = ["language", "platform_type", "project_category", "project_genre", "game_engine"];
  var projectFieldIndexes = [8, 1, 2, 3, 4];
  for(var i = 0; i < tables.length; i++)
  {
    var curTable = tables[i];
    if(td[curTable] != null)
    {
      var values = td[curTable];
      var ids = tableNamesToIds(curTable, values);
      var value = ids.join(",");
      stmt.setString(projectFieldIndexes[i], get_Validated_String(value));
    }
    else
    {
      stmt.setString(projectFieldIndexes[i], "");
    }
  }

  stmt.setString(5, get_Validated_String(td["ntku_engine_category"]));
  stmt.setBoolean(6, get_Validated_Boolean(td["cross_save"]));
  stmt.setString(7, get_Validated_String(td["requirements_to_launch"]));
  stmt.setString(9, get_Validated_String(td["distribution"]));
  stmt.setString(10, get_Validated_String(td["technology"]));
  stmt.setString(11, get_Validated_String(td["app_id"]));
  stmt.setString(12, get_Validated_String(td["monetization"]));
  stmt.setString(13, get_Validated_String(td["adult_content"]));
  stmt.setInt(14, uid);
  stmt.executeUpdate();
}

function tableNamesToIds(table, names)
{
  var conn = fetchConnection();
  var stmt = conn.createStatement();
  var rslt = stmt.executeQuery("SELECT full_name, uid FROM " + table);
  var response = [];
  while(rslt.next())
  {
    var name = rslt.getString("full_name");
    if(name != null && names.indexOf(name) > -1)
      response.push(rslt.getInt("uid"));
  }

  return response;
}

function get_Validated_Int(value, defaultValue)
{
  if(defaultValue == null)
    defaultValue = 0;
  
  value = parseInt(value);
  if(value == null || isNaN(value))
    return defaultValue;

  return value;
}

function get_Validated_String(value, defaultValue)
{
  if(defaultValue == null)
    defaultValue = "";

  if(value == null)
    value = defaultValue;

  if(typeof value !== 'string')
    value = value.toString();
  
  return value;
}

function get_Validated_Boolean(value, defaultValue)
{
  if(defaultValue == null)
    defaultValue = false;

  if(typeof value === "string")
  {
    var lowerV = value.toLowerCase();
    if(lowerV == "true" || lowerV == "yes")
      value = true;
  }

  if(value == null || typeof value !== "boolean")
    value = defaultValue;
  return value;
}

function get_Validated_JdbcDate(value, defaultValue)
{
  if(defaultValue == null)
    defaultValue = new Date();
  
  var jsDate = null;
  if(typeof value === "string")
  {
    //Expects a yyyy-MM-dd format
    var dateArray = value.split("-");
    if(dateArray == null || dateArray.length < 3)
      jsDate = defaultValue;
    else
      jsDate = new Date(dateArray[0], dateArray[1]-1, parseInt(dateArray[2]) + 1, 0, 0, 0, 0); //-1 because January is 0. I have no idea why I need the +1 for the date though, this seems like a bug in Google's JdbcDate.
  }

  if(typeof value === "date")
    jsDate = value;

  if(jsDate == null)
    jsDate = defaultValue;
  
  return Jdbc.newDate(jsDate.getTime());
}

function valid_Date(value)
{
  if (value == null || value == undefined || value == '')
    return '-';
  else
    return value;
}

function valid_Currency(value)
{
  if (value == null || value == undefined || value == '')
    return 0;
  else
    return value;
}