/** 
 * Google API Documentation: https://developers.google.com/apps-script/advanced/admin-sdk-directory 
 * Google API Reference: https://developers.google.com/admin-sdk/directory/v1/reference/
 **/

function getRoles(tableType, type_uid)
{
  var permissions_table = "";
  var permission_uid = "";
  if(tableType == "project")
  {
    permissions_table = "permission_project";
    permission_uid = "project_uid";
  }
  else if (tableType == "studio")
  {
    permissions_table = "permission_studio";
    permission_uid = "studio_uid";
  }
  else if (tableType == "company")
  {
    permissions_table = "company_studio";
  }
  else
  {
    var err = "getRoles - Unknown tableType '" + tableType + "'. Roles won't be generated for uid: " + type_uid;
    Logger.log(err);
    return err;
  }

  var rolesByUid = getRolesByUid();
  var conn = fetchConnection();
  var permissions_stmt = conn.createStatement();
  var query = 'SELECT * FROM ' + permissions_table;
  if(tableType != "company")
    query += " WHERE " + permission_uid + " = " + type_uid;
  var permissions_rslt = permissions_stmt.executeQuery(query);

  var results = [];
  var domainUsers = null;
  var domainGroups = null;
  while(permissions_rslt.next())
  {
    var result = {};
    var domainEmail = permissions_rslt.getString("domain_email");
    var role_uid = permissions_rslt.getInt("role_uid");
    var isGroup = permissions_rslt.getBoolean("is_group");

    result.roleName = rolesByUid[role_uid].name;
    result.email = domainEmail;
    if(!isGroup)
    {
      if(domainUsers == null)
        domainUsers = getAllUsers();
        
      var domainUser = domainUsers[domainEmail];
      if(domainUser != null)
      {
        if(domainUser.customSchemas != null)
          result.skypeId = domainUser.customSchemas.Skype_ID.Skype_ID;
        else
          result.skypeId = "-";
      
          result.displayName = domainUser.name.fullName;
      }
      else
      {
        result.skypeId = "-";
        result.displayName = "-";
      }
      Logger.log("email: " + domainEmail + " user: " + JSON.stringify(domainUser));
    }
    else
    {
      if(domainGroups == null)
        domainGroups = getAllGroups();
      
      var domainGroup = domainGroups[domainEmail];
      result.skypeId = "-";
      if(domainGroup != null)
        result.displayName = domainGroup.name;
      else
        result.displayName = "-";
    }

    results.push(result);
  }

  return results;
}

function getAllGroups() {
  var allGroups = {};
  var pageToken;
  var page;
  do 
  {
    page = AdminDirectory.Groups.list(
    {
      domain: 'ntku.net',
      maxResults: 200,
      pageToken: pageToken
    });

    var groups = page.groups;
    if(groups != null)
    {
      for(var i = 0; i < groups.length; i++)
      {
        allGroups[groups[i].email] = groups[i];
      }
    }
      
    pageToken = page.nextPageToken;
  } 
  while (pageToken);

  return allGroups;
}

function getAllUsers() {
  var allUsers = {};
  var pageToken;
  var page;
  do 
  {
    page = AdminDirectory.Users.list(
    {
      domain: 'ntku.net',
      orderBy: 'givenName',
      maxResults: 100,
      pageToken: pageToken,
      projection: "custom",
      customFieldMask: "Skype_ID"
    });
    var users = page.users;
    if (users != null) 
    {
      //Doesn't seem to be an array, so we can't use concat
      for (var i = 0; i < users.length; i++) 
      { 
        allUsers[users[i].primaryEmail] = users[i];
        Logger.log("[" + users[i].primaryEmail + "] " + JSON.stringify(users[i]));
      }
    }
    pageToken = page.nextPageToken;
  } 
  while (pageToken);

  return allUsers;
}

function getRolesByUid()
{
  var conn = fetchConnection();
  var role_stmt = conn.createStatement();
  var role_rslt = role_stmt.executeQuery('SELECT * FROM role ORDER BY name');

  var rolesByUid = {};
  while(role_rslt.next())
  {
    var role = {};
    role.uid = role_rslt.getInt("uid");
    role.name = role_rslt.getString("name");
    role.isSystem = role_rslt.getBoolean("is_system");
    rolesByUid[role.uid] = role;
  }

  return rolesByUid;
}

function generateRolesTabsHtml(showUsers, showGroups)
{
  if(showUsers == null)
    showUsers = true;
  if(showGroups == null)
    showGroups = true;

  var rolesByUid = getRolesByUid();

  //Html output
  //Adding roles
  var html =
  "<div class='ui-tabs'>" +
    "<ul>";
  if(showUsers)
    html +=
      "<li><a href='#rp_tab_users'>Users</a></li>";
      
  if(showUsers && showGroups)
    html +=
      "<li class='ui-tabs-spacer'></li>";

  if(showGroups)
    html +=
      "<li><a href='#rp_tab_groups'>Groups</a></li>";
  
  html +=
    "</ul>";

  //Users tab
  if(showUsers)
    html +=
    "<div id='rp_tab_users' class='rp_tab'>" +
      generateRolesAddHtml("users", rolesByUid) +
    "</div>";
  
  if(showGroups)
    html +=
    "<div id='rp_tab_groups' class='rp_tab'>" +
      generateRolesAddHtml("groups", rolesByUid) +
    "</div>";

  html +=
  "</div>";
  return html;
}

function generateRolesAddHtml(type, rolesByUid)
{
  var domainObjs = null;
  var emailProp = null;
  var addContainerId = null;
  var addSelectMailId = null;
  var addButtonId = null;
  var addRolesId = null;
  var currentRolesId = null;
  if(type == "users")
  {
    domainObjs = getAllUsers();
    emailProp = "primaryEmail";
    addContainerId = "rp_users_add_container";
    addSelectMailId = "rp_users_add";
    addButtonId = "rp_add_user_btn";
    addRolesId = "rp_add_user_roles";
    currentRolesId = "rp_current_users_container";
  }
  else if (type == "groups")
  {
    domainObjs = getAllGroups();
    emailProp = "email";
    addContainerId = "rp_groups_add_container";
    addSelectMailId = "rp_groups_add";
    addButtonId = "rp_add_group_btn";
    addRolesId = "rp_add_group_roles";
    currentRolesId = "rp_current_groups_container";
  }
  else
  {
    var err = "generateRolesForPopup - Unknown type '" + type + "'.";
    Logger.log(err);
    return err;
  }

  var html =
  "<div class='rp_row_container " + type + "'>" +
    "<div id='" + addContainerId + "' class='rp_container'>" +
      "<label class='text-field-label' for='" + addSelectMailId + "'>Users</label>" +
      "<div class='ui-editable-selectmenu-container'>" +
        "<select id='" + addSelectMailId + "' class='ui-editable-selectmenu' data-filter='true'>";

  Object.keys(domainObjs).forEach(function(key)
  {
    var curDomainObj = domainObjs[key];
    html +=
          "<option value='" + curDomainObj.id + "'>" + curDomainObj[emailProp] + "</option>";
  });

  html +=
        "</select>" +
      "</div>" +
    "</div>" +
    "<div class='rp_roles_add_container'>";

  html += generateRolesHtml(rolesByUid, addRolesId);
  
  html +=
    "</div>" +
    "<button id='" + addButtonId + "' type='button' class='ui-button rp_add_button'>Add</button>" +
  "</div>" +
  "<div id='" + currentRolesId + "'>" +
  "</div>";
  return html;
}

function generateCurrentRolesHtml(tableType, type, type_uid)
{
  var permissions_table = "";
  var permission_uid = "";
  if(tableType == "project")
  {
    permissions_table = "permission_project";
    permission_uid = "project_uid";
  }
  else if (tableType == "studio")
  {
    permissions_table = "permission_studio";
    permission_uid = "studio_uid";
  }
  else if (tableType == "company")
  {
    permissions_table = "permission_company";
  }
  else
  {
    var err = "generateRolesForPopup - Unknown tableType '" + tableType + "'. Popup's HTML won't be generated.";
    Logger.log(err);
    return err;
  }

  var getGroups = null;  
  var currentRolesId = "";
  if(type == "users")
  {
    getGroups = "false";
    currentRolesId = "rp_current_users_container";
  }
  else if (type == "groups")
  {
    getGroups = "true";
    currentRolesId = "rp_current_groups_container";
  }
  else
  {
    var err = "generateRolesForPopup - Unknown type '" + type + "'. Popup's HTML won't be generated.";
    Logger.log(err);
    return err;
  }

  var rolesByUid = getRolesByUid();
  var conn = fetchConnection();
  var permissions_stmt = conn.createStatement();
  var query = 'SELECT * FROM ' + permissions_table + " WHERE is_group = " + getGroups;
  if(tableType != "company")
    query += " AND " + permission_uid + " = " + type_uid;

  var permissions_rslt = permissions_stmt.executeQuery(query);

  var html = 
  "<div id='" + currentRolesId + "'>" +
    "<div class='rp_current_role_title'>" +
      "<label>Users</label>" +
      "<label>Roles</label>" +
    "</div>" +
    "<div>";
  //Listing current roles
  while(permissions_rslt.next())
  {
    var email = permissions_rslt.getString("domain_email");
    var role_uid = permissions_rslt.getInt("role_uid");
    html +=
      "<div class='rp_current_role_row'>" +
        "<label>" + email + "</label>" +
        "<label>" + rolesByUid[role_uid].name + "</label>" +
        "<button type='button' class='ui-button rp_remove_button' data-email='" + email + "' data-role_uid='" + role_uid + "' data-" + tableType + "_uid='" + type_uid + "'>Remove</button>" +
      "</div>";
  }
  
  html += 
    "</div>" +
  "</div>";

  var data = {};
  data.html = html;
  data.type = type;
  data.tableType = tableType;
  return data;
}

function generateRolesHtml(rolesByUid, controlId)
{
  var html =
  "<label class='text-field-label' for='" + controlId + "'>Roles</label>" +
  "<div class='ui-editable-selectmenu-container'>" +
    "<select id='" + controlId + "' class='ui-editable-selectmenu' data-filter='true'>";

  Object.keys(rolesByUid).forEach(function(key)
  {
    var curRole = rolesByUid[key];
    html +=
      "<option value='" + curRole.uid + "'>" + curRole.name + "</option>";
  });

  html +=
    "</select>" +
  "</div>";

  return html;
}

function submit_Add_Role(data)
{
  var permissions_table = null;
  var tableTypeUid = null;
  if(data.tableType == "project")
  {
    permissions_table = "permission_project";
    tableTypeUid = "project_uid";
  }
  else if (data.tableType == "studio")
  {
    permissions_table = "studio_project";
    tableTypeUid = "studio_uid";
  }
  else if (data.tableType == "company")
  {
    permissions_table = "permission_company";
    tableTypeUid = null;
  }
  else
  {
    var err = "submit_Remove_Role - Unknown tableType '" + data.tableType + "'.";
    Logger.log(err);
    return err;
  }

  var conn = fetchConnection();
  var query = 'INSERT INTO ' + permissions_table + ' (is_group, domain_email, role_uid';
  if(tableTypeUid != null)
    query += ', project_uid';

  query += ') values (?, ?, ?';
  if(tableTypeUid != null)
    query += ', ?';

  query += ')';

  var stmt = conn.prepareStatement(query);

  var type = get_Validated_String(data.type);

  stmt.setBoolean(1, type == "groups");
  stmt.setString(2, get_Validated_String(data.domain_email));
  stmt.setInt(3, get_Validated_Int(data.role_uid));
  if(tableTypeUid != null)
    stmt.setInt(4, get_Validated_Int(data[tableTypeUid]));

  stmt.executeUpdate();

  var sentData = {};
  sentData.type = data.type;
  sentData.tableType = data.tableType;
  return sentData;
}

function submit_Remove_Role(data)
{
  var permissions_table = null;
  var tableTypeUid = null;
  if(data.tableType == "project")
  {
    permissions_table = "permission_project";
    tableTypeUid = "project_uid";
  }
  else if (data.tableType == "studio")
  {
    permissions_table = "permission_studio";
    tableTypeUid = "studio_uid";
  }
  else if (data.tableType == "company")
  {
    permissions_table = "permission_company";
    tableTypeUid = null;
  }
  else
  {
    var err = "submit_Remove_Role - Unknown tableType '" + data.tableType + "'.";
    Logger.log(err);
    return err;
  }

  var conn = fetchConnection();
  var query = 'DELETE FROM ' + permissions_table + ' WHERE ' +
  'domain_email = "' + get_Validated_String(data.email)  + '" AND ' +
  'role_uid = ' + get_Validated_Int(data.role_uid);

  if(tableTypeUid != null)
    query += ' AND ' + tableTypeUid + ' = ' + get_Validated_Int(data[tableTypeUid]);

  var stmt = conn.prepareStatement(query);
  stmt.execute();

  var sentData = {};
  sentData.type = data.type;
  sentData.tableType = data.tableType;
  return sentData;
}