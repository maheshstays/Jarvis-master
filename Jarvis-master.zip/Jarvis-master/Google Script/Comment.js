///////////////////////////////////////
// Functions for the Comments Widget //
///////////////////////////////////////

//-- Global Definitions --//

//Different places where a comment widget can be found on the website. 
var thread_sources = 
{
  project: "project",
  bank: "bank",
  game_information: "game_information",
  previous_performance: "previous_performance",
  technical_information: "technical_information",
  milestones: "milestones",
  studio_experience: "studio_experience",
  legal_information: "legal_information",
  gate1: "gate1"
};

var thread_sources_array = [];
Object.keys(thread_sources).forEach(function(key) {
{
  thread_sources_array.push(key)
}});

thread_sources_array.contains = function(value)
{
  for (var i = 0; i < this.length; i++) 
  {
    if(this[i] == value)
      return true;
  }
  return false;
};

var next_empty_thread_id = -1;

//-- Functions Called From Frontend --//

//Adds a note to the database. If the thread-id doesn't exist, it creates it. Depending on the source
//of the thread, the thread_id will also be updated in the appropriate location in the database.
function addNote(message, user_id, thread_id, source, source_id)
{
  var conn = fetchConnection();
  
  if(thread_id == null || thread_id < 0)
  {
    if(!thread_sources_array.contains(source))
    {
      Logger.log("Source '" + source + "' is not supported. Thread can't be created.");
      return thread_id;
    }
    
    //Create a new thread
    var thread_stmt = conn.prepareStatement("INSERT INTO thread (source) values (?)", 1);
    thread_stmt.setString(1, source);
    thread_stmt.addBatch();
    thread_stmt.executeUpdate();

    //Doesn't seem ideal to retreive the newly added thread_id, but it does work
    var keys = thread_stmt.getGeneratedKeys(); //Get all the auto-generated keys, aka thread ids
    keys.last(); //Move to last entry
    thread_id = keys.getInt(1); //Get value in 1st (and only) collumn
    
    var update_stmt = null;
    switch(source)
    {
      case thread_sources.studio:
        update_stmt = conn.prepareStatement("UPDATE studio SET thread_id = (?) WHERE uid = (?)");
        break;
      case thread_sources.bank:
        update_stmt = conn.prepareStatement("UPDATE bank SET thread_id = (?) WHERE uid = (?)");
        break;
      case thread_sources.game_information:
        update_stmt = conn.prepareStatement("UPDATE project SET game_information_thread_id = (?) WHERE uid = (?)");
        break;
      case thread_sources.previous_performance:
        update_stmt = conn.prepareStatement("UPDATE project SET previous_performance_thread_id = (?) WHERE uid = (?)");
        break;
      case thread_sources.technical_information:
        update_stmt = conn.prepareStatement("UPDATE project SET technical_information_thread_id = (?) WHERE uid = (?)");
        break;
      case thread_sources.milestones:
        update_stmt = conn.prepareStatement("UPDATE project SET milestones_thread_id = (?) WHERE uid = (?)");
        break;
      case thread_sources.studio_experience:
        update_stmt = conn.prepareStatement("UPDATE studio_experience SET thread_id = (?) WHERE studio_uid = (?)");
        break;
      case thread_sources.legal_information:
        update_stmt = conn.prepareStatement("UPDATE legal_information SET thread_id = (?) WHERE project_uid = (?)");
        break;
      case thread_sources.gate1:
        update_stmt = conn.prepareStatement("UPDATE project SET gate1_thread_id = (?) WHERE uid = (?)");
        break;
    }

    update_stmt.setInt(1, thread_id);
    update_stmt.setInt(2, source_id);
    update_stmt.addBatch();
    update_stmt.executeUpdate();
  }

  var note_stmt = conn.prepareStatement("INSERT INTO note (user, thread_id, date, note) values (?, ?, ?, ?)", 1);
  note_stmt.setString(1, user_id);
  note_stmt.setInt(2, thread_id);
  note_stmt.setString(3, getNowDatetimeString());
  note_stmt.setString(4, message);
  note_stmt.addBatch();
  note_stmt.executeUpdate();

  return thread_id;
}

//-- Functions Called From Backend --//

function generateCommentPopupHtml(thread_id, source, source_id)
{
  if(thread_id == null || thread_id == 0)
  {
    thread_id = next_empty_thread_id;
    next_empty_thread_id--;
  }
  
  var conn = fetchConnection();
  var stmt = conn.createStatement();
  var results = stmt.executeQuery("SELECT user, thread_id, date, note FROM note WHERE thread_id = " + thread_id + " ORDER BY date DESC");
  
  var comment_widget_id = "comment_widget-" + thread_id;
  var close_background_id = "close_background-" + thread_id;
  var container_id = "comment_widget_container-" + thread_id;
  var bubble_container_id = "comment_bubble_container-" + thread_id;
  var header_id = "comment_container_header-" + thread_id;
  var header_text_id = "comment_header_text-" + thread_id;
  var scroll_container_id = "comment_scroll_container-" + thread_id;

  var html =  "<div id='" + comment_widget_id + "' class='comment_button' data-thread_id='" + thread_id + "' data-nb_messages='#message_count_data' data-source='" + source + "' data-source_id='" + source_id + "'>";
  html +=       "<div id='" + bubble_container_id + "'>"
  html +=         "<span class='comment_button_bubble'></span>" //Bubble icon
  html +=         "#messages_count_bubble";
  html +=       "</div>"
  
  html +=       "<div id='" + close_background_id + "' class='close_background'></div>"; //Invisible clickable background to close the widget
  html +=       "<div id='" + container_id + "' class='comment_container'>"; //White background
  html +=         "<div id='" + header_id + "' class='comment_header'>"; //Clickable header to add notes
  html +=           "<span id='" + header_text_id + "' class='comment_header_text'><b>+</b> Add New Note</span>"; //Text to the Add Note "button"
  html +=         "</div>";
  html +=         "<div id='" + scroll_container_id + "' class='comment_scroll_container' style='height: 100%'>"; //Container that allows to scroll through messages
  
  //Adding all the messages
  var nbMessages = 0;
  while (results.next()) 
  {
    html +=         "<div class='comment_message_container'>";
    html +=           "<p class='comment_message_text'>" + results.getString(4) + "</p>";
    html +=           "<p class='comment_message_date'>" + getDateMessageFormat(results.getTime(3).getTime()) + "</p>";
    html +=           "<p class='comment_message_author'>" + results.getString(1) + "</p>";
    html +=         "</div>";
    nbMessages++;
  }

  html +=         "</div>";
  html +=       "</div>";
  html +=     "</div>";

  html +=     "<script>";
  html +=       "$(registerCommentWidget($('#" + comment_widget_id + "')));";
  html +=     "</script>";

  //We can't know the result count until we looped through it
  html = html.replace("#messages_count_bubble", (nbMessages > 0) ? "<span class='comment_button_count'>" + nbMessages + "</span>" : "");
  html = html.replace("#message_count_data", nbMessages);
  return html;
}


//-- Utility Functions For This File --//

function getNowDatetimeString()
{
  var now = new Date();
  var yyyy = now.getFullYear();
  var MM = padZeros(now.getMonth() + 1); //+1 because January is 0
  var dd = padZeros(now.getDate());
  var hh = padZeros(now.getHours());
  var mm = padZeros(now.getMinutes());
  var ss = padZeros(now.getSeconds());

  return yyyy + "-" + MM + "-" + dd + " " + hh + ":" + mm + ":" + ss;
}

function getNowDateString()
{
  var now = new Date();
  var yyyy = now.getFullYear();
  var MM = padZeros(now.getMonth() + 1); //+1 because January is 0
  var dd = padZeros(now.getDate());

  return yyyy + "-" + MM + "-" + dd;
}

function getDateMessageFormat(ms)
{
  var date = new Date(ms); //Converting from ms to a javascript Date, because the getDate function returns a google script DateField
  const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "June", "July", "Aug", "Sept", "Oct", "Nov", "Dec"];
  var MM = monthNames[date.getMonth()];
  var dd = date.getDate();
  var yyyy = date.getFullYear();
  var hh = padZeros(date.getHours());
  var mm = padZeros(date.getMinutes());
  var ss = padZeros(date.getSeconds());
  return MM + " " + dd + ", " + yyyy + " at " + hh + ":" + mm + ":" + ss;
}

function padZeros(s)
{
  if (!(typeof s === 'string' || s instanceof String))
    s = s.toString();
  
  if(s == null || s.length == 0)
    return "00";
  if(s.length == 1)
    return "0" + s;
  return s;
}