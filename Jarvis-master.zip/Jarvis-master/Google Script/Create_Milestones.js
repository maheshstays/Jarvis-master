//Create Template Milestones
function createNewMilestones(proj_uid)
{
  var conn = fetchConnection();

  //Milestones 
  
  //Contract Signed Milestone
  var ms_stmt = conn.prepareStatement('INSERT INTO milestone (name, phase, project, due_date, approval_date, payment_amount, paid) values (?, ?, ?, ?, ?, ?, ?)', 1);

  ms_stmt.setString(1, 'Contract Signed');
  ms_stmt.setInt(2, 0);
  ms_stmt.setInt(3, proj_uid);
  ms_stmt.setString(4, '-');
  ms_stmt.setString(5, '-');
  ms_stmt.setInt(6, 0);
  ms_stmt.setString(7, '-');
  ms_stmt.addBatch();
  
  ms_stmt.executeUpdate();
  
  var ms_uid_results = ms_stmt.getGeneratedKeys();
  var ms_uid;
  
  while (ms_uid_results.next())
  {
    ms_uid = ms_uid_results.getInt(1);
  }
  
  //Deliverables
  var del_stmt = conn.prepareStatement('INSERT INTO deliverable (name, complete, milestone) values (?, ?, ?)');

  del_stmt.setString(1, 'Signed Contract');
  del_stmt.setBoolean(2, false);
  del_stmt.setInt(3, ms_uid);
  del_stmt.addBatch();
  
  del_stmt.executeUpdate();
  
  //Approvals
  var app_stmt = conn.prepareStatement('INSERT INTO approval (name, title, complete, milestone) values (?, ?, ?, ?)');

  app_stmt.setString(1, 'Matther Zoern');
  app_stmt.setString(2, 'Production Director');
  app_stmt.setString(3, 'none');
  app_stmt.setInt(4, ms_uid);
  app_stmt.addBatch();
  
  app_stmt.executeUpdate();
  
  //Pre-production
  var ms_stmt = conn.prepareStatement('INSERT INTO milestone (name, phase, project, due_date, approval_date, payment_amount, paid) values (?, ?, ?, ?, ?, ?, ?)', 1);

  ms_stmt.setString(1, 'Pre-Production and Planning');
  ms_stmt.setInt(2, 0);
  ms_stmt.setInt(3, proj_uid);
  ms_stmt.setString(4, '-');
  ms_stmt.setString(5, '-');
  ms_stmt.setInt(6, 0);
  ms_stmt.setString(7, '-');
  ms_stmt.addBatch();
  
  ms_stmt.executeUpdate();
  
  var ms_uid_results = ms_stmt.getGeneratedKeys();
  var ms_uid;
  
  while (ms_uid_results.next())
  {
    ms_uid = ms_uid_results.getInt(1);
  }
  
  //Deliverables
  var del_stmt = conn.prepareStatement('INSERT INTO deliverable (name, complete, milestone) values (?, ?, ?)');

  del_stmt.setString(1, 'Full Production Plan');
  del_stmt.setBoolean(2, false);
  del_stmt.setInt(3, ms_uid);
  del_stmt.addBatch();
  
  del_stmt.executeUpdate();
  
  del_stmt.setString(1, 'Game Design Document (GDD)');
  del_stmt.setBoolean(2, false);
  del_stmt.setInt(3, ms_uid);
  del_stmt.addBatch()
  
  del_stmt.executeUpdate();
  
  del_stmt.setString(1, 'Application Flow');
  del_stmt.setBoolean(2, false);
  del_stmt.setInt(3, ms_uid);
  del_stmt.addBatch()
  
  del_stmt.executeUpdate();
  
  del_stmt.setString(1, 'Feature List');
  del_stmt.setBoolean(2, false);
  del_stmt.setInt(3, ms_uid);
  del_stmt.addBatch()
  
  del_stmt.executeUpdate();
  
  del_stmt.setString(1, 'Technical Design (TDD)');
  del_stmt.setBoolean(2, false);
  del_stmt.setInt(3, ms_uid);
  del_stmt.addBatch()
  
  del_stmt.executeUpdate();
  
  del_stmt.setString(1, 'Creative Design Document (CDD)');
  del_stmt.setBoolean(2, false);
  del_stmt.setInt(3, ms_uid);
  del_stmt.addBatch()
  
  del_stmt.executeUpdate();
  
  del_stmt.setString(1, 'Risk & Mitigations');
  del_stmt.setBoolean(2, false);
  del_stmt.setInt(3, ms_uid);
  del_stmt.addBatch()
  
  del_stmt.executeUpdate();
  
  //Approvals
  var app_stmt = conn.prepareStatement('INSERT INTO approval (name, title, complete, milestone) values (?, ?, ?, ?)');

  app_stmt.setString(1, 'Spencer Druhan');
  app_stmt.setString(2, 'Producer');
  app_stmt.setString(3, 'none');
  app_stmt.setInt(4, ms_uid);
  app_stmt.addBatch();
  
  app_stmt.executeUpdate();
  
  app_stmt.setString(1, 'Michael Di Gregorio Rifiorati');
  app_stmt.setString(2, 'Production Lead');
  app_stmt.setString(3, 'none');
  app_stmt.setInt(4, ms_uid);
  app_stmt.addBatch();
  
  app_stmt.executeUpdate();
  
  app_stmt.setString(1, 'Florin Mirca');
  app_stmt.setString(2, 'Game Design');
  app_stmt.setString(3, 'none');
  app_stmt.setInt(4, ms_uid);
  app_stmt.addBatch();
  
  app_stmt.executeUpdate();
  
  app_stmt.setString(1, 'David Isaila');
  app_stmt.setString(2, 'Quality Assurance');
  app_stmt.setString(3, 'none');
  app_stmt.setInt(4, ms_uid);
  app_stmt.addBatch();
  
  app_stmt.executeUpdate();
  
  app_stmt.setString(1, 'Irina Lang');
  app_stmt.setString(2, 'Localization');
  app_stmt.setString(3, 'none');
  app_stmt.setInt(4, ms_uid);
  app_stmt.addBatch();
  
  app_stmt.executeUpdate();
  
  app_stmt.setString(1, 'Matther Zoern');
  app_stmt.setString(2, 'Production Director');
  app_stmt.setString(3, 'none');
  app_stmt.setInt(4, ms_uid);
  app_stmt.addBatch();
  
  app_stmt.executeUpdate();
  
  app_stmt.setString(1, 'David Lalonde');
  app_stmt.setString(2, 'Director');
  app_stmt.setString(3, 'none');
  app_stmt.setInt(4, ms_uid);
  app_stmt.addBatch();
  
  app_stmt.executeUpdate();
  
  
  //Prototype (Optional)
  var ms_stmt = conn.prepareStatement('INSERT INTO milestone (name, phase, project, due_date, approval_date, payment_amount, paid) values (?, ?, ?, ?, ?, ?, ?)', 1);

  ms_stmt.setString(1, 'Prototype (Optional)');
  ms_stmt.setInt(2, 0);
  ms_stmt.setInt(3, proj_uid);
  ms_stmt.setString(4, '-');
  ms_stmt.setString(5, '-');
  ms_stmt.setInt(6, 0);
  ms_stmt.setString(7, '-');
  ms_stmt.addBatch();
  
  ms_stmt.executeUpdate();
  
  var ms_uid_results = ms_stmt.getGeneratedKeys();
  var ms_uid;
  
  while (ms_uid_results.next())
  {
    ms_uid = ms_uid_results.getInt(1);
  }
  
  //Deliverables
  var del_stmt = conn.prepareStatement('INSERT INTO deliverable (name, complete, milestone) values (?, ?, ?)');

  del_stmt.setString(1, 'Functional Prototype Build');
  del_stmt.setBoolean(2, false);
  del_stmt.setInt(3, ms_uid);
  del_stmt.addBatch();
  
  del_stmt.executeUpdate();
  
  //Approvals
  var app_stmt = conn.prepareStatement('INSERT INTO approval (name, title, complete, milestone) values (?, ?, ?, ?)');

  app_stmt.setString(1, 'Matther Zoern');
  app_stmt.setString(2, 'Production Director');
  app_stmt.setString(3, 'none');
  app_stmt.setInt(4, ms_uid);
  app_stmt.addBatch();
  
  app_stmt.executeUpdate();
  
  app_stmt.setString(1, 'Spencer Druhan');
  app_stmt.setString(2, 'Producer');
  app_stmt.setString(3, 'none');
  app_stmt.setInt(4, ms_uid);
  app_stmt.addBatch();
  
  app_stmt.executeUpdate();
  
  
  //First Playable
  var ms_stmt = conn.prepareStatement('INSERT INTO milestone (name, phase, project, due_date, approval_date, payment_amount, paid) values (?, ?, ?, ?, ?, ?, ?)', 1);

  ms_stmt.setString(1, 'First Playable');
  ms_stmt.setInt(2, 0);
  ms_stmt.setInt(3, proj_uid);
  ms_stmt.setString(4, '-');
  ms_stmt.setString(5, '-');
  ms_stmt.setInt(6, 0);
  ms_stmt.setString(7, '-');
  ms_stmt.addBatch();
  
  ms_stmt.executeUpdate();
  
  var ms_uid_results = ms_stmt.getGeneratedKeys();
  var ms_uid;
  
  while (ms_uid_results.next())
  {
    ms_uid = ms_uid_results.getInt(1);
  }
  
  //Deliverables
  var del_stmt = conn.prepareStatement('INSERT INTO deliverable (name, complete, milestone) values (?, ?, ?)');

  del_stmt.setString(1, 'Functional First Playable Build');
  del_stmt.setBoolean(2, false);
  del_stmt.setInt(3, ms_uid);
  del_stmt.addBatch();
  
  del_stmt.executeUpdate();
  
  del_stmt.setString(1, 'Preliminary Graphics');
  del_stmt.setBoolean(2, false);
  del_stmt.setInt(3, ms_uid);
  del_stmt.addBatch();
  
  del_stmt.executeUpdate();
  
  del_stmt.setString(1, 'Wireframe UI');
  del_stmt.setBoolean(2, false);
  del_stmt.setInt(3, ms_uid);
  del_stmt.addBatch();
  
  del_stmt.executeUpdate();
  
  //Approvals
  var app_stmt = conn.prepareStatement('INSERT INTO approval (name, title, complete, milestone) values (?, ?, ?, ?)');

  app_stmt.setString(1, 'Matther Zoern');
  app_stmt.setString(2, 'Production Director');
  app_stmt.setString(3, 'none');
  app_stmt.setInt(4, ms_uid);
  app_stmt.addBatch();
  
  app_stmt.executeUpdate();
  
  app_stmt.setString(1, 'Spencer Druhan');
  app_stmt.setString(2, 'Producer');
  app_stmt.setString(3, 'none');
  app_stmt.setInt(4, ms_uid);
  app_stmt.addBatch();
  
  app_stmt.executeUpdate();
  
  app_stmt.setString(1, 'David Isaila');
  app_stmt.setString(2, 'Quality Assurance');
  app_stmt.setString(3, 'none');
  app_stmt.setInt(4, ms_uid);
  app_stmt.addBatch();
  
  app_stmt.executeUpdate();
  
  
  //Alpha
  var ms_stmt = conn.prepareStatement('INSERT INTO milestone (name, phase, project, due_date, approval_date, payment_amount, paid) values (?, ?, ?, ?, ?, ?, ?)', 1);

  ms_stmt.setString(1, 'Alpha');
  ms_stmt.setInt(2, 0);
  ms_stmt.setInt(3, proj_uid);
  ms_stmt.setString(4, '-');
  ms_stmt.setString(5, '-');
  ms_stmt.setInt(6, 0);
  ms_stmt.setString(7, '-');
  ms_stmt.addBatch();
  
  ms_stmt.executeUpdate();
  
  var ms_uid_results = ms_stmt.getGeneratedKeys();
  var ms_uid;
  
  while (ms_uid_results.next())
  {
    ms_uid = ms_uid_results.getInt(1);
  }
  
  //Deliverables
  var del_stmt = conn.prepareStatement('INSERT INTO deliverable (name, complete, milestone) values (?, ?, ?)');

  del_stmt.setString(1, 'Platform Functional Build');
  del_stmt.setBoolean(2, false);
  del_stmt.setInt(3, ms_uid);
  del_stmt.addBatch();
  
  del_stmt.executeUpdate();
  
  del_stmt.setString(1, 'No Blocker Severity Bugs');
  del_stmt.setBoolean(2, false);
  del_stmt.setInt(3, ms_uid);
  del_stmt.addBatch();
  
  del_stmt.executeUpdate();
  
  del_stmt.setString(1, 'GUI Complete');
  del_stmt.setBoolean(2, false);
  del_stmt.setInt(3, ms_uid);
  del_stmt.addBatch();
  
  del_stmt.executeUpdate();
  
  del_stmt.setString(1, 'Initial Integration of Metrics System');
  del_stmt.setBoolean(2, false);
  del_stmt.setInt(3, ms_uid);
  del_stmt.addBatch();
  
  del_stmt.executeUpdate();
  
  del_stmt.setString(1, 'Audio Integration');
  del_stmt.setBoolean(2, false);
  del_stmt.setInt(3, ms_uid);
  del_stmt.addBatch();
  
  del_stmt.executeUpdate();
  
  //Approvals
  var app_stmt = conn.prepareStatement('INSERT INTO approval (name, title, complete, milestone) values (?, ?, ?, ?)');

  app_stmt.setString(1, 'Spencer Druhan');
  app_stmt.setString(2, 'Producer');
  app_stmt.setString(3, 'none');
  app_stmt.setInt(4, ms_uid);
  app_stmt.addBatch();
  
  app_stmt.executeUpdate();
  
  app_stmt.setString(1, 'Michael Di Gregorio Rifiorati');
  app_stmt.setString(2, 'Production Lead');
  app_stmt.setString(3, 'none');
  app_stmt.setInt(4, ms_uid);
  app_stmt.addBatch();
  
  app_stmt.executeUpdate();
  
  app_stmt.setString(1, 'Florin Mirca');
  app_stmt.setString(2, 'Game Design');
  app_stmt.setString(3, 'none');
  app_stmt.setInt(4, ms_uid);
  app_stmt.addBatch();
  
  app_stmt.executeUpdate();
  
  app_stmt.setString(1, 'David Lalonde');
  app_stmt.setString(2, 'Director');
  app_stmt.setString(3, 'none');
  app_stmt.setInt(4, ms_uid);
  app_stmt.addBatch();
  
  app_stmt.executeUpdate();
  
  app_stmt.setString(1, 'Irina Lang');
  app_stmt.setString(2, 'Localization');
  app_stmt.setString(3, 'none');
  app_stmt.setInt(4, ms_uid);
  app_stmt.addBatch();
  
  app_stmt.executeUpdate();
  
  app_stmt.setString(1, 'Matthew Zoern');
  app_stmt.setString(2, 'Production Director');
  app_stmt.setString(3, 'none');
  app_stmt.setInt(4, ms_uid);
  app_stmt.addBatch();
  
  app_stmt.executeUpdate();
  
  
  //Beta
  var ms_stmt = conn.prepareStatement('INSERT INTO milestone (name, phase, project, due_date, approval_date, payment_amount, paid) values (?, ?, ?, ?, ?, ?, ?)', 1);

  ms_stmt.setString(1, 'Beta');
  ms_stmt.setInt(2, 0);
  ms_stmt.setInt(3, proj_uid);
  ms_stmt.setString(4, '-');
  ms_stmt.setString(5, '-');
  ms_stmt.setInt(6, 0);
  ms_stmt.setString(7, '-');
  ms_stmt.addBatch();
  
  ms_stmt.executeUpdate();
  
  var ms_uid_results = ms_stmt.getGeneratedKeys();
  var ms_uid;
  
  while (ms_uid_results.next())
  {
    ms_uid = ms_uid_results.getInt(1);
  }
  
  //Deliverables
  var del_stmt = conn.prepareStatement('INSERT INTO deliverable (name, complete, milestone) values (?, ?, ?)');

  del_stmt.setString(1, 'Functional Beta Build');
  del_stmt.setBoolean(2, false);
  del_stmt.setInt(3, ms_uid);
  del_stmt.addBatch();
  
  del_stmt.executeUpdate();
  
  del_stmt.setString(1, 'No Blocker or Critical Bugs');
  del_stmt.setBoolean(2, false);
  del_stmt.setInt(3, ms_uid);
  del_stmt.addBatch();
  
  del_stmt.executeUpdate();
  
  del_stmt.setString(1, 'Localization System');
  del_stmt.setBoolean(2, false);
  del_stmt.setInt(3, ms_uid);
  del_stmt.addBatch();
  
  del_stmt.executeUpdate();
  
  del_stmt.setString(1, 'GUI Complete');
  del_stmt.setBoolean(2, false);
  del_stmt.setInt(3, ms_uid);
  del_stmt.addBatch();
  
  del_stmt.executeUpdate();
  
  del_stmt.setString(1, 'Marketing Materials');
  del_stmt.setBoolean(2, false);
  del_stmt.setInt(3, ms_uid);
  del_stmt.addBatch();
  
  del_stmt.executeUpdate();
  
  del_stmt.setString(1, 'Full Integration of Metrics Hooks');
  del_stmt.setBoolean(2, false);
  del_stmt.setInt(3, ms_uid);
  del_stmt.addBatch();
  
  del_stmt.executeUpdate();
  
  del_stmt.setString(1, '3 Month Post Launch Content');
  del_stmt.setBoolean(2, false);
  del_stmt.setInt(3, ms_uid);
  del_stmt.addBatch();
  
  del_stmt.executeUpdate();
  
  del_stmt.setString(1, 'Cross Promotion Tool Integration');
  del_stmt.setBoolean(2, false);
  del_stmt.setInt(3, ms_uid);
  del_stmt.addBatch();
  
  del_stmt.executeUpdate();
  
  //Approvals
  var app_stmt = conn.prepareStatement('INSERT INTO approval (name, title, complete, milestone) values (?, ?, ?, ?)');

  app_stmt.setString(1, 'Spencer Druhan');
  app_stmt.setString(2, 'Producer');
  app_stmt.setString(3, 'none');
  app_stmt.setInt(4, ms_uid);
  app_stmt.addBatch();
  
  app_stmt.executeUpdate();
  
  app_stmt.setString(1, 'Michael Di Gregorio Rifiorati');
  app_stmt.setString(2, 'Production Lead');
  app_stmt.setString(3, 'none');
  app_stmt.setInt(4, ms_uid);
  app_stmt.addBatch();
  
  app_stmt.executeUpdate();
  
  app_stmt.setString(1, 'Florin Mirca');
  app_stmt.setString(2, 'Game Design');
  app_stmt.setString(3, 'none');
  app_stmt.setInt(4, ms_uid);
  app_stmt.addBatch();
  
  app_stmt.executeUpdate();
  
  app_stmt.setString(1, 'David Lalonde');
  app_stmt.setString(2, 'Director');
  app_stmt.setString(3, 'none');
  app_stmt.setInt(4, ms_uid);
  app_stmt.addBatch();
  
  app_stmt.executeUpdate();
  
  app_stmt.setString(1, 'Irina Lang');
  app_stmt.setString(2, 'Localization');
  app_stmt.setString(3, 'none');
  app_stmt.setInt(4, ms_uid);
  app_stmt.addBatch();
  
  app_stmt.executeUpdate();
  
  app_stmt.setString(1, 'David Isaila');
  app_stmt.setString(2, 'Quality Assurance');
  app_stmt.setString(3, 'none');
  app_stmt.setInt(4, ms_uid);
  app_stmt.addBatch();
  
  app_stmt.executeUpdate()
  
  app_stmt.setString(1, 'Matthew Zoern');
  app_stmt.setString(2, 'Production Director');
  app_stmt.setString(3, 'none');
  app_stmt.setInt(4, ms_uid);
  app_stmt.addBatch();
  
  app_stmt.executeUpdate()
  
  
  //Closed Beta
  var ms_stmt = conn.prepareStatement('INSERT INTO milestone (name, phase, project, due_date, approval_date, payment_amount, paid) values (?, ?, ?, ?, ?, ?, ?)', 1);

  ms_stmt.setString(1, 'Closed Beta');
  ms_stmt.setInt(2, 0);
  ms_stmt.setInt(3, proj_uid);
  ms_stmt.setString(4, '-');
  ms_stmt.setString(5, '-');
  ms_stmt.setInt(6, 0);
  ms_stmt.setString(7, '-');
  ms_stmt.addBatch();
  
  ms_stmt.executeUpdate();
  
  var ms_uid_results = ms_stmt.getGeneratedKeys();
  var ms_uid;
  
  while (ms_uid_results.next())
  {
    ms_uid = ms_uid_results.getInt(1);
  }
  
  //Deliverables
  var del_stmt = conn.prepareStatement('INSERT INTO deliverable (name, complete, milestone) values (?, ?, ?)');

  del_stmt.setString(1, 'No Blocker, Critical or Major Bugs');
  del_stmt.setBoolean(2, false);
  del_stmt.setInt(3, ms_uid);
  del_stmt.addBatch();
  
  del_stmt.executeUpdate();
  
  del_stmt.setString(1, 'Platform Integrated');
  del_stmt.setBoolean(2, false);
  del_stmt.setInt(3, ms_uid);
  del_stmt.addBatch();
  
  del_stmt.executeUpdate();
  
  del_stmt.setString(1, 'Final Audio Integrated');
  del_stmt.setBoolean(2, false);
  del_stmt.setInt(3, ms_uid);
  del_stmt.addBatch();
  
  del_stmt.executeUpdate();
  
  //Approvals
  var app_stmt = conn.prepareStatement('INSERT INTO approval (name, title, complete, milestone) values (?, ?, ?, ?)');

  app_stmt.setString(1, 'Spencer Druhan');
  app_stmt.setString(2, 'Producer');
  app_stmt.setBoolean(3, false);
  app_stmt.setInt(4, ms_uid);
  app_stmt.addBatch();
  
  app_stmt.executeUpdate();
  
  app_stmt.setString(1, 'Michael Di Gregorio Rifiorati');
  app_stmt.setString(2, 'Production Lead');
  app_stmt.setBoolean(3, false);
  app_stmt.setInt(4, ms_uid);
  app_stmt.addBatch();
  
  app_stmt.executeUpdate();
  
  app_stmt.setString(1, 'Florin Mirca');
  app_stmt.setString(2, 'Game Design');
  app_stmt.setBoolean(3, false);
  app_stmt.setInt(4, ms_uid);
  app_stmt.addBatch();
  
  app_stmt.executeUpdate();
  
  app_stmt.setString(1, 'David Lalonde');
  app_stmt.setString(2, 'Director');
  app_stmt.setBoolean(3, false);
  app_stmt.setInt(4, ms_uid);
  app_stmt.addBatch();
  
  app_stmt.executeUpdate();
  
  app_stmt.setString(1, 'Irina Lang');
  app_stmt.setString(2, 'Localization');
  app_stmt.setBoolean(3, false);
  app_stmt.setInt(4, ms_uid);
  app_stmt.addBatch();
  
  app_stmt.executeUpdate();
  
  app_stmt.setString(1, 'David Isaila');
  app_stmt.setString(2, 'Quality Assurance');
  app_stmt.setBoolean(3, false);
  app_stmt.setInt(4, ms_uid);
  app_stmt.addBatch();
  
  app_stmt.executeUpdate()
  
  app_stmt.setString(1, 'Matthew Zoern');
  app_stmt.setString(2, 'Production Director');
  app_stmt.setBoolean(3, false);
  app_stmt.setInt(4, ms_uid);
  app_stmt.addBatch();
  
  app_stmt.executeUpdate()
  
  
  //Launch
  var ms_stmt = conn.prepareStatement('INSERT INTO milestone (name, phase, project, due_date, approval_date, payment_amount, paid) values (?, ?, ?, ?, ?, ?, ?)', 1);

  ms_stmt.setString(1, 'Launch');
  ms_stmt.setInt(2, 0);
  ms_stmt.setInt(3, proj_uid);
  ms_stmt.setString(4, '-');
  ms_stmt.setString(5, '-');
  ms_stmt.setInt(6, 0);
  ms_stmt.setString(7, '-');
  ms_stmt.addBatch();
  
  ms_stmt.executeUpdate();
  
  var ms_uid_results = ms_stmt.getGeneratedKeys();
  var ms_uid;
  
  while (ms_uid_results.next())
  {
    ms_uid = ms_uid_results.getInt(1);
  }
  
  //Deliverables
  var del_stmt = conn.prepareStatement('INSERT INTO deliverable (name, complete, milestone) values (?, ?, ?)');

  del_stmt.setString(1, 'Platform Ready Build');
  del_stmt.setBoolean(2, false);
  del_stmt.setInt(3, ms_uid);
  del_stmt.addBatch();
  
  del_stmt.executeUpdate();
  
  //Approvals
  var app_stmt = conn.prepareStatement('INSERT INTO approval (name, title, complete, milestone) values (?, ?, ?, ?)');

  app_stmt.setString(1, 'Spencer Druhan');
  app_stmt.setString(2, 'Producer');
  app_stmt.setBoolean(3, false);
  app_stmt.setInt(4, ms_uid);
  app_stmt.addBatch();
  
  app_stmt.executeUpdate();
  
  app_stmt.setString(1, 'Michael Di Gregorio Rifiorati');
  app_stmt.setString(2, 'Production Lead');
  app_stmt.setBoolean(3, false);
  app_stmt.setInt(4, ms_uid);
  app_stmt.addBatch();
  
  app_stmt.executeUpdate();
  
  app_stmt.setString(1, 'Florin Mirca');
  app_stmt.setString(2, 'Game Design');
  app_stmt.setBoolean(3, false);
  app_stmt.setInt(4, ms_uid);
  app_stmt.addBatch();
  
  app_stmt.executeUpdate();
  
  app_stmt.setString(1, 'David Lalonde');
  app_stmt.setString(2, 'Director');
  app_stmt.setBoolean(3, false);
  app_stmt.setInt(4, ms_uid);
  app_stmt.addBatch();
  
  app_stmt.executeUpdate();
  
  app_stmt.setString(1, 'Irina Lang');
  app_stmt.setString(2, 'Localization');
  app_stmt.setBoolean(3, false);
  app_stmt.setInt(4, ms_uid);
  app_stmt.addBatch();
  
  app_stmt.executeUpdate();
  
  app_stmt.setString(1, 'David Isaila');
  app_stmt.setString(2, 'Quality Assurance');
  app_stmt.setBoolean(3, false);
  app_stmt.setInt(4, ms_uid);
  app_stmt.addBatch();
  
  app_stmt.executeUpdate()
  
  app_stmt.setString(1, 'Matthew Zoern');
  app_stmt.setString(2, 'Production Director');
  app_stmt.setBoolean(3, false);
  app_stmt.setInt(4, ms_uid);
  app_stmt.addBatch();
  
  app_stmt.executeUpdate()
}