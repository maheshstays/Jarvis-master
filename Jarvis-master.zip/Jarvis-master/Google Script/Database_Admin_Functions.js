/*********************************************************
This is the main script for adminstration of the database
*********************************************************/

var location_enum = ' ENUM("Bucharest", "Montreal")';
var status_enum = ' ENUM("On Track", "Delayed", "At Risk")';
var phase_enum = ' ENUM("Pre-Production", "First Playable", "Alpha", "Beta", "Release", "Release - Live Ops", "Declined", "Cancelled")';

var DB_PROPERTY_KEY = "DB_CONFIG";

//#region Db Properties
function setDbPropertiesToDevNik()
{
  setDbProperty("jdbc:google:mysql://jarvis-260417:us-central1:jarvis/development");
}

function setDbPropertiesToDevDDP()
{
  setDbProperty("jdbc:google:mysql://jarvis-260417:us-central1:jarvis/development_ddp");
}

function setDbPropertiesToTesting()
{
  setDbProperty("jdbc:google:mysql://jarvis-260417:us-central1:jarvis/testing");
}

function setDbPropertiesToDemo()
{
  setDbProperty("jdbc:google:mysql://jarvis-260417:us-central1:jarvis/demo");
}

//Generates and saves the db property with a given dburl
function setDbProperty(dbUrl)
{
  dbObj = {};
  dbObj.username = "root";
  dbObj.password = "phoenix16";
  dbObj.url = dbUrl;

  _properties_handler.setProperty(DB_PROPERTY_KEY, dbObj);
  Logger.log("Set db properties to: " + JSON.stringify(dbObj));
}

//Development utility to see what the db's configurations look like
function logDbProperties()
{
  Logger.log(_properties_handler.getPropertyObj(DB_PROPERTY_KEY));
}
//#endregion

//Creates a connection to the database
function fetchConnection()
{
  var conn = Jdbc.getCloudSqlConnection("jdbc:google:mysql://jarvis-260417:us-central1:jarvis/development_ddp", "root", "phoenix16");
  //var conn = Jdbc.getCloudSqlConnection("jdbc:google:mysql://jarvis-260417:us-central1:jarvis/development_koni", "root", "phoenix16");
  //var conn = Jdbc.getCloudSqlConnection("jdbc:google:mysql://jarvis-260417:us-central1:jarvis/development_nik", "root", "phoenix16");
  
  //var dbObj = _properties_handler.getPropertyObj(DB_PROPERTY_KEY);
  //var conn = Jdbc.getCloudSqlConnection(dbObj.url, dbObj.username, dbObj.password);
  
  return conn;
}

//Admin function to reset the database
function resetDatabase()
{
  deleteDatabase();
  createDatabase();
  populateData();
}

//Admin function to create database tables
function createDatabase()
{
  var conn = fetchConnection();
    
  //Studio information tables
  conn.createStatement().execute('CREATE TABLE IF NOT EXISTS studio (name TINYTEXT, age INT, employees INT, website TINYTEXT, logo_url TINYTEXT, address_first TINYTEXT, address_second TINYTEXT, address_city TINYTEXT, address_state TINYTEXT, address_zipcode TINYTEXT, address_country TINYTEXT, thread_id INT, uid INT NOT NULL AUTO_INCREMENT, PRIMARY KEY(uid));');
  conn.createStatement().execute('CREATE TABLE IF NOT EXISTS bank (name TINYTEXT, routing_number TINYTEXT, account_number TINYTEXT, sort_code TINYTEXT, swift_code TINYTEXT, beneficiary TINYTEXT, tax_id TINYTEXT, address_first TINYTEXT, address_second TINYTEXT, address_city TINYTEXT, address_state TINYTEXT, address_zipcode TINYTEXT, address_country TINYTEXT, viability TEXT, thread_id INT, uid INT NOT NULL, PRIMARY KEY(uid));'); 
  conn.createStatement().execute('CREATE TABLE IF NOT EXISTS studio_experience (success_game_name VARCHAR(128), success_game_platform INT, success_game_url VARCHAR(2000), success_game_rating INT, games_launched INT, has_f2p_exp BIT NOT NULL, has_live_ops_exp BIT NOT NULL, thread_id INT, studio_uid INT NOT NULL, PRIMARY KEY(studio_uid));');
  
  //Project information tables
  conn.createStatement().execute('CREATE TABLE IF NOT EXISTS project (title TINYTEXT, logo_url LONGTEXT, studio INT, location ' + location_enum + ', status' + status_enum + ', phase TINYTEXT, tier INT, platform_types VARCHAR(128), categories VARCHAR(128), genres VARCHAR(128), game_engine VARCHAR(128), ntku_engine_category VARCHAR(256), cross_save BIT NOT NULL, requirements_to_launch VARCHAR(256), languages VARCHAR(255), distribution TINYTEXT, technology TINYTEXT, app_id TINYTEXT, monetization INT, adult_content INT, drive_url TINYTEXT, jira_url TINYTEXT, playfab_url TINYTEXT, discord_url TINYTEXT, play_url TINYTEXT, kpis_url TINYTEXT, build_url TINYTEXT, game_information_thread_id INT, previous_performance_thread_id INT, technical_information_thread_id INT, gate1_thread_id INT, milestones_thread_id INT, recoup_period INT, game_closure_date DATE, uid INT NOT NULL AUTO_INCREMENT, PRIMARY KEY(uid));');
  conn.createStatement().execute('CREATE TABLE IF NOT EXISTS contract (advance INT, development_months TINYTEXT, live_ops_cost TINYTEXT, live_ops_months TINYTEXT, rev_share TINYTEXT, expected_revenue_month TINYTEXT, uid INT NOT NULL, PRIMARY KEY(uid));');
  conn.createStatement().execute('CREATE TABLE IF NOT EXISTS legal_information (thread_id INT, is_exclusive BIT NOT NULL, publisher VARCHAR(128), ip_holder VARCHAR(128), ntku_pays_free_gold BIT NOT NULL, is_publishing_agreement_signed BIT NOT NULL, publishing_contract_date DATE, is_ntku_dot_net_agreement_signed BIT NOT NULL, ntku_dot_net_signature_date DATE, has_biz_dev_commision BIT NOT NULL, advance_by VARCHAR(128), project_uid INT NOT NULL, PRIMARY KEY(project_uid));');

  //Permissions
  conn.createStatement().execute('CREATE TABLE IF NOT EXISTS permission_company (is_group BIT NOT NULL, domain_email VARCHAR(128) NOT NULL, role_uid INT NOT NULL, PRIMARY KEY(domain_email, role_uid));');
  conn.createStatement().execute('CREATE TABLE IF NOT EXISTS permission_studio (is_group BIT NOT NULL, domain_email VARCHAR(128) NOT NULL, role_uid INT NOT NULL, studio_uid INT NOT NULL, PRIMARY KEY(domain_email, role_uid, studio_uid));');
  conn.createStatement().execute('CREATE TABLE IF NOT EXISTS permission_project (is_group BIT NOT NULL, domain_email VARCHAR(128) NOT NULL, role_uid INT NOT NULL, project_uid INT NOT NULL, PRIMARY KEY(domain_email, role_uid, project_uid));');
  conn.createStatement().execute('CREATE TABLE IF NOT EXISTS role (name VARCHAR(128) UNIQUE, is_system BIT NOT NULL, uid INT NOT NULL AUTO_INCREMENT, PRIMARY KEY(uid));');
  conn.createStatement().execute('CREATE TABLE IF NOT EXISTS role_permission (role_uid INT NOT NULL, permission_uid INT NOT NULL, PRIMARY KEY(role_uid, permission_uid));');
  conn.createStatement().execute('CREATE TABLE IF NOT EXISTS permission (name VARCHAR(128), description VARCHAR(1024), uid INT NOT NULL AUTO_INCREMENT, PRIMARY KEY(uid));');

  //Contacts
  conn.createStatement().execute('CREATE TABLE IF NOT EXISTS contact (name VARCHAR(128), email VARCHAR(128), skype VARCHAR(128), uid INT NOT NULL AUTO_INCREMENT, PRIMARY KEY(uid));');
  conn.createStatement().execute('CREATE TABLE IF NOT EXISTS contact_role (name VARCHAR(128) UNIQUE, is_default BIT NOT NULL, uid INT NOT NULL AUTO_INCREMENT, PRIMARY KEY(uid));');
  conn.createStatement().execute('CREATE TABLE IF NOT EXISTS project_info_contact (project_uid INT NOT NULL, role_uid INT NOT NULL, contact_uid INT NOT NULL, PRIMARY KEY(project_uid, role_uid, contact_uid));');
  conn.createStatement().execute('CREATE TABLE IF NOT EXISTS financial_info_contact (studio_uid INT NOT NULL, role_uid INT NOT NULL, contact_uid INT NOT NULL, PRIMARY KEY(studio_uid, role_uid, contact_uid));');
  conn.createStatement().execute('CREATE TABLE IF NOT EXISTS studio_info_contact (studio_uid INT NOT NULL, role_uid INT NOT NULL, contact_uid INT NOT NULL, PRIMARY KEY(studio_uid, role_uid, contact_uid));');
  
  //Static tables
  conn.createStatement().execute('CREATE TABLE IF NOT EXISTS language (full_name VARCHAR(128), small_name VARCHAR(16), uid INT NOT NULL AUTO_INCREMENT, PRIMARY KEY(uid));');
  conn.createStatement().execute('CREATE TABLE IF NOT EXISTS platform_type (full_name VARCHAR(128), small_name VARCHAR(16), uid INT NOT NULL AUTO_INCREMENT, PRIMARY KEY(uid));');
  conn.createStatement().execute('CREATE TABLE IF NOT EXISTS project_category (full_name VARCHAR(128), small_name VARCHAR(16), uid INT NOT NULL AUTO_INCREMENT, PRIMARY KEY(uid));');
  conn.createStatement().execute('CREATE TABLE IF NOT EXISTS project_genre (full_name VARCHAR(128), small_name VARCHAR(16), uid INT NOT NULL AUTO_INCREMENT, PRIMARY KEY(uid));');
  conn.createStatement().execute('CREATE TABLE IF NOT EXISTS game_engine (full_name VARCHAR(128), small_name VARCHAR(16), uid INT NOT NULL AUTO_INCREMENT, PRIMARY KEY(uid));');
  
  //Previous project tables
  conn.createStatement().execute('CREATE TABLE IF NOT EXISTS previous_project (title TINYTEXT, reference_url TINYTEXT, trailer_url TINYTEXT, project_id INT NOT NULL, built_on_existing_game_code BIT NOT NULL, PRIMARY KEY(project_id));');
  conn.createStatement().execute('CREATE TABLE IF NOT EXISTS previous_project_platforms (rating TINYINT, downloads INT, platform_id INT NOT NULL, project_id INT NOT NULL, PRIMARY KEY(platform_id, project_id));');
  conn.createStatement().execute('CREATE TABLE IF NOT EXISTS platform (name TEXT, logo_url TEXT, uid INT NOT NULL AUTO_INCREMENT, PRIMARY KEY(uid));');
  conn.createStatement().execute('CREATE TABLE IF NOT EXISTS previous_project_notable_titles (url TINYTEXT, project_id INT NOT NULL, uid INT NOT NULL AUTO_INCREMENT, PRIMARY KEY(uid), FOREIGN KEY (project_id) REFERENCES previous_project(project_id));');

  //Notes tables
  conn.createStatement().execute('CREATE TABLE IF NOT EXISTS note (user TINYTEXT, thread_id INT, date DATETIME, note LONGTEXT, uid INT NOT NULL AUTO_INCREMENT, PRIMARY KEY(uid));');
  conn.createStatement().execute('CREATE TABLE IF NOT EXISTS thread (source TINYTEXT, uid INT NOT NULL AUTO_INCREMENT, PRIMARY KEY(uid));');

  //Milestone tables
  conn.createStatement().execute('CREATE TABLE IF NOT EXISTS milestone (name TINYTEXT, phase INT, project INT, due_date TINYTEXT, approval_date TINYTEXT, payment_amount INT, paid TINYTEXT, uid INT NOT NULL AUTO_INCREMENT, PRIMARY KEY(uid));');
  conn.createStatement().execute('CREATE TABLE IF NOT EXISTS deliverable (name TINYTEXT, comment TEXT, complete BOOL, milestone INT, uid INT NOT NULL AUTO_INCREMENT, PRIMARY KEY(uid));');
  conn.createStatement().execute('CREATE TABLE IF NOT EXISTS approval (name TINYTEXT, title TINYTEXT, comment TEXT, complete TINYTEXT, milestone INT, uid INT NOT NULL AUTO_INCREMENT, PRIMARY KEY(uid));');

  //Gate tables 
  conn.createStatement().execute('CREATE TABLE IF NOT EXISTS gate (name VARCHAR(128), uid INT NOT NULL AUTO_INCREMENT, PRIMARY KEY(uid));');
  conn.createStatement().execute('CREATE TABLE IF NOT EXISTS gate_feedback_template (role_uid INT, gate_uid INT, uid INT NOT NULL AUTO_INCREMENT, PRIMARY KEY(uid), FOREIGN KEY (role_uid) REFERENCES role(uid), FOREIGN KEY (gate_uid) REFERENCES gate(uid));');
  conn.createStatement().execute('CREATE TABLE IF NOT EXISTS gate_declaration (name VARCHAR(128), color INT, uid INT NOT NULL AUTO_INCREMENT, PRIMARY KEY(uid));');
  conn.createStatement().execute('CREATE TABLE IF NOT EXISTS gate_feedback (feedback VARCHAR(4096), todo VARCHAR(4096), user_domain_email VARCHAR(128), date DATE, template_uid INT, declaration_uid INT, gate_uid INT, project_uid INT, uid INT NOT NULL AUTO_INCREMENT, PRIMARY KEY(uid), FOREIGN KEY (template_uid) REFERENCES gate_feedback_template(uid), FOREIGN KEY (declaration_uid) REFERENCES gate_declaration(uid), FOREIGN KEY (gate_uid) REFERENCES gate(uid), FOREIGN KEY (project_uid) REFERENCES project(uid));');
  
  conn.close();
}

//Admin function deletes the database
function deleteDatabase()
{
  var conn = fetchConnection();

  //Gates
  conn.createStatement().execute('DROP TABLE IF EXISTS gate_feedback');
  conn.createStatement().execute('DROP TABLE IF EXISTS gate_feedback_template');
  conn.createStatement().execute('DROP TABLE IF EXISTS gate_declaration');
  conn.createStatement().execute('DROP TABLE IF EXISTS gate');

  //Studio information tables
  conn.createStatement().execute('DROP TABLE IF EXISTS studio');
  conn.createStatement().execute('DROP TABLE IF EXISTS bank');
  conn.createStatement().execute('DROP TABLE IF EXISTS studio_experience');
  
  //Project information tables
  conn.createStatement().execute('DROP TABLE IF EXISTS project');
  conn.createStatement().execute('DROP TABLE IF EXISTS contract');
  conn.createStatement().execute('DROP TABLE IF EXISTS legal_information');

  //Static tables
  conn.createStatement().execute('DROP TABLE IF EXISTS language');
  conn.createStatement().execute('DROP TABLE IF EXISTS platform_type');
  conn.createStatement().execute('DROP TABLE IF EXISTS project_category');
  conn.createStatement().execute('DROP TABLE IF EXISTS project_genre');
  conn.createStatement().execute('DROP TABLE IF EXISTS game_engine');

  //Permissions
  conn.createStatement().execute('DROP TABLE IF EXISTS permission_company');
  conn.createStatement().execute('DROP TABLE IF EXISTS permission_studio');
  conn.createStatement().execute('DROP TABLE IF EXISTS permission_project');
  conn.createStatement().execute('DROP TABLE IF EXISTS role');
  conn.createStatement().execute('DROP TABLE IF EXISTS role_permission');
  conn.createStatement().execute('DROP TABLE IF EXISTS permission');

  //Contact tables
  conn.createStatement().execute('DROP TABLE IF EXISTS contact');
  conn.createStatement().execute('DROP TABLE IF EXISTS contact_role');
  conn.createStatement().execute('DROP TABLE IF EXISTS project_info_contact');
  conn.createStatement().execute('DROP TABLE IF EXISTS financial_info_contact');
  conn.createStatement().execute('DROP TABLE IF EXISTS studio_info_contact');
  
  //Previous project tables
  conn.createStatement().execute('DROP TABLE IF EXISTS previous_project');
  conn.createStatement().execute('DROP TABLE IF EXISTS previous_project_platforms');
  conn.createStatement().execute('DROP TABLE IF EXISTS platform');
  conn.createStatement().execute('DROP TABLE IF EXISTS previous_project_notable_titles');
  
  //Notes tables
  conn.createStatement().execute('DROP TABLE IF EXISTS note');
  conn.createStatement().execute('DROP TABLE IF EXISTS thread');
  
  //Milestone tables
  conn.createStatement().execute('DROP TABLE IF EXISTS milestone');
  conn.createStatement().execute('DROP TABLE IF EXISTS deliverable');
  conn.createStatement().execute('DROP TABLE IF EXISTS approval');
  
  conn.close();
}

var RANDOM_NAMES = [
  "Kanesha Kime",
  "Johnson Johnosn",
  "Georgia Gallegos",
  "Fonda Feingold",
  "Jenice Juntunen",
  "Myrl Makris",
  "Ruth Rideout",
  "Bethany Bayliss",
  "Lawana Luevano",
  "Lekisha Laprade",
  "Jolynn Jakes",
  "Bennie Ballin",
  "Lois Licea",
  "Guy Garg",
  "Kelle Kissel",
  "Mi Mace",
  "Deirdre Delreal",
  "Agustina Alvear",
  "Garry Glancy",
  "Emerson Eiler",
  "Jame Jurado",
  "Nancy Naughton",
  "Rachal Rhyne",
  "Noe Number",
  "Angelica Atkins",
  "Corene Cicero",
  "Darren Delossantos",
  "Loyce Linzy",
  "Kristin Kauppi",
  "Jeanice Jara",
  "Jina Jefferies",
  "Felton Freeney",
  "Mariella Mariotti",
  "Ceola Cortes",
  "Marx Mcclaren",
  "Bridget Batiste",
  "Masako Mitchell",
  "Deeann Drummer",
  "Annabel Anchondo",
  "Sharmaine Sugden",
  "Jonie Jarnagin",
  "Sunni Stack",
  "Carlton Chavers",
  "Florida Fruchter",
  "Candida Colombo",
  "Bailey Borst",
  "Sharie Samson",
  "Jonelle Joye",
  "Alycia Acevedo",
  "Regenia Roehr"
];

function getRandomName()
{
  var index = parseInt(Math.random() * RANDOM_NAMES.length);
  name = RANDOM_NAMES[index];
  if(name != null)
  {
    RANDOM_NAMES.splice(index, 1);
    return name;
  }
  else
  {
    return "random name index: " + index + " name: " + name;
  }
}

//Admin function to populate data during testing
function populateData()
{
  //Open connections
  conn = fetchConnection();
  conn.setAutoCommit(false);
  
  var sc = 1;
  var pc = 1;
  
  //Create statements
  var studio_stmt = conn.prepareStatement('INSERT INTO studio (name, age, employees, website, logo_url, address_first, address_second, address_city, address_state, address_zipcode, address_country) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
  var bank_stmt = conn.prepareStatement('INSERT INTO bank (name, routing_number, account_number, sort_code, swift_code, beneficiary, tax_id, address_first, address_second, address_city, address_state, address_zipcode, address_country, viability, uid) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
  var std_exp_stmt = conn.prepareStatement('INSERT INTO studio_experience (success_game_name, success_game_platform, success_game_url, success_game_rating, games_launched, has_f2p_exp, has_live_ops_exp, studio_uid) values (?, ?, ?, ?, ?, ?, ?, ?)')

  var previous_project_stmt = conn.prepareStatement('INSERT INTO previous_project (title, reference_url, trailer_url, project_id, built_on_existing_game_code) values (?, ?, ?, ?, ?)');
  var platform_stmt = conn.prepareStatement('INSERT INTO platform (name, logo_url) values (?, ?)');

  var project_stmt = conn.prepareStatement('INSERT INTO project (title, logo_url, studio, location, status, phase, tier, platform_types, categories, genres, game_engine, ntku_engine_category, cross_save, requirements_to_launch, languages, distribution, technology, app_id, monetization, adult_content, drive_url, jira_url, playfab_url, discord_url, play_url, kpis_url, build_url, recoup_period, game_closure_date) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)', 1);
  var contract_stmt = conn.prepareStatement('INSERT INTO contract (advance, development_months, live_ops_cost, live_ops_months, rev_share, expected_revenue_month, uid) values (?, ?, ?, ?, ?, ?, ?)');
  var legal_info_stmt = conn.prepareStatement('INSERT INTO legal_information (is_exclusive, publisher, ip_holder, ntku_pays_free_gold, is_publishing_agreement_signed, publishing_contract_date, is_ntku_dot_net_agreement_signed, ntku_dot_net_signature_date, has_biz_dev_commision, advance_by, project_uid) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)', 1);

  var role_stmt = conn.prepareStatement('INSERT INTO role (name, is_system, uid) values (?, ?, ?)');
  var permission_stmt = conn.prepareStatement('INSERT INTO permission (name, description) values (?, ?)');

  var language_stmt = conn.prepareStatement('INSERT INTO language (full_name, small_name) values (?, ?)');
  var platform_type_stmt = conn.prepareStatement('INSERT INTO platform_type (full_name, small_name) values (?, ?)');
  var project_category_stmt = conn.prepareStatement('INSERT INTO project_category (full_name, small_name) values (?, ?)');
  var project_genre_stmt = conn.prepareStatement('INSERT INTO project_genre (full_name, small_name) values (?, ?)');
  var game_engine_stmt = conn.prepareStatement('INSERT INTO game_engine (full_name, small_name) values (?, ?)');

  var gate_stmt = conn.prepareStatement('INSERT INTO gate (name) values (?)');
  var gate_feedback_template_stmt = conn.prepareStatement('INSERT INTO gate_feedback_template (role_uid, gate_uid) values (?, ?)');
  var gate_declaration = conn.prepareStatement('INSERT INTO gate_declaration (name, color) values (?, ?)');

  //Contact
  insertContactRole({name:"Nutaku Producer", is_default:true});
  insertContactRole({name:"Developer Producer", is_default:true});
  insertContactRole({name:"Nutaku BizDev", is_default:true});

  //Static Tables
  //Languages
  language_stmt.setString(1, "English");
  language_stmt.setString(2, "En");
  language_stmt.addBatch();
  language_stmt.setString(1, "French");
  language_stmt.setString(2, "Fr");
  language_stmt.addBatch();
  language_stmt.setString(1, "Deutch");
  language_stmt.setString(2, "De");
  language_stmt.addBatch();
  language_stmt.setString(1, "Japanese");
  language_stmt.setString(2, "Jp");
  language_stmt.addBatch();
  language_stmt.setString(1, "Spanish");
  language_stmt.setString(2, "Sp");
  language_stmt.addBatch();
  
  //Platform Types
  platform_type_stmt.setString(1, "Browser");
  platform_type_stmt.setString(2, "Browser");
  platform_type_stmt.addBatch();
  platform_type_stmt.setString(1, "Mobile");
  platform_type_stmt.setString(2, "Mobile");
  platform_type_stmt.addBatch();
  platform_type_stmt.setString(1, "Downloadable");
  platform_type_stmt.setString(2, "Dl");
  platform_type_stmt.addBatch();
  platform_type_stmt.setString(1, "Console");
  platform_type_stmt.setString(2, "Console");
  platform_type_stmt.addBatch();
  
  //Project categories
  project_category_stmt.setString(1, "Action");
  project_category_stmt.setString(2, "Action");
  project_category_stmt.addBatch();
  project_category_stmt.setString(1, "Adventure");
  project_category_stmt.setString(2, "Adventure");
  project_category_stmt.addBatch();
  project_category_stmt.setString(1, "Action/Adventure");
  project_category_stmt.setString(2, "Action/Adventure");
  project_category_stmt.addBatch();
  
  //Project genres
  project_genre_stmt.setString(1, "Clicker");
  project_genre_stmt.setString(2, "Clicker");
  project_genre_stmt.addBatch();
  project_genre_stmt.setString(1, "Strategy");
  project_genre_stmt.setString(2, "Strategy");
  project_genre_stmt.addBatch();
  project_genre_stmt.setString(1, "Puzzle");
  project_genre_stmt.setString(2, "Puzzle");
  project_genre_stmt.addBatch();
  project_genre_stmt.setString(1, "Role Playing Game");
  project_genre_stmt.setString(2, "RPG");
  project_genre_stmt.addBatch();
  
  //Game engines
  game_engine_stmt.setString(1, "Unity 3D");
  game_engine_stmt.setString(2, "Unity");
  game_engine_stmt.addBatch();
  game_engine_stmt.setString(1, "Unreal");
  game_engine_stmt.setString(2, "Unreal");
  game_engine_stmt.addBatch();
  game_engine_stmt.setString(1, "Cocos2D");
  game_engine_stmt.setString(2, "Cocos2D");
  game_engine_stmt.addBatch();

  //Platforms
  platform_stmt.setString(1, "GooglePlay");
  platform_stmt.setString(2, "https://nutaku-jarvis.s3.us-east-2.amazonaws.com/images/GooglePlay.png");
  platform_stmt.addBatch();
  platform_stmt.setString(1, "Kongregate");
  platform_stmt.setString(2, "https://nutaku-jarvis.s3.us-east-2.amazonaws.com/images/Kongregate.png");
  platform_stmt.addBatch();
  platform_stmt.setString(1, "Steam");
  platform_stmt.setString(2, "https://nutaku-jarvis.s3.us-east-2.amazonaws.com/images/Steam.png");
  platform_stmt.addBatch();
  
  //Permissions
  role_stmt.setString(1, "System Administrator");
  role_stmt.setBoolean(2, true);
  role_stmt.setInt(3, 1);
  role_stmt.addBatch();
  role_stmt.setString(1, "Owner");
  role_stmt.setBoolean(2, true);
  role_stmt.setInt(3, 2);
  role_stmt.addBatch();
  role_stmt.setString(1, "Publishing Director");
  role_stmt.setBoolean(2, false);
  role_stmt.setInt(3, 3);
  role_stmt.addBatch();
  role_stmt.setString(1, "Producer (Bucharest)");
  role_stmt.setBoolean(2, false);
  role_stmt.setInt(3, 4);
  role_stmt.addBatch();
  role_stmt.setString(1, "Producer (Montreal)");
  role_stmt.setBoolean(2, false);
  role_stmt.setInt(3, 5);
  role_stmt.addBatch();
  role_stmt.setString(1, "Game Designer");
  role_stmt.setBoolean(2, false);
  role_stmt.setInt(3, 6);
  role_stmt.addBatch();
  role_stmt.setString(1, "BizDev");
  role_stmt.setBoolean(2, false);
  role_stmt.setInt(3, 7);
  role_stmt.addBatch();

  permission_stmt.setString(1, "Permission 1");
  permission_stmt.setString(2, "Permission 1 description");
  permission_stmt.addBatch();
  permission_stmt.setString(1, "Permission 2");
  permission_stmt.setString(2, "Permission 2 description");
  permission_stmt.addBatch();
  permission_stmt.setString(1, "Permission 3");
  permission_stmt.setString(2, "Permission 3 description");
  permission_stmt.addBatch();
  permission_stmt.setString(1, "Permission 4");
  permission_stmt.setString(2, "Permission 4 description");
  permission_stmt.addBatch();
  permission_stmt.setString(1, "Permission 5");
  permission_stmt.setString(2, "Permission 5 description");
  permission_stmt.addBatch();

  //Gates
  gate_stmt.setString(1, "Gate 1");
  gate_stmt.addBatch();
  gate_stmt.setString(1, "Gate 2");
  gate_stmt.addBatch();
  gate_stmt.setString(1, "Gate 2.5");
  gate_stmt.addBatch();

  gate_declaration.setString(1, "Feedback Required");
  gate_declaration.setInt(2, 0x060E29);
  gate_declaration.addBatch();
  gate_declaration.setString(1, "More Info Required");
  gate_declaration.setInt(2, 0xEF8A00);
  gate_declaration.addBatch();
  gate_declaration.setString(1, "On Hold");
  gate_declaration.setInt(2, 0x009DFF);
  gate_declaration.addBatch();
  gate_declaration.setString(1, "Approved");
  gate_declaration.setInt(2, 0x00B201);
  gate_declaration.addBatch();
  gate_declaration.setString(1, "Declined");
  gate_declaration.setInt(2, 0xE00000);
  gate_declaration.addBatch();

  //Gate 1
  gate_feedback_template_stmt.setInt(1, 3); //Publishing Director
  gate_feedback_template_stmt.setInt(2, 1);
  gate_feedback_template_stmt.addBatch();
  gate_feedback_template_stmt.setInt(1, 4); //Producer (Bucharest)
  gate_feedback_template_stmt.setInt(2, 1);
  gate_feedback_template_stmt.addBatch();
  gate_feedback_template_stmt.setInt(1, 5); //Producer (Montreal)
  gate_feedback_template_stmt.setInt(2, 1);
  gate_feedback_template_stmt.addBatch();
  gate_feedback_template_stmt.setInt(1, 6); //Game Designer
  gate_feedback_template_stmt.setInt(2, 1);
  gate_feedback_template_stmt.addBatch();
  gate_feedback_template_stmt.setInt(1, 7); //BizDev
  gate_feedback_template_stmt.setInt(2, 1);
  gate_feedback_template_stmt.addBatch();
  //Gate2
  gate_feedback_template_stmt.setInt(1, 3); //Publishing Director
  gate_feedback_template_stmt.setInt(2, 2);
  gate_feedback_template_stmt.addBatch();
  gate_feedback_template_stmt.setInt(1, 4); //Producer (Bucharest)
  gate_feedback_template_stmt.setInt(2, 2);
  gate_feedback_template_stmt.addBatch();
  gate_feedback_template_stmt.setInt(1, 5); //Producer (Montreal)
  gate_feedback_template_stmt.setInt(2, 2);
  gate_feedback_template_stmt.addBatch();
  gate_feedback_template_stmt.setInt(1, 6); //Game Designer
  gate_feedback_template_stmt.setInt(2, 2);
  gate_feedback_template_stmt.addBatch();
  gate_feedback_template_stmt.setInt(1, 7); //BizDev
  gate_feedback_template_stmt.setInt(2, 2);
  gate_feedback_template_stmt.addBatch();
  //Gate 2.5
  gate_feedback_template_stmt.setInt(1, 3); //Publishing Director
  gate_feedback_template_stmt.setInt(2, 3);
  gate_feedback_template_stmt.addBatch();
  gate_feedback_template_stmt.setInt(1, 4); //Producer (Bucharest)
  gate_feedback_template_stmt.setInt(2, 3);
  gate_feedback_template_stmt.addBatch();
  gate_feedback_template_stmt.setInt(1, 5); //Producer (Montreal)
  gate_feedback_template_stmt.setInt(2, 3);
  gate_feedback_template_stmt.addBatch();
  gate_feedback_template_stmt.setInt(1, 6); //Game Designer
  gate_feedback_template_stmt.setInt(2, 3);
  gate_feedback_template_stmt.addBatch();
  gate_feedback_template_stmt.setInt(1, 7); //BizDev
  gate_feedback_template_stmt.setInt(2, 3);
  gate_feedback_template_stmt.addBatch();

  for (var i = 0; i < 2; i++) 
  {
    //Studio
    var studio_name = 'Sample Studio ' + sc;
    var studio_short_name = 'samplestudio' + sc;
    
    studio_stmt.setString(1, studio_name);
    studio_stmt.setInt(2, 0);
    studio_stmt.setInt(3, 0);
    studio_stmt.setString(4, studio_short_name + '@website.com');
    studio_stmt.setString(5, studio_short_name + '@images.com');
    studio_stmt.setString(6, 'Some Street Line 1');
    studio_stmt.setString(7, 'Some Street Line 2');
    studio_stmt.setString(8, 'Cool City');
    studio_stmt.setString(9, 'TX');
    studio_stmt.setString(10, '1234567');
    studio_stmt.setString(11, 'Canada');
    studio_stmt.addBatch();
    
    //Bank
    bank_stmt.setString(1, 'Best Bank CNT');
    bank_stmt.setString(2, '123456789');
    bank_stmt.setString(3, '123456789');
    bank_stmt.setString(4, '00-00-00');
    bank_stmt.setString(5, '123456');
    bank_stmt.setString(6, '');
    bank_stmt.setString(7, '123456-0987');
    bank_stmt.setString(8, 'Bank Street Line 1');
    bank_stmt.setString(9, 'Bank Street Line 2');
    bank_stmt.setString(10, 'Banktown');
    bank_stmt.setString(11, 'TX');
    bank_stmt.setString(12, '098765');
    bank_stmt.setString(13, 'Canada');
    bank_stmt.setString(14, '');
    bank_stmt.setInt(15, sc);
    bank_stmt.addBatch();

    std_exp_stmt.setString(1, "Previous Game " + sc);
    std_exp_stmt.setInt(2, (parseInt(Math.random() * 3)) + 1); //From 1 to 3 inclusively
    std_exp_stmt.setString(3, "https://store.steampowered.com/");
    std_exp_stmt.setInt(4, parseInt(Math.random() * 11)); //From 0 to 10, inclusive
    std_exp_stmt.setInt(5, parseInt(Math.random() * 4));
    std_exp_stmt.setBoolean(6, (Math.random() > 0.5) ? true : false);
    std_exp_stmt.setBoolean(7, (Math.random() > 0.5) ? true : false);
    std_exp_stmt.setInt(8, sc);
    std_exp_stmt.addBatch();
    
    insertContacts("studio", [{name:getRandomName(), email:"temp@email.com", skype:"tempSkypeId", s_uid:sc, role: { name:"Nutaku Producer", is_default: true } }]);
    insertContacts("studio", [{name:getRandomName(), email:"temp@email.com", skype:"tempSkypeId", s_uid:sc, role: { name:"Developer Producer", is_default: true } }]);
    insertContacts("studio", [{name:getRandomName(), email:"temp@email.com", skype:"tempSkypeId", s_uid:sc, role: { name:"Nutaku BizDev", is_default: true } }]);
    
    insertContacts("financial", [{name:getRandomName(), email:"temp@email.com", skype:"tempSkypeId", s_uid:sc, role: { name:"Nutaku Producer", is_default: true } }]);
    insertContacts("financial", [{name:getRandomName(), email:"temp@email.com", skype:"tempSkypeId", s_uid:sc, role: { name:"Developer Producer", is_default: true } }]);
    insertContacts("financial", [{name:getRandomName(), email:"temp@email.com", skype:"tempSkypeId", s_uid:sc, role: { name:"Nutaku BizDev", is_default: true } }]);

    //Randomly generated count
    var count = Math.floor(Math.random() * 3) + 1;
    
    for (var x = 0; x < count; x++) 
    {

      insertContacts("project", [{name:getRandomName(), email:"temp@email.com", skype:"tempSkypeId", s_uid:pc, role: { name:"Nutaku Producer", is_default: true } }]);
      insertContacts("project", [{name:getRandomName(), email:"temp@email.com", skype:"tempSkypeId", s_uid:pc, role: { name:"Developer Producer", is_default: true } }]);
      insertContacts("project", [{name:getRandomName(), email:"temp@email.com", skype:"tempSkypeId", s_uid:pc, role: { name:"Nutaku BizDev", is_default: true } }]);

      //Projects
      project_stmt.setString(1, 'Cool Game' + sc + '-' + x);
      project_stmt.setString(2, 'image@image.com');
      project_stmt.setInt(3, sc);
      project_stmt.setInt(4, Math.floor(Math.random() * 2) + 1);
      project_stmt.setString(5, Math.floor(Math.random() * 3) + 1);
      project_stmt.setString(6, 'Pre-Production');
      project_stmt.setString(7, '1');
      project_stmt.setString(8, '1,2,3');
      project_stmt.setString(9, '1,2');
      project_stmt.setString(10, '2,4');
      project_stmt.setString(11, '1');
      project_stmt.setString(12, 'Previously-launched, with little success');
      project_stmt.setBoolean(13, true);
      project_stmt.setString(14, 'Clone/Reskin+Adultify');
      project_stmt.setString(15, '1,2,4,5'); 
      project_stmt.setString(16, 'Nutaku.net');
      project_stmt.setString(17, 'VR');
      project_stmt.setString(18, '123456789');
      project_stmt.setString(19, '1');
      project_stmt.setString(20, '1');
      project_stmt.setString(21, 'http://drive.host.com');
      project_stmt.setString(22, 'http://jira.host.com');
      project_stmt.setString(23, 'http://playfab.host.com');
      project_stmt.setString(24, 'http://discord.host.com');
      project_stmt.setString(25, 'http://play.host.com');
      project_stmt.setString(26, 'http://kpis.host.com');
      project_stmt.setString(27, 'http://gamebuild.host.com');
      project_stmt.setInt(28, 0);
      project_stmt.setDate(29, get_Validated_JdbcDate("1970-01-01"));
      project_stmt.addBatch();
      
      //Contracts
      contract_stmt.setInt(1, 0);
      contract_stmt.setString(2, 0);
      contract_stmt.setString(3, 0);
      contract_stmt.setString(4, 0);
      contract_stmt.setString(5, 0);
      contract_stmt.setString(6, 0);
      contract_stmt.setString(7, pc);
      contract_stmt.addBatch();

      //Legal information
      legal_info_stmt.setBoolean(1, Math.random() > 0.5);
      legal_info_stmt.setString(2, "Temp publisher");
      legal_info_stmt.setString(3, "Temp IP Holder Name");
      legal_info_stmt.setBoolean(4, Math.random() > 0.5);
      legal_info_stmt.setBoolean(5, Math.random() > 0.5);
      legal_info_stmt.setDate(6, get_Validated_JdbcDate());
      legal_info_stmt.setBoolean(7, Math.random() > 0.5);
      legal_info_stmt.setDate(8, get_Validated_JdbcDate());
      legal_info_stmt.setBoolean(9, Math.random() > 0.5);
      legal_info_stmt.setString(10, "Temp advance by");
      legal_info_stmt.setInt(11, pc);
      legal_info_stmt.addBatch();

      //Previous project
      previous_project_stmt.setString(1, "Previous Project " + pc);
      previous_project_stmt.setString(2, "https://nutaku.net");
      previous_project_stmt.setString(3, "https://nutaku.net");
      previous_project_stmt.setInt(4, pc);
      previous_project_stmt.setBoolean(5, false);
      previous_project_stmt.addBatch();
      
      //Increment project count
      pc++
    }
      
    //Increment studio count
    sc++;    
  }
  
  //Execute statements
  studio_stmt.executeBatch();
  bank_stmt.executeBatch();
  std_exp_stmt.executeBatch();

  platform_stmt.executeBatch();
  
  project_stmt.executeBatch();
  contract_stmt.executeBatch();
  previous_project_stmt.executeBatch();

  legal_info_stmt.executeBatch();

  role_stmt.executeBatch();
  permission_stmt.executeBatch();

  language_stmt.executeBatch();
  platform_type_stmt.executeBatch();
  project_category_stmt.executeBatch();
  project_genre_stmt.executeBatch();
  game_engine_stmt.executeBatch();
  
  gate_stmt.executeBatch();
  gate_declaration.executeBatch();
  gate_feedback_template_stmt.executeBatch();

  var uid_results = project_stmt.getGeneratedKeys();
  
  while (uid_results.next())
  {
    var uid = uid_results.getInt(1);
    
    createNewMilestones(uid);
  }
  
  //Close connection
  conn.commit();
  conn.close();
}

//Logs any SQL table
function logTable()
{
  //Get HTML template, parse to XML, connect to database
  var conn = fetchConnection();
  
  //Create SQL statement
  var stmt = conn.createStatement();
  stmt.setMaxRows(1000);
  
  //SQL Query
  Logger.log("## Previous Project ##")
  var results = stmt.executeQuery('SELECT * FROM previous_project');
  var numCols = results.getMetaData().getColumnCount();
  while (results.next()) 
  {     
    var rowString = '';
    for (var col = 0; col < numCols; col++) 
    {
      rowString += results.getString(col + 1) + '\t';
    }
    
    Logger.log(rowString);
  }

  Logger.log("## Done logging table ##");
}