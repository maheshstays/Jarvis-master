/*********************************************************
This is the main parsing script. 
*********************************************************/

/** Entry Point Function **/
function doGet(e) 
{ 
  var view;
  var key = "#main-table-position";
  
  //Get the view param from the URL
  if (e && e.parameters)
  {
    view = e.parameters.view;
    
    if (view == '' || view == undefined)
      view = 'studio';
  }
    view = 'studio';
  
  //Create HTML from template
  var html = HtmlService.createTemplateFromFile("main_View").evaluate().getContent();
  var css_Main = HtmlService.createTemplateFromFile("css_Main").evaluate().getContent();
  html = html.replace("#css_main", css_Main);
  var css_controls = HtmlService.createTemplateFromFile("css_Controls").evaluate().getContent();
  html = html.replace("#css_controls", css_controls);
  var css_CommentWidget = HtmlService.createTemplateFromFile("css_Comment_Widget").evaluate().getContent();
  html = html.replace("#css_comment_widget", css_CommentWidget);
  var css_popups = HtmlService.createTemplateFromFile("css_Popups").evaluate().getContent();
  html = html.replace("#css_popups", css_popups);
  var css_manage = HtmlService.createTemplateFromFile("css_Manage").evaluate().getContent();
  html = html.replace("#css_manage", css_manage);
  var css_loading_icon = HtmlService.createTemplateFromFile("css_Loading_Icon").evaluate().getContent();
  html = html.replace("#css_loading_icon", css_loading_icon);
  var css_project_gate = HtmlService.createTemplateFromFile("css_Project_Gate").evaluate().getContent();
  html = html.replace("#css_project_gate", css_project_gate);
  var css_editable_select = HtmlService.createTemplateFromFile("css_Frontend_JQuery_Editable_Select").evaluate().getContent();
  html = html.replace("#css_frontend_editable_select", css_editable_select);

  var js_comment_widget = HtmlService.createTemplateFromFile("js_Frontend_Comment_Widget").evaluate().getContent();
  html = html.replace("#js_frontend_comment_widget", js_comment_widget);
  var js_editable_select = HtmlService.createTemplateFromFile("js_Frontend_JQuery_Editable_Select").evaluate().getContent();
  html = html.replace("#js_frontend_editable_select", js_editable_select);
  var js_popups = HtmlService.createTemplateFromFile("js_Frontend_Popups").evaluate().getContent();
  html = html.replace("#js_frontend_popups", js_popups);

  var html_popups = HtmlService.createTemplateFromFile("html_Popups").evaluate().getContent();
  html = html.replace("#popups_html", html_popups);
  html = html.replace("#permissions_popup", generateRolesTabsHtml());

  html = html.replace("#previous_performance_popup", generatePreviousPerformancePopup());
  html = html.replace("#technical_information_popup", generateTechnicalInformationPopup());
  html = html.replace("#legal_information_popup", generateLegalInformationPopup());
  
  html = html.replace("#studio_experience_popup", generateStudioExperiencePopup());

  ///////////////
  //TODO: Remove this! Temporary to easily test the popup threads
  html = html.replace("#test_popup_comment_button", generateCommentPopupHtml(6, "example_popup", -1));
  ///////////////

  //Determine which parse to use
  if (view == 'project')
  {
    html = html.replace(key, generateProjectList());
  }
  else if (view == 'studio')
  {
    html = html.replace(key, generateMasterStudioList());
  }
  else if (view == 'dashboard')
  {
    html = html.replace(key, generateDashboard());
  }
  else if (view == 'manage')
  {
    html = html.replace(key, generateManageView());
  }
  else
  {
    html = html.replace(key, generateMasterStudioList()); 
  }
  
  return HtmlService.createHtmlOutput(html);
}

/** Change Views (Re-Entry Point Function) **/
function parseHTML(view, select, search)
{
  var html; 
  
  if (view == 'project')
    html = generateProjectList(select, search);
  else if (view == 'studio')
    html = generateMasterStudioList();
  else if (view == 'studio_detail')
    html = generateStudioDetail(select);
  else if (view == 'project_detail')
    html = generateProjectDetail(select);
  else if (view == 'dashboard')
    html = generateDashboard();
  else if (view == 'create_project')
    html = createProject();
  else if (view == 'manage')
    html = generateManageView();
  else
    html = generateMasterStudioList();
  
  return html;
}

//Studio view parsing functions
function parseStudioRow(uid, name, logo_url, city, country, contact_name, contact_email) 
{
  var html = HtmlService.createTemplateFromFile("studio_StudioTable").evaluate().getContent();
  
  html = html.replace('#datatag', parseDataUID(uid));
  html = html.replace('#name', name);
  html = html.replace('#city', city);
  html = html.replace('#country', country);
  html = html.replace('#contact-name', contact_name);
  html = html.replace('#contact-email', contact_email);
  html = html.replace('#id', name);
  html = html.replace('#games_row', uid + '_row');
  html = html.replace('#games_row_id', uid + '_row');

  html = html.replace('#game_css', generateStudioImageCSS(uid, logo_url));
  html = html.replace("#studio_id", uid);

  return html;
}

function generateStudioImageCSS(uid, logo_url)
{
  var css = HtmlService.createTemplateFromFile("css_Studio_Logo").evaluate().getContent();
  css = css.replace("#studio_id", uid);
  css = css.replace("#studio_logo_url", logo_url);
  return css;
}

function parseProjectRow(uid, title, logo, producer, location, status, phase, tier, is_last)
{
  var html = HtmlService.createTemplateFromFile("detail_GameRow").evaluate().getContent();
  
  /*
  switch (status)
  {
    case 'On Track':
      html = html.replace('#status', 'icon-status-go');
      break;
      
    case 'Delayed':
      html = html.replace('#status', 'icon-status-hold');
      break;
      
    case 'At Risk':
      html = html.replace('#status', 'icon-status-stop');
      break;
      
    default:
      html = html.replace('#status', 'icon-status-none');
      break;
  }
  */
  
  html = html.replace('#data_uid', uid);
  html = html.replace('#title', title);
  html = html.replace('#producer', producer);
  html = html.replace('#location', location);
  html = html.replace('#tier', "Tier " + tier);
  html = html.replace('#phase', phase);
  html = html.replace('#game_id', uid);
  html = html.replace("#game_css", generateGameImageCSS(uid, logo));
  html = html.replace(/#is_last/g, is_last ? "last_row" : ""); //Replacing all instsances of #is_last with regex
  
  return html;
}

function generateGameImageCSS(uid, logo_url)
{
  var css = HtmlService.createTemplateFromFile("css_Game_Logo").evaluate().getContent();
  css = css.replace("#game_id", uid);
  css = css.replace("#game_logo_url", logo_url);
  return css;
}

//Detail parsing functions
function parseDeveloperCatalogue(ProjectHTML, uid)
{
  var type = 'catalogue';
  var html = HtmlService.createTemplateFromFile("detail_CatalogueTable").evaluate().getContent();
  
  html = html.replace('#projects', ProjectHTML);
  
  //Notes section
  html = html.replace('#note-type', type);
  html = html.replace('#note-id', uid);
  
  html = html.replace('#notes', parseNotesTable(type, uid));
  
  return html;
}

function parseGameInformation(uid, title, genre, investment, revshare, location, producer, devproducer, busdev, status, phase, tier, platforms, languages, drivelink, jiralink, playfablink, discordlink, playnowlink, kpislink)
{
  var type = 'project_information';
  var html = HtmlService.createTemplateFromFile("detail_GameInformation").evaluate().getContent();
  
  switch (status)
  {
    case 'On Track':
      html = html.replace('#status_table', 'detail-status-table-go');
      break;
      
    case 'Delayed':
      html = html.replace('#status_table', 'detail-status-table-hold');
      break;
      
    case 'At Risk':
      html = html.replace('#status_table', 'detail-status-table-stop');
      break;
      
    default:
      html = html.replace('#status_table', 'detail-status-table-none');
      break;
  }
  
  html = html.replace('#gametitle', title);
  html = html.replace('#genre', genre);
  html = html.replace('#investment', investment);
  html = html.replace('#revshare', revshare);
  
  html = html.replace('#location', location);
  html = html.replace('#producer', producer);
  html = html.replace('#devproducer', devproducer);
  html = html.replace('#busdev', busdev);
  html = html.replace('#platforms', platforms);
  html = html.replace('#languages', languages);
  
  html = html.replace('#drivelink', drivelink);
  html = html.replace('#jiralink', jiralink);
  html = html.replace('#playfablink', playfablink);
  html = html.replace('#discordlink', discordlink);
  
  html = html.replace('#playnowlink', playnowlink);
  html = html.replace('#kpislink', kpislink);
  
  html = html.replace('#phase', phase);
  html = html.replace('#status', status);
  html = html.replace('#tier', tier);
  
  //Notes section
  html = html.replace('#note-type', type);
  html = html.replace('#note-id', uid);
  
  html = html.replace('#notes', parseNotesTable(type, uid));
  
  return html;
}

//Converts a string such as 123456 to $1,234. The 56 cents are cut from the string on purpose, though we still keep them in the database.
function intToCurrencyString(value)
{
  if(value == null || !isInt(value))
    value = 0;
  
  if(value == 0)
    return "$0";
  
  var str = "";
  var strInt = value.toString();
  var count = 0;
  for (var i = strInt.length - 3; i >= 0; i--) //-3 because we don't want the cents in our string
  {

    //Add thousands separator every loops
    if(count % 3 == 0 && count != 0)
      str = strInt[i] + "," + str;
    else
      str = strInt[i] + str;

    count++;
  }

  return "$" + str;
}

function parseMilestoneTable(uid)
{
  var type = 'milestone';
  var html = HtmlService.createTemplateFromFile("detail_MilestoneTable").evaluate().getContent();
  
  //Notes section
  html = html.replace('#note-type', type);
  html = html.replace('#note-id', uid);
  
  html = html.replace('#notes', parseNotesTable(type, uid));
  
  return html;
}

//Project view parsing functions
function parseProjectTable(uid, title, studio, producer, location, status, phase, tier)
{
  var type = 'project';
  var html = HtmlService.createTemplateFromFile("project_ProjectTable").evaluate().getContent();
  
  switch (status)
  {
    case 'On Track':
      html = html.replace('#status', 'icon-status-go');
      break;
      
    case 'Delayed':
      html = html.replace('#status', 'icon-status-hold');
      break;
      
    case 'At Risk':
      html = html.replace('#status', 'icon-status-stop');
      break;
      
    default:
      html = html.replace('#status', 'icon-status-none');
      break;
  }
  
  html = html.replace('#datatag', parseDataUID(uid));
  html = html.replace('#title', title);
  html = html.replace('#producer', producer);
  html = html.replace('#location', location);
  html = html.replace('#tier', "Tier " + tier);
  html = html.replace('#phase', phase);
  html = html.replace('#studio', studio);
  
  html = html.replace('#id', uid);
  
  return html;
}

//Detail view parsing functions
//function parseStudioDetailRow(name, address, city, state, zipcode, country, primary_contact, primary_email, uid)
//{
//  var type = 'studio';
//  var html = HtmlService.createTemplateFromFile("detail_StudioTable").evaluate().getContent();
//  
//  html = html.replace('#name', name);
//  html = html.replace('#address', address);
//  html = html.replace('#city', city);
//  html = html.replace('#state', state);
//  html = html.replace('#zipcode', zipcode);
//  html = html.replace('#country', country);
//  
//  html = html.replace('#primary_contact', primary_contact);
//  html = html.replace('#primary_email', primary_email);
//  
//  html = html.replace('#id', uid);
//  html = html.replace('#uid', uid);
//  html = html.replace('#address-uid', uid);
//  
//  //Notes section
//  html = html.replace('#note-type', type);
//  html = html.replace('#note-id', uid);
//  
//  html = html.replace('#notes', parseNotesTable(type, uid));
//  
//  return html;
//}

function parseStudioBankRow(name, account, routing, address, city, state, zipcode, country, sort, beneficiary, swift, taxid, uid)
{
  var type = 'bank';
  var html = HtmlService.createTemplateFromFile("detail_BankTable").evaluate().getContent();
  
  html = html.replace('#bankname', name);
  html = html.replace('#account', account);
  html = html.replace('#routing', routing);
  html = html.replace('#address', address);
  html = html.replace('#city', city);
  html = html.replace('#state', state);
  html = html.replace('#zipcode', zipcode);
  html = html.replace('#country', country);
  
  html = html.replace('#sort', sort);
  html = html.replace('#beneficiary', beneficiary);
  html = html.replace('#swift', swift);
  html = html.replace('#taxid', taxid);
  
  //Notes section
  html = html.replace('#note-type', type);
  html = html.replace('#note-id', uid);
  
  html = html.replace('#notes', parseNotesTable(type, uid));
  
  return html;
}

function parseAddress(description, first, second, city, state, zipcode, country, uid)
{
  var html = HtmlService.createTemplateFromFile("detail_exp_Address").evaluate().getContent();
  
  html = html.replace('#description', description);
  html = html.replace('#first', first);
  html = html.replace('#second', second);
  html = html.replace('#city', city);
  html = html.replace('#state', state);
  html = html.replace('#zipcode', zipcode);
  html = html.replace('#country', country);
  html = html.replace('#uid', uid);
  html = html.replace('#uid', uid);
  html = html.replace('#uid', uid);
  html = html.replace('#fullid', 'address-table-' + uid);
  
  return html;
}

function parseNotesTable(type, id)
{
  var conn = fetchConnection();
  var stmt = conn.createStatement();
  var results = stmt.executeQuery('SELECT user, date, note, uid FROM note WHERE type =' + qstr(type) + ' AND id =' + qstr(id));
  
  var html = '<table>';
  
  while (results.next())
  {
    html += '<tr><td><b>[' + results.getString('user') + ']</b></td><td><b>[' + results.getString('date') + ']</b></td><td>' + results.getString('note') + '</td></tr>';
  }
  
  html += '</table>';
  
  return html;
}

//Result logging support function
function logResults(results)
{
  var numCols = results.getMetaData().getColumnCount();
  var rowString = '';
  
  for (var col = 0; col < numCols; col++) 
  {
    rowString += results.getString(col + 1) + '\t';
  }
    
  Logger.log(rowString);
}

//Function to search for specific html elements
function getElement(element, id) 
{  
  var children = element.getDescendants();
  
  for(i in children) 
  {
    var item = children[i].asElement();
    
    if(item != null) 
    {
      var eid = item.getAttribute('id');
      
      if(eid != null && eid.getValue() == id) 
       return item;    
    }
  }
}

//Support functions
function parseURL(view)
{
  var url = '\'' + ScriptApp.getService().getUrl() + '?view=' + view + '\'';
  
  return url;
}

function parseDataUID(uid)
{
  return "data-uid=" + qstr(uid);
}

function parseAURL(target)
{
  var url = '<a href=' + parseURL(target) + ' target=\'_self\'>' + target + '</a>';
  
  url = url.replace('#target', target);
  
  return url;
}

function qstr(string)
{
  return '\'' + string + '\''; 
}

function pad2(number)
{   
  if (number.length < 2) 
    return '0' + number;
  else
    return number;
}

function now()
{
  var dt = new Date();
  var dtstring = dt.getFullYear() + '-' + pad2(dt.getMonth()+1) + '-' + pad2(dt.getDate()) + ' ' + pad2(dt.getHours()) + ':' + pad2(dt.getMinutes()) + ':' + pad2(dt.getSeconds());
  
  return dtstring;
}

//Data manipulation functions
function deleteEntry(table, id)
{
  var conn = fetchConnection();
  var stmt = conn.createStatement();
  
  //SQL Query
  var results = stmt.executeUpdate('DELETE FROM '+ table + ' WHERE uid=' + qstr(id));
}

function addAddress(params)
{  
  var conn = Jdbc.getCloudSqlConnection(dburl, username, password);
  var stmt = conn.prepareStatement('INSERT INTO address ' + '(studio, description, first, second, city, state, zipcode, country) values (?, ?, ?, ?, ?, ?, ?, ?)');
  
  stmt.setString(1, params[0]);
  stmt.setString(2, params[1]);
  stmt.setString(3, params[2]);
  stmt.setString(4, params[3]);
  stmt.setString(5, params[4]);
  stmt.setString(6, params[5]);
  stmt.setString(7, params[6]);
  stmt.setString(8, params[7]);
  
  stmt.executeUpdate();
}

function addTableRow(table, params)
{
  var conn = fetchConnection();
  var stmt = conn.createStatement();
  var cols = '';
    
  for (i = 0; i < params.length; i++)
  {
    cols += qstr(params[i]);
    
    if ((i + 1) < params.length)
      cols += ', ';
  }
  
  //SQL Query
  stmt.executeUpdate('INSERT INTO ' + table + ' VALUES ( ' + cols + ' )');
}

function findInGroups(group_email)
{
  var groups = GroupsApp.getGroups();
  var result = false;
  
  for (var i = 0; i < groups.length; i++)
  {
    if (groups[i].getEmail() == group_email)
      result = true;
  }
  
  return result;
}

function isInt(value) {
  return !isNaN(value) && 
         parseInt(Number(value)) == value && 
         !isNaN(parseInt(value, 10));
}