function generateDashboard(select) 
{
  //Search Params
  var maxStudios = 200;
  var maxProjects = 10;
  var maxCols = 1;
  
  var conn = fetchConnection();
  
  //Create SQL statement
  var stmt = conn.createStatement();
  stmt.setMaxRows(maxStudios);
  
  //SQL Query
  var proj_results;
  
  var b_select = select != null && select != 0 && select != '';
  
  var stmt_text = 'SELECT title, logo_url, studio, location, status, phase, tier, uid FROM project';
  
  var html = '';
  
  var base_html = HtmlService.createTemplateFromFile("dashboard_View").evaluate().getContent();
  
  if (b_select)
  {
    stmt_text += ' WHERE';
    
    if (b_select)
     stmt_text += ' phase =' + select;
  }
  
  proj_results = stmt.executeQuery(stmt_text);
  
  var colorFlag = true;
  
  while (proj_results.next()) 
  {
    var add = true;
    var studio_stmt = conn.createStatement();
    var prod_stmt = conn.createStatement()
    studio_stmt.setMaxRows(1);
    
    var uid = proj_results.getInt('uid');
    var title = proj_results.getString('title');
    var logo = proj_results.getString('logo_url');
    var location = proj_results.getString('location');
    var status = proj_results.getString('status');
    var phase = proj_results.getString('phase');
    var tier = proj_results.getString('tier');
    var is_last = proj_results.isLast();
    
    var studio = proj_results.getString('studio');
    var studio_name;
    
    var studio_results = studio_stmt.executeQuery('SELECT name FROM studio WHERE uid=' + studio);
    
    while (studio_results.next())
    {
      studio_name = studio_results.getString('name');
    }
    
    var producerName = "";
    var producers = getContacts("project", uid, "Nutaku Producer");
    if(producers.length > 0)
      producerName = producers[0].name;
    
    if (add)
    {    
      //Add new studio row
      html += parseProjectRow(uid, title, logo, producerName, location, status, phase, tier, is_last);
    }
  }
  
  //Close connections
  proj_results.close();
  stmt.close();
   
  base_html = base_html.replace('#project-rows', html);
  
  return base_html;
}
