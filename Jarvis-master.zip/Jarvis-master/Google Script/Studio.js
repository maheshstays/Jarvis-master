//Master list of studios and associated projects
function generateMasterStudioList()
{ 
  var base_html = HtmlService.createTemplateFromFile("studio_StudioMasterTable").evaluate().getContent();
  
  //Base HTML table
  var studios_html = generateStudioList();
  
  base_html = base_html.replace('#studio-tables', studios_html);
  
  return base_html;
}

function generateStudioList()
{
  //Search Params
  var maxProjects = 10;
  var maxStudios = 200;
  
  //Get HTML template, parse to XML, connect to database
  var conn = fetchConnection();

  //Create SQL statement
  var pc_stmt = conn.createStatement();
  var prod_stmt = conn.createStatement();
  var studio_stmt = conn.createStatement();
  studio_stmt.setMaxRows(maxStudios);

  //SQL Query
  var html = "";
  var studio_results = studio_stmt.executeQuery('SELECT name, logo_url, address_city, address_country, uid FROM studio');
  while (studio_results.next()) 
  {
    var uid = studio_results.getString('uid');
    var studio_logo_url = studio_results.getString('logo_url');
    var name = studio_results.getString('name');
    var add_city = studio_results.getString('address_city');
    var add_country = studio_results.getString('address_country');
    var contact_name = '';
    var contact_email = '';
    
    var contacts = getContacts("studio", uid);
    for(var i = 0; i < contacts.length; i++)
    {
      contact_name = contacts[i].name;
      contact_email = contacts[i].email;
    }
      
    //Add new studio row
    html += parseStudioRow(uid, name, studio_logo_url, add_city, add_country, contact_name, contact_email); 
    
    //SQL Project Query
    var proj_stmt = conn.createStatement();
    proj_stmt.setMaxRows(maxProjects);
    var proj_results = proj_stmt.executeQuery('SELECT title, logo_url, location, status, phase, tier, uid FROM project WHERE studio=' + qstr(uid));
    
    var project_html = '';
    var count = 0;
    
    //Add all projects
    while (proj_results.next()) 
    {       
      var p_uid = proj_results.getInt('uid');
      var title = proj_results.getString('title');
      var logo = proj_results.getString('logo_url');
      var location = proj_results.getString('location');
      var status = proj_results.getString('status');
      var phase = proj_results.getString('phase');
      var tier = proj_results.getString('tier');
      var is_last = proj_results.isLast();
      
      //SQL producer query
      var producerName = "";
      var producers = getContacts("project", p_uid, "Nutaku Producer");
      if(producers.length > 0)
        producerName = producers[0].name;
      
      project_html += parseProjectRow(p_uid, title, logo, producerName, location, status, phase, tier, is_last);
      count ++;
    }
    
    html = html.replace("#project-rows", project_html);
    html = html.replace('#games_count', count);
  }
  
  //Close connections
  studio_results.close();
  studio_stmt.close();
  return html;
}