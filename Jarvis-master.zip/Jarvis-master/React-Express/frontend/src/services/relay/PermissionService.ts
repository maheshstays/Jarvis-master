import Contact from '../../domain/Contact';
import Role from '../../domain/Role';

const CONTACT_1: Contact = new Contact({
  email: '#temporary_mail1',
  name: '#temporary_name',
  role: new Role({
    id: '1',
    name: 'Producer',
  }),
  skype: '#temporary_skype',
});
const CONTACT_2: Contact = new Contact({
  email: '#temporary_mail2',
  name: '#temporary_name',
  role: new Role({
    id: '2',
    name: 'Production Lead',
  }),
  skype: '#temporary_skype',
});

export default class {
  public static fetchContactsForProject(projectId?: string): Contact[] {
    if (projectId == null) { return []; }
    return [CONTACT_1, CONTACT_2];
  }

  public static fetchContactsForStudio(studioId?: string): Contact[] {
    if (studioId == null) { return []; }
    return [CONTACT_1, CONTACT_2];
  }
}
