import graphql from 'babel-plugin-relay/macro';
import { commitMutation } from 'react-relay';
import { useLazyLoadQuery } from 'react-relay/hooks';
import Platform from '../../domain/Platform';
import PlatformPerformance from '../../domain/PlatformPerformance';
import PreviousPerformance from '../../domain/PreviousPerformance';
import Project from '../../domain/Project';
import TechnicalInformation from '../../domain/TechnicalInformation';
import environment from '../relay';
import { ProjectServiceCreationMutation } from './__generated__/ProjectServiceCreationMutation.graphql';
import { ProjectServiceProjectsQuery } from './__generated__/ProjectServiceProjectsQuery.graphql';
import ProjectMapper from './mappers/ProjectMapper';

import googlePlay from '../../main/platform/assets/google-play.svg';
import kongregate from '../../main/platform/assets/kongregate.svg';
import steam from '../../main/platform/assets/steam.svg';

const FAKE_PLATFORM_1: Platform = new Platform({
  icon: googlePlay,
  id: '1',
  name: 'Google Play',
});
const FAKE_PLATFORM_2: Platform = new Platform({
  icon: kongregate,
  id: '2',
  name: 'Kongregate',
});
const FAKE_PLATFORM_3: Platform = new Platform({
  icon: steam,
  id: '3',
  name: 'Steam',
});

const FAKE_PLATFORM_PERFORMANCE_1: PlatformPerformance = new PlatformPerformance({
  downloads: 1564,
  id: '1',
  platform: FAKE_PLATFORM_1,
  rating: 5,
});
const FAKE_PLATFORM_PERFORMANCE_2: PlatformPerformance = new PlatformPerformance({
  downloads: 164,
  id: '2',
  platform: FAKE_PLATFORM_2,
  rating: 6,
});
const FAKE_PLATFORM_PERFORMANCE_3: PlatformPerformance = new PlatformPerformance({
  downloads: 155464,
  id: '3',
  platform: FAKE_PLATFORM_3,
  rating: 8,
});
const FAKE_PLATFORM_PERFORMANCE_4: PlatformPerformance = new PlatformPerformance({
  downloads: 9813564,
  id: '4',
  platform: FAKE_PLATFORM_1,
  rating: 2,
});
const FAKE_PLATFORM_PERFORMANCE_5: PlatformPerformance = new PlatformPerformance({
  downloads: 154,
  id: '5',
  platform: FAKE_PLATFORM_2,
  rating: 3,
});
const FAKE_PLATFORM_PERFORMANCE_6: PlatformPerformance = new PlatformPerformance({
  downloads: 12,
  id: '6',
  platform: FAKE_PLATFORM_3,
  rating: 7,
});

const FAKE_PREVIOUS_PERFORMANCE_1: PreviousPerformance = new PreviousPerformance({
  gameName: 'Previous Game #1',
  id: '1',
  platformsPerformance: [FAKE_PLATFORM_PERFORMANCE_1, FAKE_PLATFORM_PERFORMANCE_2],
  referenceUrl: 'https://nutaku.net/perf1',
  trailerUrl:  'https://nutaku.net/trailer1',
});
const FAKE_PREVIOUS_PERFORMANCE_2: PreviousPerformance = new PreviousPerformance({
  gameName: 'Previous Game #2',
  id: '2',
  platformsPerformance: [FAKE_PLATFORM_PERFORMANCE_3, FAKE_PLATFORM_PERFORMANCE_4, FAKE_PLATFORM_PERFORMANCE_5],
  referenceUrl: 'https://nutaku.net/perf1',
  trailerUrl:  'https://nutaku.net/trailer1',
});
const FAKE_PREVIOUS_PERFORMANCE_3: PreviousPerformance = new PreviousPerformance({
  gameName: 'Previous Game #3',
  id: '3',
  platformsPerformance: [FAKE_PLATFORM_PERFORMANCE_6],
  referenceUrl: 'https://nutaku.net/perf1',
  trailerUrl:  'https://nutaku.net/trailer1',
});

const FAKE_TECHNICAL_INFORMATION_1: TechnicalInformation = new TechnicalInformation({
  categories: ['action/adventure'],
  crossSaveState: true,
  engine: 'Unity',
  genres: ['clicker', 'strategy', 'puzzler', 'rpg'],
  languages: ['eng', 'fr', 'de', 'jpn'],
  nutakuEngineCategory: 'Previously-launched, with little success',
  platforms: ['browser', 'mobile', 'dl'],
  requirementToLaunch: 'Clone/Resking+Adultify',
});
const FAKE_TECHNICAL_INFORMATION_2: TechnicalInformation = new TechnicalInformation({
  categories: ['strategy', 'adventure'],
  crossSaveState: false,
  engine: 'Unreal',
  genres: ['clicker', 'rpg'],
  languages: ['de', 'jpn'],
  nutakuEngineCategory: 'Previously-launched, with moderate success',
  platforms: ['mobile'],
  requirementToLaunch: 'Resking+Adultify',
});
const FAKE_TECHNICAL_INFORMATION_3: TechnicalInformation = new TechnicalInformation({
  categories: ['platformer', 'action'],
  crossSaveState: true,
  engine: 'Unity',
  genres: ['clicker'],
  languages: ['eng', 'fr'],
  nutakuEngineCategory: 'Previously-launched, with huge success',
  platforms: ['dl'],
  requirementToLaunch: 'Clone/Resking',
});

const projectsQuery = graphql`
  query ProjectServiceProjectsQuery($studioName: String!) {
    projects(studioName: $studioName) {
      id
      contacts {
        email
        name
        role {
          id
          name
        }
        skype
      }
      managedBy
      name
      thumbnailUrl
    }
  }
`;

const projectCreationMutation = graphql`
  mutation ProjectServiceCreationMutation($studioId: ID!, $projectInput: ProjectCreationInput!) {
    createProject(
      studioId: $studioId,
      project: $projectInput
    ) {
      id
    }
  }
`;

export default class {
  public static fetchProjects(studioName: string): Project[] {
    const data = useLazyLoadQuery<ProjectServiceProjectsQuery>(projectsQuery, { studioName });

    return data.projects.map(ProjectMapper.assembleProject);
  }

  public static fetchProject(studioName: string, projectName: string): Project {
    const projects: Project[] = this.fetchProjects(studioName);
    const result = projects.find((project: Project) => project.name === projectName);

    if (!result) {
      throw new Error(`No project found with name ${projectName}.`);
    }

    return result;
  }

  public static createProject(
    studioId: ProjectServiceCreationMutation['variables']['studioId'],
    project: ProjectServiceCreationMutation['variables']['projectInput'],
    onCompleted?: () => void,
    onError?: () => void,
  ) {
    commitMutation<ProjectServiceCreationMutation>(
      environment,
      {
        mutation: projectCreationMutation,
        onCompleted,
        onError,
        variables: { studioId, projectInput: project },
      },
    );
  }

  // FAKE
  public static fetchPreviousPerformance(projectId: string): PreviousPerformance {
    const performances: PreviousPerformance[] = [
      FAKE_PREVIOUS_PERFORMANCE_1,
      FAKE_PREVIOUS_PERFORMANCE_2,
      FAKE_PREVIOUS_PERFORMANCE_3,
    ];

    const index = parseInt((Math.random() * performances.length).toString(), 10);
    return performances[index];
  }

  // FAKE
  public static fetchTechnicalInformation(projectId: string): TechnicalInformation {
    const technicalInformations: TechnicalInformation[] = [
      FAKE_TECHNICAL_INFORMATION_1,
      FAKE_TECHNICAL_INFORMATION_2,
      FAKE_TECHNICAL_INFORMATION_3,
    ];

    const index = parseInt((Math.random() * technicalInformations.length).toString(), 10);
    return technicalInformations[index];
  }
}
