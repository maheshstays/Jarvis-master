import Address from '../../../domain/Address';
import Comment from '../../../domain/Comment';
import Contact from '../../../domain/Contact';
import Role from '../../../domain/Role';
import Studio from '../../../domain/Studio';
import StudioExperience from '../../../domain/StudioExperience';
import { StudioServiceStudiosQueryResponse } from '../__generated__/StudioServiceStudiosQuery.graphql';
import ProjectMapper from './ProjectMapper';

type RawStudio = StudioServiceStudiosQueryResponse['studios'][0];
type RawComment = RawStudio['comments'][0];
type RawExperienceComment = RawStudio['experienceComments'][0];
type RawContact = RawStudio['contacts'][0];

export default class {
  public static assembleStudio(rawStudio: RawStudio): Studio {
    const {
      address: rawAddress,
      comments: rawComments,
      contacts: rawContacts,
      experienceComments: rawExperienceComments,
      projects: rawProjects,
    } = rawStudio;

    return new Studio({
      address: new Address(rawAddress && {
        city: rawAddress.country,
        country: rawAddress.country,
        state: rawAddress.state,
        street: rawAddress.street,
        zipcode: rawAddress.zipcode,
      }),
      comments: rawComments.map((rawComment: RawComment) => new Comment({
        author: rawComment.author,
        date: rawComment.date,
        id: rawComment.id,
        text: rawComment.text,
      })),
      contacts: rawContacts.map(({
        role: rawRole,
        ...rawContact
      }: RawContact) => new Contact({
        email: rawContact.email,
        name: rawContact.name,
        role: new Role({ id: rawRole.id, name: rawRole.name }),
        skype: rawContact.skype,
      })),
      employees: rawStudio.employees,
      experience: new StudioExperience({
        comments: rawExperienceComments.map(
          (rawExperienceComment: RawExperienceComment) => new Comment({
            author: rawExperienceComment.author,
            date: rawExperienceComment.date,
            id: rawExperienceComment.id,
            text: rawExperienceComment.text,
          }),
        ),
        gamesLaunched: rawStudio.gamesLaunched,
        hasF2pExperience: rawStudio.hasF2pExperience,
        hasLiveOpsExperience: rawStudio.hasLiveOpsExperience,
        successfulRating: rawStudio.successfulRating,
        successfulTitle: rawStudio.successfulTitle,
        successfulUrl: rawStudio.successfulUrl,
      }),
      foundingDate: rawStudio.foundingDate,
      id: rawStudio.id,
      logoUrl: rawStudio.logoUrl,
      name: rawStudio.name,
      phoneNumber: rawStudio.phoneNumber,
      projects: rawProjects.map(ProjectMapper.assembleProject),
      websiteUrl: rawStudio.websiteUrl,
    });
  }
}
