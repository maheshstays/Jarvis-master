import { NUTAKU_PRODUCER } from '../../../constants';
import Comment from '../../../domain/Comment';
import Contact from '../../../domain/Contact';
import KPI from '../../../domain/KPI';
import LegalInformation from '../../../domain/LegalInformation';
import Approval, { ApprovalStatus } from '../../../domain/milestones/Approval';
import Deliverable, { DeliverableStatus } from '../../../domain/milestones/Deliverable';
import Milestone, { PaymentStatus } from '../../../domain/milestones/Milestone';
import Project from '../../../domain/Project';
import Role from '../../../domain/Role';
import { ProjectServiceProjectsQueryResponse } from '../__generated__/ProjectServiceProjectsQuery.graphql';

type RawProject = ProjectServiceProjectsQueryResponse['projects'][0];
type RawContact = RawProject['contacts'][0];

const FAKE_DELIVERABLE_1: Deliverable = new Deliverable({
  description: 'Description for the full production plan',
  id: '1',
  name: 'Full Production Plan',
  status: DeliverableStatus.Delivered,
});
const FAKE_DELIVERABLE_2: Deliverable = new Deliverable({
  description: 'Description for the GDD',
  id: '2',
  name: 'Game Design Document (GDD)',
  status: DeliverableStatus.ToBeDelivered,
});
const FAKE_DELIVERABLE_3: Deliverable = new Deliverable({
  description: 'Description for the application flow',
  id: '3',
  name: 'Application Flow',
  status: DeliverableStatus.Late,
});
const FAKE_DELIVERABLE_4: Deliverable = new Deliverable({
  description: 'Feature list outlining primary and secondary features',
  id: '4',
  name: 'Feature List',
  status: DeliverableStatus.Delivered,
});
const FAKE_DELIVERABLE_5: Deliverable = new Deliverable({
  description: 'Technical Design Document (TDD) including architecture',
  id: '5',
  name: 'Technical Design Document (TDD)',
  status: DeliverableStatus.Delivered,
});
const FAKE_DELIVERABLE_6: Deliverable = new Deliverable({
  description: 'Description for the CDD',
  id: '6',
  name: 'Creative Design Document (CDD)',
  status: DeliverableStatus.Delivered,
});
const FAKE_DELIVERABLE_7: Deliverable = new Deliverable({
  description: 'Description for the Risk and Mitigations',
  id: '7',
  name: 'Risk & Mitigations',
  status: DeliverableStatus.Delivered,
});

const FAKE_ROLE_1: Role = new Role({
  id: '1',
  name: 'Producer',
});
const FAKE_ROLE_2: Role = new Role({
  id: '2',
  name: 'Production Lead',
});
const FAKE_ROLE_3: Role = new Role({
  id: '3',
  name: 'Game Design',
});
const FAKE_ROLE_4: Role = new Role({
  id: '4',
  name: 'Quality Assurance',
});
const FAKE_ROLE_5: Role = new Role({
  id: '5',
  name: 'Localization',
});
const FAKE_ROLE_6: Role = new Role({
  id: '6',
  name: 'Production Director',
});
const FAKE_ROLE_7: Role = new Role({
  id: '7',
  name: 'Director',
});

const FAKE_APPROVAL_1: Approval = new Approval({
  approverName: 'Approver Name',
  comment: 'This is a comment',
  id: '1',
  role: FAKE_ROLE_1,
  status: ApprovalStatus.Approved,
});
const FAKE_APPROVAL_2: Approval = new Approval({
  approverName: 'Approver Name',
  comment: 'This is a comment',
  id: '2',
  role: FAKE_ROLE_2,
  status: ApprovalStatus.Approved,
});
const FAKE_APPROVAL_3: Approval = new Approval({
  approverName: 'Approver Name',
  comment: 'This is a comment',
  id: '3',
  role: FAKE_ROLE_3,
  status: ApprovalStatus.Approved,
});
const FAKE_APPROVAL_4: Approval = new Approval({
  approverName: 'Approver Name',
  comment: 'This is a comment',
  id: '4',
  role: FAKE_ROLE_4,
  status: ApprovalStatus.NeedMoreInfo,
});
const FAKE_APPROVAL_5: Approval = new Approval({
  approverName: 'Approver Name',
  comment: 'This is a comment',
  id: '5',
  role: FAKE_ROLE_5,
  status: ApprovalStatus.Denied,
});
const FAKE_APPROVAL_6: Approval = new Approval({
  approverName: 'Approver Name',
  comment: 'This is a comment',
  id: '6',
  role: FAKE_ROLE_6,
  status: ApprovalStatus.Approved,
});
const FAKE_APPROVAL_7: Approval = new Approval({
  approverName: 'Approver Name',
  comment: 'This is a comment',
  id: '7',
  role: FAKE_ROLE_7,
  status: ApprovalStatus.Approved,
});

const FAKE_DELIVERABLES: Deliverable[] = [
  FAKE_DELIVERABLE_1,
  FAKE_DELIVERABLE_2,
  FAKE_DELIVERABLE_3,
  FAKE_DELIVERABLE_4,
  FAKE_DELIVERABLE_5,
  FAKE_DELIVERABLE_6,
  FAKE_DELIVERABLE_7,
];
const FAKE_APPROVALS: Approval[] = [
  FAKE_APPROVAL_1,
  FAKE_APPROVAL_2,
  FAKE_APPROVAL_3,
  FAKE_APPROVAL_4,
  FAKE_APPROVAL_5,
  FAKE_APPROVAL_6,
  FAKE_APPROVAL_7,
];

const FAKE_MILESTONE_1: Milestone = new Milestone({
  approvalDate: (new Date(2019, 9, 26)).getTime(),
  approvals: FAKE_APPROVALS,
  deliverables: FAKE_DELIVERABLES,
  dueDate: (new Date(2019, 9, 24)).getTime(),
  id: '1',
  name: 'Contract Signed',
  paymentAmount: 1000000,
  paymentStatus: PaymentStatus.Paid,
});
const FAKE_MILESTONE_2: Milestone = new Milestone({
  approvalDate: (new Date(2019, 10, 25)).getTime(),
  approvals: FAKE_APPROVALS,
  deliverables: FAKE_DELIVERABLES,
  dueDate: (new Date(2019, 10, 20)).getTime(),
  id: '2',
  name: 'Pre-Prod & Planning',
  paymentAmount: 1000000,
  paymentStatus: PaymentStatus.Paid,
});
const FAKE_MILESTONE_3: Milestone = new Milestone({
  approvalDate: (new Date(2019, 11, 24)).getTime(),
  approvals: FAKE_APPROVALS,
  deliverables: FAKE_DELIVERABLES,
  dueDate: (new Date(2019, 11, 22)).getTime(),
  id: '3',
  name: 'First Playable',
  paymentAmount: 1500000,
  paymentStatus: PaymentStatus.SentToAccounting,
});
const FAKE_MILESTONE_4: Milestone = new Milestone({
  approvalDate: null,
  approvals: FAKE_APPROVALS,
  deliverables: FAKE_DELIVERABLES,
  dueDate: (new Date(2020, 1, 6)).getTime(),
  id: '4',
  name: 'Alpha',
  paymentAmount: 2000000,
  paymentStatus: null,
});
const FAKE_MILESTONE_5: Milestone = new Milestone({
  approvalDate: null,
  approvals: FAKE_APPROVALS,
  deliverables: FAKE_DELIVERABLES,
  dueDate: null,
  id: '5',
  name: 'Beta',
  paymentAmount: 2500000,
  paymentStatus: null,
});
const FAKE_MILESTONE_6: Milestone = new Milestone({
  approvalDate: null,
  approvals: FAKE_APPROVALS,
  deliverables: FAKE_DELIVERABLES,
  dueDate: (new Date(2019, 3, 24)).getTime(),
  id: '6',
  name: 'Open Beta',
  paymentAmount: null,
  paymentStatus: null,
});
const FAKE_MILESTONE_7: Milestone = new Milestone({
  approvalDate: null,
  approvals: FAKE_APPROVALS,
  deliverables: FAKE_DELIVERABLES,
  dueDate: (new Date(2019, 6, 2)).getTime(),
  id: '7',
  name: 'Commercial Launch',
  paymentAmount: null,
  paymentStatus: null,
});

const FAKE_COMMENT_1: Comment = new Comment({
  author: 'Random Author #1',
  date: (new Date(2020, 0, 1)).getTime(),
  id: '2',
  text: 'Happy New Year!',
});
const FAKE_COMMENT_2: Comment = new Comment({
  author: 'Random Author #2',
  date: (new Date(2019, 5, 22)).getTime(),
  id: '4',
  text: 'This is a comment',
});
const FAKE_COMMENT_3: Comment = new Comment({
  author: 'Random Author #3',
  date: (new Date(2019, 10, 7)).getTime(),
  id: '6',
  text: 'This is a longer comment with more text in it. This is a longer comment with more text in it. This is a longer comment with more text in it. This is a longer comment with more text in it. This is a longer comment with more text in it. This is a longer comment with more text in it.',
});

const FAKE_LEGAL_INFORMATION: LegalInformation = new LegalInformation({
  advanceBy: 'Advenced by',
  comments: [],
  hasBizDevCommission: false,
  ipHolder: 'Ip Holder Name',
  isExclusive: false,
  nutakuSignatureDate: (new Date(2017, 2, 5)).getTime(),
  paysFreeGold: false,
  publisher: 'Publisher Name',
  publishingSignatureDate: null,
});

const FAKE_PROJECT: Project = new Project({
  contacts: [new Contact({
    email: 'producer@ntku.net',
    name: 'Superman',
    role: new Role({ name: NUTAKU_PRODUCER, id: '3'} ),
    skype: null,
  })],
  discordUrl: 'https:discord.gg',
  gameInformationComments: [],
  googleDriveUrl: 'https://drive.google.com/',
  id: '3',
  jiraUrl: 'https://www.atlassian.com/software/jira',
  legalInformation: FAKE_LEGAL_INFORMATION,
  managedBy: 'Nutaku Montreal',
  milestones: [
    FAKE_MILESTONE_1,
    FAKE_MILESTONE_2,
    FAKE_MILESTONE_3,
    FAKE_MILESTONE_4,
    FAKE_MILESTONE_5,
    FAKE_MILESTONE_6,
    FAKE_MILESTONE_7,
  ],
  milestonesComments: [],
  name: 'Funny Project',
  playfabUrl: 'https://playfab.com/',
  previousPerformanceComments: [FAKE_COMMENT_2, FAKE_COMMENT_3],
  projectCompletionKPI: new KPI({
    name: 'Project Completion', progressRatio: 0.85,
  }),
  statusDate: (new Date(2020, 1, 9)).getTime(),
  statusLevel: 'good',
  statusName: 'Alpha',
  technicalInformationComments: [FAKE_COMMENT_1],
  thumbnailUrl: 'https://picsum.photos/100/200',
  tier: 1,
  totalFundingKPI: new KPI({
    name: 'Funding Completion', progressRatio: 0.7,
  }),
});

export default class {
  public static assembleProject(rawProject: RawProject): Project {
    const {
      contacts: rawContacts,
    } = rawProject;

    return new Project({
      ...FAKE_PROJECT,
      contacts: rawContacts.map(({
        role: rawRole,
        ...rawContact
      }: RawContact) => new Contact({
        email: rawContact.email,
        name: rawContact.name,
        role: new Role({ id: rawRole.id, name: rawRole.name }),
        skype: rawContact.skype,
      })),
      id: rawProject.id,
      managedBy: rawProject.managedBy,
      name: rawProject.name,
      thumbnailUrl: rawProject.thumbnailUrl,
    });
  }
}
