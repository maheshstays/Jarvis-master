import graphql from 'babel-plugin-relay/macro';
import { commitMutation } from 'react-relay';
import { useLazyLoadQuery } from 'react-relay/hooks';
import Studio from '../../domain/Studio';
import environment from '../relay';
import { StudioServiceCreationMutation } from './__generated__/StudioServiceCreationMutation.graphql';
import { StudioServiceDeletionMutation } from './__generated__/StudioServiceDeletionMutation.graphql';
import { StudioServiceStudiosQuery } from './__generated__/StudioServiceStudiosQuery.graphql';
import { StudioServiceUpdateMutation } from './__generated__/StudioServiceUpdateMutation.graphql';
import StudioMapper from './mappers/StudioMapper';

const studiosQuery = graphql`
  query StudioServiceStudiosQuery {
    studios {
      id
      address {
        city
        country
        state
        street
        zipcode
      }
      comments {
        id
        author
        date
        text
      }
      contacts {
        email
        name
        role {
          id
          name
        }
        skype
      }
      employees
      experienceComments {
        id
        author
        date
        text
      }
      foundingDate
      gamesLaunched
      hasF2pExperience
      hasLiveOpsExperience
      logoUrl
      name
      phoneNumber
      projects {
        id
        contacts {
          email
          name
          role {
            id
            name
          }
          skype
        }
        managedBy
        name
        thumbnailUrl
      }
      successfulRating
      successfulTitle
      successfulUrl
      websiteUrl
    }
  }
`;

const studioCreationMutation = graphql`
  mutation StudioServiceCreationMutation($studioInput: StudioCreationInput!) {
    createStudio(
      studio: $studioInput
    ) {
      id
    }
  }
`;

const studioUpdateMutation = graphql`
  mutation StudioServiceUpdateMutation($studioInput: StudioUpdateInput!) {
    updateStudio(
      studio: $studioInput
    ) {
      id
    }
  }
`;

const studioDeletionMutation = graphql`
  mutation StudioServiceDeletionMutation($studioId: ID!) {
    deleteStudio(
      studioId: $studioId
    )
  }
`;

export default class {
  public static fetchStudios(): Studio[] {
    const data = useLazyLoadQuery<StudioServiceStudiosQuery>(studiosQuery, {});

    return data.studios.map(StudioMapper.assembleStudio);
  }

  public static fetchStudio(name: string): Studio {
    const studios: Studio[] = this.fetchStudios();
    const result = studios.find((studio: Studio) => studio.name === name);

    if (!result) {
      throw new Error(`No studio found with name ${name}.`);
    }

    return result;
  }

  public static createStudio(
    studio: StudioServiceCreationMutation['variables']['studioInput'], onCompleted?: () => void, onError?: () => void,
  ) {
    commitMutation<StudioServiceCreationMutation>(
      environment,
      {
        mutation: studioCreationMutation,
        onCompleted,
        onError,
        variables: { studioInput: studio },
      },
    );
  }

  public static updateStudio(
    studio: StudioServiceUpdateMutation['variables']['studioInput'], onCompleted?: () => void, onError?: () => void,
  ) {
    commitMutation<StudioServiceUpdateMutation>(
      environment,
      {
        mutation: studioUpdateMutation,
        onCompleted,
        onError,
        variables: { studioInput: studio },
      },
    );
  }

  public static deleteStudio(
    studioId: string, onCompleted?: () => void, onError?: () => void,
  ) {
    commitMutation<StudioServiceDeletionMutation>(
      environment,
      {
        mutation: studioDeletionMutation,
        onCompleted,
        onError,
        variables: { studioId },
      },
    );
  }
}
