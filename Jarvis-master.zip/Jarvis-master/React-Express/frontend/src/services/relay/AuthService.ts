import graphql from 'babel-plugin-relay/macro';
import Cookie from 'js-cookie';
import { GoogleLoginResponse, GoogleLoginResponseOffline } from 'react-google-login';
import { commitMutation } from 'react-relay';
import { Observable, Subject } from 'rxjs';
import { SESSION_COOKIE_NAME } from '../../constants';
import environment from '../relay';
import { AuthServiceLoginMutation } from './__generated__/AuthServiceLoginMutation.graphql';

const loginMutation = graphql`
  mutation AuthServiceLoginMutation(
    $token: String!
  ) {
    login(token: $token)
  }
`;

const logoutMutation = graphql`
  mutation AuthServiceLogoutMutation {
    logout
  }
`;

export default class AuthService {
  public static login(loginResponse: GoogleLoginResponse | GoogleLoginResponseOffline ) {
    commitMutation<AuthServiceLoginMutation>(
      environment,
      {
        mutation: loginMutation,
        onCompleted: () => { AuthService.userSubject.next({ isAuthenticated: true }); },
        variables: {
          token: (loginResponse as GoogleLoginResponse)?.tokenObj?.id_token,
        },
      });
  }

  public static logout() {
    commitMutation(
      environment,
      {
        mutation: logoutMutation,
        onCompleted: () => { AuthService.userSubject.next({ isAuthenticated: false }); },
        variables: {},
      },
    );
  }

  public static initialize() {
    AuthService.userSubject.next({ isAuthenticated: !!Cookie.get(SESSION_COOKIE_NAME) });
  }

  public static getUser(): Observable<{ isAuthenticated: boolean }> {
    return AuthService.userSubject.asObservable();
  }

  private static userSubject: Subject<{ isAuthenticated: boolean }> = new Subject();
}
