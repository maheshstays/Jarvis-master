import { Environment, Network, RecordSource, RequestParameters, Store, Variables } from 'relay-runtime';

async function fetchFn(operation: RequestParameters, variables: Variables) {
  const response = await fetch(
    process.env.NODE_ENV === 'production' ?
      'https://api.vision.ntku.net/graphql' :
      'http://localhost:3001/graphql',
    {
      body: JSON.stringify({
        query: operation.text,
        variables,
      }),
      credentials: 'include',
      headers: {
        'Content-Type': 'application/json',
      },
      method: 'POST',
    },
  );

  return response.json();
}

const environment = new Environment({
  network: Network.create(fetchFn),
  store: new Store(new RecordSource()),
});

export default environment;
