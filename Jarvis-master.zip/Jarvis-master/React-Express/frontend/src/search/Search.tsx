import { RouteComponentProps } from '@reach/router';
import React from 'react';
import SearchBar from './SearchBar';

interface Props extends RouteComponentProps<{}> {
  children?: never;
}

export default (props: Props) => (
  <SearchBar/>
);
