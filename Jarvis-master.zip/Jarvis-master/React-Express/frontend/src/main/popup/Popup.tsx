import classNames from 'classnames';
import React, { ButtonHTMLAttributes, Component, createRef, ReactNode, RefObject } from 'react';
import Button from '../button/Button';
import Modal from '../modal/Modal';

import styles from './Popup.module.css';

export interface PopupButton {
  onClick?: () => void;
  text: string;
  type?: ButtonHTMLAttributes<HTMLButtonElement>['type'];
}

interface Props {
  defaultWidth?: string;
  defaultHeight?: string;
  extraButtons?: PopupButton[];
  closeButton?: PopupButton;
  children: ReactNode;
}

interface State {
  isShown: boolean;
}

export default class extends Component<Props, State> {
  public state = { isShown: false };

  private modalRef: RefObject<Modal> = createRef<Modal>();
  private containerRef: RefObject<HTMLDivElement> = createRef<HTMLDivElement>();

  public componentDidUpdate() {
    if (this.modalRef.current && this.containerRef.current) {
      const rect: DOMRect = this.modalRef.current.containerRef.current!.getBoundingClientRect();
      const parentRect: DOMRect = this.containerRef.current.getBoundingClientRect();
      const x = (parentRect.width - rect.width) * 0.5;
      const y = (parentRect.height - rect.height) * 0.5;

      this.modalRef.current.setTopLeft(`${x}px`, `${y}px`);
    }
  }

  public render() {
    let buttons = [this.closeButton];
    if (this.props.extraButtons) {
      buttons = buttons.concat(this.props.extraButtons.map((extraButton) =>
        <Button key={extraButton.text} onClick={extraButton.onClick} type={extraButton.type}>
          {extraButton.text}
        </Button>,
      ));
    }

    return (
    <div
      ref={this.containerRef}
      className={classNames(styles.container, {[styles.hidden]: !this.state.isShown})}
    >
      <div
        className={classNames(styles.background, {[styles.hidden]: !this.state.isShown})}
        onClick={() => this.setVisibility(false)}
      />
      <Modal
        defaultWidth={this.props.defaultWidth}
        defaultHeight={this.props.defaultHeight}
        ref={this.modalRef}
        containerClassName={styles.modalContainer}
        contentClassName={styles.modalContent}
      >
        <div className={styles.content}>
          {this.props.children}
        </div>
        <div className={styles.push}/>
        <div className={styles.buttonsContainer}>
          {buttons}
        </div>
      </Modal>
    </div>
    );
  }

  public setVisibility(isShown: boolean) {
    this.setState({ isShown });
  }

  get closeButton() {
    return this.props.closeButton == null ?
      <Button key={0} onClick={() => this.setVisibility(false)}>Close</Button>
    :
      <Button key={0} onClick={this.props.closeButton.onClick}>{this.props.closeButton.text}</Button>;
  }
}
