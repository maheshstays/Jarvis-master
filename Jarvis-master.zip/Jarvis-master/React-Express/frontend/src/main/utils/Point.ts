interface PointArgs {
  x: number;
  y: number;
}

export default class {
  public readonly x: number;
  public readonly y: number;

  constructor(args: PointArgs) {
    this.x = args.x;
    this.y = args.y;
  }
}
