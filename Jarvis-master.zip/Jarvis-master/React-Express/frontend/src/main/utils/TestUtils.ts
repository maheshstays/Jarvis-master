export const idSelector = (id: string): string => `[id="${id}"]`;

export const classSelector = (klass: string): string => `.${klass}`;
