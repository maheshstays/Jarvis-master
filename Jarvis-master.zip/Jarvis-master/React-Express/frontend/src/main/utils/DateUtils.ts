export const getYearsInterval = (date1: Date, date2: Date) => {
  const intervalMs: number = Math.abs(date1.getTime() - date2.getTime());
  const days = intervalMs / 1000 / 60 / 60 / 24;

  return Math.floor(days / 365.25);
};

export const getDateString = (date: Date) => {
  const month = `${date.getMonth() + 1}`.padStart(2, '0');
  const day = `${date.getDate()}`.padStart(2, '0');
  const year = `${date.getFullYear()}`;

  return [year, month, day].join('-');
};
