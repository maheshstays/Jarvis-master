export const cssGlobal = (variable: string): string =>
  getComputedStyle(document.documentElement).getPropertyValue(variable);
