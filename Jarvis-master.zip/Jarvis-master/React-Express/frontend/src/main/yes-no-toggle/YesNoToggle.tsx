import classNames from 'classnames';
import React, {ChangeEvent, Component} from 'react';
import Label from '../label/Label';

import styles from './YesNoToggle.module.css';

interface Props {
  value: boolean;
  label?: string;
  subLabel?: string;
  containerClassName?: string;
  onChange?: (element: React.ChangeEvent<HTMLInputElement>) => void;
  children?: never;
}

interface State {
  value: boolean;
}

class YesNoToggle extends Component<Props, State> {
  constructor(props: Props) {
    super(props);
    this.state = {
        value: props.value,
    };
    this.handleClick = this.handleClick.bind(this);
  }

  public render() {
    return (
      <div>
        <Label label={this.props.label} subLabel={this.props.subLabel}/>
        <div
          className={classNames(
            styles.uiToggle,
            {[styles.selected]: this.state.value},
            this.props.containerClassName)
          }
        >
          <input
            type="radio"
            className={styles.uiToggleInput}
            value="yes"
            checked={this.state.value}
            onChange={this.props.onChange}
          />
          <label className={classNames(styles.uiToggleLabel, styles.uiToggleLabelOn)} onClick={this.handleClick}>
            Yes
          </label>
          <input
            type="radio"
            className={styles.uiToggleInput}
            value="no"
            checked={!this.state.value}
            onChange={this.props.onChange}
          />
          <label className={classNames(styles.uiToggleLabel, styles.uiToggleLabelOff)} onClick={this.handleClick}>
            No
          </label>
          <span className={styles.uiToggleSelection}/>
        </div>
      </div>
    );
  }

  private handleClick = () => {
    this.setState({value: !this.state.value});
  }
}

export default YesNoToggle;
