import classNames from 'classnames';
import React, { Component, ReactNode } from 'react';

import styles from './Tabs.module.css';

interface Tab {
  header: string;
  content: ReactNode;
}

interface Props {
  children: Tab[];
}

interface State {
  shownTabHeaderName: string;
}

export default class extends Component<Props, State> {
  constructor(props: Props) {
    super(props);
    this.state = {
      shownTabHeaderName: this.props.children[0].header,
    };
  }

  public render() {
    const tabs: Tab[] = this.props.children;
    const headers = tabs.map((tab) => {
      return (
        <div
          key={tab.header}
          onClick={() => { this.onTabClick(tab.header); }}
          className={classNames(styles.header, {[styles.selected]: this.state.shownTabHeaderName === tab.header})}
        >
            {tab.header}
        </div>
      );
    });

    const contents = tabs.map((tab) => {
      return (
        <div
          key={tab.header}
          className={classNames(styles.content, {[styles.hidden]: this.state.shownTabHeaderName !== tab.header})}
        >
          {tab.content}
        </div>
      );
    });

    return (
      <div className={styles.container}>
        <div className={styles.headersContainer}>
          {headers}
        </div>
        <div className={styles.contentContainer}>
          {contents}
        </div>
      </div>
    );
  }

  private onTabClick = (clickedHeader: string) => {
    this.setState({ shownTabHeaderName: clickedHeader });
  }
}
