import React, { Component } from 'react';

interface Props {
  number: number;
  children?: never;
}

class ThousandsSeparatedText extends Component<Props> {
  public static defaultProps = {
    number: 0,
  };

  public render() {
    const value = this.props.number.toString(10);
    let result = '';
    let count = 0;
    for (let i = value.length - 1; i >= 0; i--) {
      const char = value[i];

      if (count % 3 === 0 && count !== 0) {
        result = char + ',' + result;
      } else {
        result = char + result;
      }

      count++;
    }

    return <span>{result}</span>;
  }
}

export default ThousandsSeparatedText;
