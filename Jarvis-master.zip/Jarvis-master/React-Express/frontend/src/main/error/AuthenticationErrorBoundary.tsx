import { Component, ReactNode } from 'react';
import { ExtendedError, ExtendedPayloadError } from './ExtendedError';

interface Props {
  children: ReactNode;
}

export default class extends Component<Props> {
  public static getDerivedStateFromError(error: ExtendedError) {
    if (error.source?.errors.find((payloadError: ExtendedPayloadError) => payloadError.extensions?.code === 'UNAUTHENTICATED')) {
      window.location.reload();
    }

    throw error;
  }

  public render() {
    return this.props.children;
  }
}
