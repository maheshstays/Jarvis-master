import { ConcreteRequest, PayloadError, Variables } from 'relay-runtime';

export interface ExtendedPayloadError extends PayloadError {
  extensions?: {
    code: string;
    exception?: object;
  };
}

export interface ExtendedError extends Error {
  source?: {
    errors: ExtendedPayloadError[];
    operation: ConcreteRequest;
    variables: Variables;
  };
}
