import React, { Component, ReactNode } from 'react';
import { ExtendedError } from './ExtendedError';

interface Props {
  children: ReactNode;
}

interface State {
  error?: ExtendedError;
}

export default class extends Component<Props, State> {
  public static getDerivedStateFromError(error: ExtendedError): State {
    return { error };
  }

  public state: State = {};

  public render() {
    if (!this.state.error) {
      return this.props.children;
    }

    return <h1>Error: {JSON.stringify(
      this.state.error.source
        ? this.state.error.source?.errors[0].extensions?.code
        : this.state.error.message,
      )}</h1>;
  }
}
