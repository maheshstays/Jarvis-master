import React, { Component, Fragment } from 'react';
import { ReactSVG } from 'react-svg';

import ellipsis from './assets/ellipsis.svg';
import styles from './EllipsisButton.module.css';

interface Props {
  onClick?: () => void;
  children?: never;
}

export default class extends Component<Props> {
  public render() {
    return (
    <Fragment>
      <button onClick={this.props.onClick} className={styles.ellipsisButton}>
        <ReactSVG
          src={ellipsis}
          className={styles.ellipsisIconContainer}
          beforeInjection={(svg: Element) => {
            svg.classList.add(styles.ellipsisIcon);
          }}
        />
      </button>
    </Fragment>
    );
  }
}
