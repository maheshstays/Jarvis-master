import React from 'react';
import Button from '../button/Button';
import Textarea from '../textarea/Textarea';

import styles from './AddComment.module.css';

interface Props {
  onHide?: () => void;
  children?: never;
}

export default (props: Props) => (
  <div className={styles.container}>
    <Textarea className={styles.comment} placeholder="Write your note here"/>
    <div className={styles.buttonsContainer}>
      <Button>Add Note</Button>
      <div className={styles.spacer}/>
      <Button onClick={props.onHide}>Cancel</Button>
    </div>
  </div>
);
