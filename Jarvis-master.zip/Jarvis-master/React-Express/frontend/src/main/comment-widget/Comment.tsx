import React from 'react';
import DomainComment from '../../domain/Comment';
import DateText from '../date-text/DateText';

import styles from './Comment.module.css';

interface Props {
  comment: DomainComment;
  children?: never;
}

export default ({comment}: Props) => (
  <div className={styles.container}>
    <span className={styles.comment}>{comment.text}</span>
    <span className={styles.date}><DateText date={comment.date}/></span>
    <span className={styles.author}>{comment.author}</span>
  </div>
);
