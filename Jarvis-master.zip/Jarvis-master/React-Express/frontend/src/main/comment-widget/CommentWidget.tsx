// tslint:disable: no-bitwise
import classNames from 'classnames';
import React, { Component, createRef, RefObject } from 'react';
import { ReactSVG } from 'react-svg';
import DomainComment from '../../domain/Comment';
import Modal, { ResizeDirection } from '../modal/Modal';
import AddComment from './AddComment';
import Comment from './Comment';

import bubble from './assets/bubble.svg';
import plus from './assets/plus.svg';
import styles from './CommentWidget.module.css';

interface Props {
  comments: DomainComment[];
  children?: never;
}

interface State {
  isShown: boolean;
  isAddCommentShown: boolean;
}

export default class extends Component<Props, State> {
  private backgroundRef: RefObject<HTMLDivElement> = createRef<HTMLDivElement>();

  constructor(props: Props) {
    super(props);
    this.state = {
      isAddCommentShown: false,
      isShown: false,
    };
  }

  public componentDidMount() {
    if (this.backgroundRef.current) {
      this.backgroundRef.current.style.setProperty('max-height', 'inherit');
    }
  }

  public render() {
    const header =
    <div className={styles.header}>
      <button className={styles.addCommentButton} onClick={this.onClickAddComment}>
        <ReactSVG className={styles.plusIcon} src={plus}/>
        <span className={styles.headerText}>Add New Note</span>
      </button>
    </div>;

    const comments = this.props.comments.map((comment) => <Comment key={comment.id} comment={comment}/>);

    return (
    <div className={styles.container}>
      <button className={styles.bubbleButton} onClick={this.showWidget}>
        <ReactSVG
          src={bubble}
          className={styles.bubbleIconContainer}
          beforeInjection={(svg: Element) => {
            svg.classList.add(styles.bubbleIcon);
          }}
        />
      </button>
      <div
        ref={this.backgroundRef}
        className={classNames(styles.background, {[styles.hidden]: !this.state.isShown})}
        onClick={this.hideWidget}
      />
      <Modal
        containerClassName={classNames(styles.modalContainer, {[styles.hidden]: !this.state.isShown})}
        contentClassName={styles.modalContent}
        defaultWidth="25em"
        headerHeight="default"
        defaultLeft="-24.5em"
        defaultTop="0.5ex"
        maxHeight="50vh"
        minHeight="18ex"
        onResize={this.onResize}
        headerContent={header}
      >
        <div className={classNames(styles.addComment, {[styles.hidden]: !this.state.isAddCommentShown})}>
          <AddComment onHide={this.onHideAddComment}/>
        </div>
        <div className={styles.commentsContainer}>
          {comments}
        </div>
      </Modal>
    </div>
    );
  }

  private onResize = (container: HTMLDivElement, direction: ResizeDirection) => {
    if (ResizeDirection.East === (direction & ResizeDirection.East) ||
        ResizeDirection.East === (direction & ResizeDirection.West)) {
      container.style.setProperty('--max-width', 'default');
    }
    if (ResizeDirection.North === (direction & ResizeDirection.North) ||
        ResizeDirection.South === (direction & ResizeDirection.South)) {
      container.style.setProperty('--max-height', 'default');
    }
  }

  private onClickAddComment = () => {
    this.setState({
      isAddCommentShown: true,
    });
  }

  private onHideAddComment = () => {
    this.setState({
      isAddCommentShown: false,
    });
  }

  private showWidget = () => {
    this.setState({
      isShown: true,
    });
  }

  private hideWidget = () => {
    this.setState({
      isShown: false,
    });
  }
}
