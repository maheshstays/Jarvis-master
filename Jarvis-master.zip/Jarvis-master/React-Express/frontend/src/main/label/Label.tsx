import React from 'react';

import styles from './Label.module.css';

interface Props {
  label?: string;
  subLabel?: string;
  children?: never;
}

export default (props: Props) => (
  <div className={styles.container}>
    {props.label != null && <label className={styles.label}>{props.label}</label>}
    {props.subLabel != null && <span>&nbsp;</span>}
    {props.subLabel != null && <label className={styles.subLabel}>{`(${props.subLabel})`}</label>}
  </div>
);
