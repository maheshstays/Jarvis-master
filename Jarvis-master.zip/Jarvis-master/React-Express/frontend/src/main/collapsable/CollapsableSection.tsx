
import classNames from 'classnames';
import React, { Component, createRef, ReactNode, RefObject } from 'react';
import { ReactSVG } from 'react-svg';
import Text from 'react-texty';
import Comment from '../../domain/Comment';
import CommentWidget from '../comment-widget/CommentWidget';
import EllispsisButton from '../ellipsis-button/EllispsisButton';
import Popup from '../popup/Popup';
import { clamp } from '../utils/MathUtils';

import arrow from './assets/arrow.svg';
import styles from './CollapsableSection.module.css';

type ToggleReference = () => void;
interface Props {
  headerClassName?: React.HTMLAttributes<HTMLDivElement>['className'];
  contentClassName?: React.HTMLAttributes<HTMLDivElement>['className'];
  containerClassName?: React.HTMLAttributes<HTMLDivElement>['className'];
  collapsed: boolean;
  header: string;
  headerElement?: React.ReactNode;
  getToggleReference?: (toggleRef: ToggleReference) => void;
  onEllipsisClick?: () => void;
  hideEllipsis: boolean;
  comments?: Comment[];
  hideComments: boolean;
  children: ReactNode;
}

interface State {
  collapsed: boolean;
}

export default class extends Component<Props, State> {
  public static defaultProps = {
    className: undefined,
    collapsed: false,
    header: '',
    hideComments: false,
    hideEllipsis: false,
  };

  private containerRef: RefObject<HTMLDivElement> = createRef<HTMLDivElement>();
  private popupRef: RefObject<Popup> = createRef<Popup>();

  private COLLAPSE_PROGRESS_RATIO: number = 0.2;
  private UPDATE_DELAY_MS: number = 10;

  private currentExpandRatio: number = 1;
  private contentHeight: number = 0;
  private interval?: NodeJS.Timeout;

  constructor(props: Props) {
    super(props);

    this.state = {
      collapsed: props.collapsed,
    };
    this.currentExpandRatio = props.collapsed ? 0 : 1;

    if (props.getToggleReference != null) {
      props.getToggleReference(this.toggleCollapse);
    }
  }

  public render() {
    const DEFAULT_HEADER =
    <div className={classNames(styles.header, this.props.headerClassName, {[styles.collapsed]: this.state.collapsed})}>
      <button className={styles.arrowButton} onClick={this.toggleCollapse}>
        <ReactSVG
          src={arrow}
          className={styles.arrowIconContainer}
          beforeInjection={(svg: Element) => {
            svg.classList.add(styles.arrowIcon);
          }}
        />
      </button>
      <Text tooltipMaxWidth={160} placement="bottom-start" className={styles.headerTitle}>
        {this.props.header}
      </Text>
      <div className={styles.push}/>
      {!this.props.hideComments && this.props.comments && <CommentWidget comments={this.props.comments}/>}
      {!this.props.hideEllipsis && <div className={styles.ellipsisContainer}>
        <EllispsisButton onClick={this.props.onEllipsisClick != null ? this.props.onEllipsisClick : this.showPopup}/>
        <Popup ref={this.popupRef}>
          <div>HelloHelloHelloHello</div>
          <div>HelloHelloHelloHelloHelloHelloHello</div>
          <div>HelloHelloHelloHelloHello</div>
          <div>HelloHelloHelloHelloHelloHelloHello</div>
      </Popup>
      </div>}
    </div>;

    const header = (this.props.headerElement != null) ? this.props.headerElement : DEFAULT_HEADER;

    return (
      <div className={classNames(styles.container, this.props.containerClassName)}>
        {header}
        <div ref={this.containerRef} className={classNames(styles.content, this.props.contentClassName)}>
          {this.props.children}
        </div>
      </div>
    );
  }

  public componentDidMount() {
    this.updateHeight();
    this.updateCollapse();
  }

  public componentWillUnmount() {
    if (this.interval) {
      clearInterval(this.interval);
    }
  }

  public toggleCollapse = () => {
    this.setState({collapsed: !this.state.collapsed});

    if (this.interval) {
      clearInterval(this.interval);
    }

    if (!this.state.collapsed && this.containerRef.current) {
      this.updateHeight();
      this.containerRef.current.style.setProperty('--content-height', this.contentHeight + 'px');
    }

    this.interval = setInterval(() => this.updateCollapse(), this.UPDATE_DELAY_MS);
  }

  private updateHeight = () => {
    if (!this.containerRef.current) {
      return;
    }

    this.containerRef.current.style.setProperty('--content-height', '100%');
    this.contentHeight = this.containerRef.current.clientHeight;
    this.containerRef.current.style.setProperty('--content-height', this.contentHeight + 'px');
  }

  private updateCollapse = () => {
    if (!this.containerRef.current) {
      return;
    }

    const direction = (this.state.collapsed ? -1 : 1);
    this.currentExpandRatio += direction * this.COLLAPSE_PROGRESS_RATIO;
    if (this.currentExpandRatio < 0 || this.currentExpandRatio > 1) {
      this.currentExpandRatio = clamp(this.currentExpandRatio, 0, 1);

      if (this.currentExpandRatio >= 1) {
        this.containerRef.current.style.setProperty('--content-height', '100%');
      }

      if (this.interval) {
        clearInterval(this.interval);
      }
    }

    this.containerRef.current.style.setProperty('--current-collapse-ratio', this.currentExpandRatio.toString());
  }

  private showPopup = () => {
    if (this.popupRef.current) {
      this.popupRef.current.setVisibility(true);
    }
  }
}
