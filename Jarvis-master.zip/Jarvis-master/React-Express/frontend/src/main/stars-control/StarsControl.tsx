import classNames from 'classnames';
import React, { Component } from 'react';
import { ReactSVG } from 'react-svg';

import Label from '../label/Label';
import starFull from './assets/star-full.svg';
import starHalf from './assets/star-half.svg';
import styles from './StarsControl.module.css';

interface Props {
  name: string;
  selectable: boolean;
  score: number;
  label?: string;
  subLabel?: string;
  onChange?: (element: React.ChangeEvent<HTMLInputElement>) => void;
  children?: never;
}

class StarsControl extends Component<Props> {
  private static instanceCount: number = 0;

  constructor(props: Props) {
    super(props);
    StarsControl.instanceCount++;
  }

  public render() {
    const NB_STARS = 10;
    const elements = [];
    const starFullSVG = <ReactSVG src={starFull} className={styles.starSVG}/>;
    const starHalfSVG = <ReactSVG src={starHalf} className={styles.starSVG}/>;
    let id = '';
    for (let i = NB_STARS; i >= 1; i--) {
      id = `star${i}${this.props.name}_${StarsControl.instanceCount}`;
      const className = (i % 2 === 0) ? styles.full : styles.half;
      const icon = (i % 2 === 0) ? starFullSVG : starHalfSVG;
      elements.push(
        <input
          key={`input${i}`}
          type="radio"
          id={id}
          name={this.props.name}
          defaultValue={i}
          disabled={!this.props.selectable}
          defaultChecked={i === this.props.score}
          onChange={this.props.onChange}
        />,
      );
      elements.push(
        <label key={`label${i}`} className={className} htmlFor={id}>{icon}</label>,
      );
    }
    id = `star0${this.props.name}_${StarsControl.instanceCount}`;
    elements.push(<input key="radio0" type="radio" id={id} name={this.props.name} value="0"/>);
    elements.push(<label key="label0" className={styles.zero} htmlFor={id}/>);

    return (
    <div className={styles.container}>
      <Label label={this.props.label} subLabel={this.props.subLabel}/>
      <div className={classNames(styles.uiStar, {[styles.disabled]: !this.props.selectable})}>
        {elements}
      </div>
    </div>
    );
  }
}

export default StarsControl;
