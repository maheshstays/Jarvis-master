import classNames from 'classnames';
import React from 'react';
import { ReactSVG } from 'react-svg';
import DomainContact from '../../domain/Contact';

import skype from './assets/skype.svg';
import styles from './Contact.module.css';

interface Props {
  children?: never;
  contact: DomainContact;
}

export default (props: Props) => (
  <div className={styles.container}>
    <div className={classNames(styles.cell, styles.title)}>{props.contact.role.name}</div>
    <a href={`mailto:${props.contact.email}`} className={classNames(styles.cell, styles.name)}>{props.contact.name}</a>
    <div className={classNames(styles.cell, styles.skype)}>
      <ReactSVG src={skype} className={styles.skypeContainer}/>
      <div className={styles.skypeText}>{props.contact.skype}</div>
    </div>
  </div>
);
