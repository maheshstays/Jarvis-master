import React from 'react';
import DomainContact from '../../domain/Contact';
import Contact from './Contact';

import styles from './Contacts.module.css';

interface Props {
  children?: never;
  contacts: DomainContact[];
}

export default (props: Props) => (
  <div className={styles.container}>
    <div className={styles.headerContainer}>
      <div className={styles.header}>Title</div>
      <div className={styles.header}>Name/Email</div>
      <div className={styles.header}>Skype</div>
    </div>
    <div className={styles.contactsContainer}>
      {props.contacts.map((contact: DomainContact) =>
        <Contact key={contact.email} contact={contact}/>,
      )}
    </div>
  </div>
);
