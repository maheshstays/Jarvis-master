import classNames from 'classnames';
import React from 'react';
import Label from '../label/Label';

import styles from './InputField.module.css';

interface Props {
  children?: never;
  containerClassName?: string;
  inputClassName?: string;
  label?: string;
  min?: number;
  onChange?: (element: React.ChangeEvent<HTMLInputElement>) => void;
  placeholder?: string;
  required?: boolean;
  subLabel?: string;
  type?: 'button' | 'checkbox' | 'color' | 'date' | 'datetime-local' | 'email' | 'file' | 'hidden' | 'image' | 'month' | 'number' | 'password' | 'radio' | 'range' | 'reset' | 'search' | 'submit' | 'tel' | 'text' | 'time' | 'url' | 'week';
  value?: string | string[] | number | boolean;
}

const InputField = (props: Props) => (
  <div className={classNames(styles.container, props.containerClassName)}>
    <Label label={props.label} subLabel={props.subLabel}/>
    <input
      className={classNames(styles.textfield, props.inputClassName)}
      min={props.min}
      onChange={props.onChange}
      placeholder={props.placeholder}
      required={props.required}
      type={props.type == null ? 'text' : props.type}
      value={typeof props.value === 'boolean' ? props.value.toString() : props.value}
    />
  </div>
);

export default InputField;
