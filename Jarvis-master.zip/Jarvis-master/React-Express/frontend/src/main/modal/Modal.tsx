// tslint:disable: no-bitwise
import classNames from 'classnames';
import React, { Component, createRef, MouseEvent, ReactNode, RefObject } from 'react';

import Point from '../utils/Point';
import styles from './Modal.module.css';

interface Props {
  defaultWidth: string;
  defaultHeight: string;
  defaultLeft: string;
  defaultTop: string;
  maxHeight: string;
  minHeight: string;
  maxWidth: string;
  minWidth: string;
  headerHeight: string;
  headerContent?: ReactNode;
  isResizable: boolean;
  isDraggable: boolean;
  containerClassName?: string;
  contentClassName?: string;
  onResize?: (container: HTMLDivElement, direction: ResizeDirection) => void;
  children: ReactNode;
}

export enum ResizeDirection {
  NONE = 0,
  North = 1 << 0,
  South = 1 << 1,
  East = 1 << 2,
  West = 1 << 3,
}

export default class extends Component<Props> {
  public static defaultProps = {
    defaultHeight: 'default',
    defaultLeft: 'default',
    defaultTop: 'default',
    defaultWidth: 'default',
    headerHeight: '3ex',
    isDraggable: true,
    isResizable: true,
    maxHeight: '100vh',
    maxWidth: 'default',
    minHeight: '4ex',
    minWidth: '2em',
  };

  public containerRef: RefObject<HTMLDivElement> = createRef<HTMLDivElement>();
  private startPosition: Point;
  private startOffset: Point;
  private startSize: Point;
  private currentResizeDirection: ResizeDirection;

  constructor(props: Props) {
    super(props);
    this.startPosition = new Point({x: 0, y: 0});
    this.startOffset = new Point({x: 0, y: 0});
    this.startSize = new Point({x: 0, y: 0});
    this.currentResizeDirection = ResizeDirection.NONE;
  }

  public componentDidMount() {
    this.containerRef.current!.style.setProperty('--header-height', this.props.headerHeight);

    this.containerRef.current!.style.setProperty('--width', this.props.defaultWidth);
    this.containerRef.current!.style.setProperty('--height', this.props.defaultHeight);
    this.containerRef.current!.style.setProperty('--left', this.props.defaultLeft);
    this.containerRef.current!.style.setProperty('--top', this.props.defaultTop);
    this.containerRef.current!.style.setProperty('--max-height', this.props.maxHeight);
    this.containerRef.current!.style.setProperty('--min-height', this.props.minHeight);
    this.containerRef.current!.style.setProperty('--max-width', this.props.maxWidth);
    this.containerRef.current!.style.setProperty('--min-width', this.props.minWidth);
  }

  public componentWillUnmount() {
    document.removeEventListener('mousemove', this.updateResize, false);
    document.removeEventListener('mouseup', this.stopResize, false);
    document.removeEventListener('mousemove', this.updateDrag, false);
    document.removeEventListener('mouseup', this.stopDrag, false);
  }

  public render() {
    return (
    <div className={classNames(styles.container, this.props.containerClassName)} ref={this.containerRef}>
      <div
        className={classNames(styles.handle, styles.north)}
        onMouseDown={(e) => {this.handleResizeMouseDown(e, ResizeDirection.North); }}
      />
      <div
        className={classNames(styles.handle, styles.east)}
        onMouseDown={(e) => {this.handleResizeMouseDown(e, ResizeDirection.East); }}
      />
      <div
        className={classNames(styles.handle, styles.south)}
        onMouseDown={(e) => {this.handleResizeMouseDown(e, ResizeDirection.South); }}
      />
      <div
        className={classNames(styles.handle, styles.west)}
        onMouseDown={(e) => {this.handleResizeMouseDown(e, ResizeDirection.West); }}
      />
      <div
        className={classNames(styles.handle, styles.corner, styles.northEast)}
        onMouseDown={(e) => {this.handleResizeMouseDown(e, ResizeDirection.North | ResizeDirection.East); }}
      />
      <div
        className={classNames(styles.handle, styles.corner, styles.southEast)}
        onMouseDown={(e) => {this.handleResizeMouseDown(e, ResizeDirection.South | ResizeDirection.East); }}
      />
      <div
        className={classNames(styles.handle, styles.corner, styles.southWest)}
        onMouseDown={(e) => {this.handleResizeMouseDown(e, ResizeDirection.South | ResizeDirection.West); }}
      />
      <div
        className={classNames(styles.handle, styles.corner, styles.northWest)}
        onMouseDown={(e) => {this.handleResizeMouseDown(e, ResizeDirection.North | ResizeDirection.West); }}
      />

      <div
        className={classNames(styles.header, {[styles.disabled]: !this.props.isDraggable})}
        onMouseDown={this.startDrag}
      >
        {this.props.headerContent}
      </div>
      <div className={classNames(styles.content, this.props.contentClassName)}>
        {this.props.children}
      </div>
    </div>
    );
  }

  public setTopLeft(left: string, top: string) {
    this.containerRef.current!.style.setProperty('--left', left);
    this.containerRef.current!.style.setProperty('--top', top);
  }

  private handleResizeMouseDown = (e: MouseEvent, direction: ResizeDirection) => {
    this.currentResizeDirection = direction;
    this.startResize(e);
  }

  private startResize = (e: MouseEvent) => {
    const parentRect: DOMRect | undefined = this.containerRef.current!.parentElement?.getBoundingClientRect();
    const parentLeft: number = parentRect ? parentRect.left : 0;
    const parentTop: number = parentRect ? parentRect.top : 0;
    this.startOffset = new Point({x: parentLeft, y: parentTop});

    this.startPosition = new Point({x: e.pageX, y: e.pageY});
    const rect: DOMRect = this.containerRef.current!.getBoundingClientRect();
    this.startSize = new Point({x: rect.width, y: rect.height});
    document.addEventListener('mousemove', this.updateResize, false);
    document.addEventListener('mouseup', this.stopResize, false);
  }

  private updateResize = (e: any) => {
    if (ResizeDirection.East === (this.currentResizeDirection & ResizeDirection.East)) {
      const width = (e.pageX - this.startPosition.x) + this.startSize.x;
      this.containerRef.current!.style.setProperty('--width', width + 'px');
    }

    if (ResizeDirection.West === (this.currentResizeDirection & ResizeDirection.West)) {
      const left = this.startPosition.x + (e.pageX - this.startPosition.x) - this.startOffset.x;
      const width = this.startSize.x - (e.pageX - this.startPosition.x);
      this.containerRef.current!.style.setProperty('--left', left + 'px');
      this.containerRef.current!.style.setProperty('--width', width + 'px');
    }

    if (ResizeDirection.South === (this.currentResizeDirection & ResizeDirection.South)) {
      const height = (e.pageY - this.startPosition.y) + this.startSize.y;
      this.containerRef.current!.style.setProperty('--height', height + 'px');
    }

    if (ResizeDirection.North === (this.currentResizeDirection & ResizeDirection.North)) {
      const top = this.startPosition.y + (e.pageY - this.startPosition.y) - this.startOffset.y;
      const height = this.startSize.y - (e.pageY - this.startPosition.y);
      this.containerRef.current!.style.setProperty('--top', top + 'px');
      this.containerRef.current!.style.setProperty('--height', height + 'px');
    }

    if (this.props.onResize && this.containerRef?.current) {
      this.props.onResize(this.containerRef.current, this.currentResizeDirection);
    }
  }

  private stopResize = () => {
    document.removeEventListener('mousemove', this.updateResize, false);
    document.removeEventListener('mouseup', this.stopResize, false);
  }

  private startDrag = (e: MouseEvent) => {
    this.startPosition = new Point({x: e.pageX, y: e.pageY});

    const rect: DOMRect = this.containerRef.current!.getBoundingClientRect();
    const parentRect: DOMRect | undefined = this.containerRef.current!.parentElement?.getBoundingClientRect();
    const parentLeft: number = parentRect ? parentRect.left : 0;
    const parentTop: number = parentRect ? parentRect.top : 0;

    this.startOffset = new Point({
      x: this.startPosition.x - (this.startPosition.x - rect.left) - parentLeft,
      y: this.startPosition.y - (this.startPosition.y - rect.top) - parentTop,
    });

    document.addEventListener('mousemove', this.updateDrag, false);
    document.addEventListener('mouseup', this.stopDrag, false);
  }

  private stopDrag = () => {
    document.removeEventListener('mousemove', this.updateDrag, false);
    document.removeEventListener('mouseup', this.stopDrag, false);
  }

  private updateDrag = (e: any) => {
    const x: number = (e.pageX - this.startPosition.x) + this.startOffset.x;
    const y: number = (e.pageY - this.startPosition.y) + this.startOffset.y;
    this.containerRef.current!.style.setProperty('--left', x + 'px');
    this.containerRef.current!.style.setProperty('--top', y + 'px');
  }
}
