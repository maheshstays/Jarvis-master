import { Link, LinkGetProps } from '@reach/router';
import classNames from 'classnames';
import React from 'react';
import { GoogleLogout } from 'react-google-login';
import { ReactSVG } from 'react-svg';
import { GOOGLE_CLIENT_ID } from '../../constants';
import AuthService from '../../services/relay/AuthService';

import collapsedLogo from './assets/collapsed-logo.svg';
import dashboard from './assets/dashboard.svg';
import logo from './assets/logo.svg';
import search from './assets/search.svg';
import studios from './assets/studios.svg';
import styles from './NavigationMenu.module.css';

interface Props {
  collapsed: boolean;
}

const NavigationMenu = ({ collapsed }: Props) => {
  const itemStyles = ({ isPartiallyCurrent }: LinkGetProps) => ({
    className: classNames(
      styles.item,
      {[styles.active]: isPartiallyCurrent},
    ),
  });

  return (
    <div
      className={
        classNames(
          styles.container,
          {[styles.collapsed]: collapsed},
        )
      }
    >
      <Link id="home" to="/">
        <ReactSVG
          src={collapsed ? collapsedLogo : logo}
          beforeInjection={(svg: Element) => {
            svg.classList.add(styles.svgLogo);
          }}
          className={styles.logo}
        />
      </Link>
      <div className={styles.mainMenu}>
        <Link id="dashboard" to="dashboard" getProps={itemStyles}>
          <ReactSVG
            src={dashboard}
            className={styles.itemIcon}
            beforeInjection={(svg: Element) => {
              svg.classList.add(styles.svgDashboardItemIcon);
            }}
          />
          {!collapsed && 'Dashboard'}
        </Link>
        <Link id="studios" to="studios" getProps={itemStyles}>
          <ReactSVG
            src={studios}
            className={styles.itemIcon}
            beforeInjection={(svg: Element) => {
              svg.classList.add(styles.svgStudiosItemIcon);
            }}
          />
          {!collapsed && 'Studios'}
        </Link>
        <Link id="search" to="search" getProps={itemStyles}>
          <ReactSVG
            src={search}
            className={styles.itemIcon}
            beforeInjection={(svg: Element) => {
              svg.classList.add(styles.svgSearchItemIcon);
            }}
          />
          {!collapsed && 'Search'}
        </Link>
        <div className={styles.logoutButton}>
          <GoogleLogout
            clientId={GOOGLE_CLIENT_ID}
            buttonText="Logout"
            onLogoutSuccess={AuthService.logout}
          />
        </div>
      </div>
    </div>
  );
};

NavigationMenu.defaultProps = {
  collapsed: false,
};

export default NavigationMenu;
