import React from 'react';
import { ReactSVG } from 'react-svg';
import DomainPlatform from '../../domain/Platform';

import styles from './Platform.module.css';

interface Props {
  children?: never;
  platform: DomainPlatform;
}

export default (props: Props) => (
  <div className={styles.container}>
    <ReactSVG src={props.platform.icon} className={styles.platformIcon}/>
    <span className={styles.name}>{props.platform.name}</span>
  </div>
);
