import React, { Component } from 'react';

interface Props {
  cents: number;
  children?: never;
}

class ThousandsSeparatedText extends Component<Props> {
  public static defaultProps = {
    cents: 0,
  };

  public render() {
    if (this.props.cents < 100) {
      return <span>{`$0`}</span>;
    }

    const CENTS_PLACES = 2;
    let str: string = '';
    const strInt: string = this.props.cents.toString();
    let count: number = 0;
    for (let i = strInt.length - 1 - CENTS_PLACES; i >= 0; i--) {

      if (count % 3 === 0 && count !== 0) {
        str = strInt[i] + ',' + str;
      } else {
        str = strInt[i] + str;
      }
      count++;
    }

    return <span>{`$${str}`}</span>;
  }
}

export default ThousandsSeparatedText;
