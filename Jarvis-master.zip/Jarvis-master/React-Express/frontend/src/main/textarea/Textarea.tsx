import classNames from 'classnames';
import React, { Component } from 'react';
import Label from '../label/Label';

import styles from './Textarea.module.css';

interface Props extends React.HTMLProps<HTMLTextAreaElement> {
  label?: string;
  subLabel?: string;
  children?: never;
}

export default class extends Component<Props> {
  private genericProps: any;

  constructor(props: Props) {
    super(props);
    this.genericProps = {};
    Object.entries(props).forEach((entry) => {
      if (entry[0] !== 'label' && entry[0] !== 'subLabel') {
        this.genericProps[entry[0]] = entry[1];
      }
    });
  }

  public render() {
    return (
      <div className={styles.container}>
        <Label label={this.props.label} subLabel={this.props.subLabel}/>
        <textarea {...this.genericProps} className={classNames(styles.textarea, this.props.className)} />
      </div>
    );
  }
}
