import classNames from 'classnames';
import React, {Component} from 'react';
import { ReactSVG } from 'react-svg';

import heart from './assets/heart.svg';
import styles from './FavoriteButton.module.css';

interface Props {
  children?: never;
  projectId: string;
}

interface State {
  selected: boolean;
}

class FavoriteButton extends Component<Props, State> {
  constructor(props: Props) {
    super(props);
    this.state = {
      selected: (props.projectId.charCodeAt(0) % 2 === 0),
    };
  }

  public render() {
    return (
      <button
        className={classNames(styles.container, {[styles.selected]: this.state.selected})}
        onClick={this.handleClick}
      >
        <ReactSVG
          src={heart}
          beforeInjection={(svg: Element) => {
            svg.classList.add(styles.favorite);
          }}
        />
      </button>
    );
  }

  private handleClick = () => {
    this.setState({selected: !this.state.selected});
  }
}

export default FavoriteButton;
