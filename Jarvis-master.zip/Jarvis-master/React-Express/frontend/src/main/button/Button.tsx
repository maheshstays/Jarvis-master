import classNames from 'classnames';
import React, { ButtonHTMLAttributes, Component, createRef, DetailedHTMLProps, ReactNode, RefObject } from 'react';

import styles from './Button.module.css';

export enum ButtonColor {
  Primary,
  Ternary,
}

interface Props extends DetailedHTMLProps<ButtonHTMLAttributes<HTMLButtonElement>, HTMLButtonElement> {
  buttonColor: ButtonColor;
  children?: ReactNode;
}

export default class extends Component<Props> {
  public static defaultProps = {
    buttonColor: ButtonColor.Ternary,
    type: 'button',
  };

  private buttonRef: RefObject<HTMLButtonElement> = createRef<HTMLButtonElement>();
  private genericProps: any;

  constructor(props: Props) {
    super(props);
    this.genericProps = {};
    Object.entries(props).forEach((entry) => {
      if (entry[0] !== 'buttonColor') {
        this.genericProps[entry[0]] = entry[1];
      }
    });
  }

  public componentDidMount() {
    if (this.buttonRef) {
      this.buttonRef.current!.style.setProperty('--background-color',
        this.props.buttonColor === ButtonColor.Ternary ? 'var(--ternary)' : 'var(--primary)');
      this.buttonRef.current!.style.setProperty('--background-color-hover',
        this.props.buttonColor === ButtonColor.Ternary ? 'var(--ternary-hover)' : 'var(--primary-hover)');
      this.buttonRef.current!.style.setProperty('--background-color-active',
        this.props.buttonColor === ButtonColor.Ternary ? 'var(--ternary-active)' : 'var(--primary-active)');
    }
  }

  public render() {
    return (
      <button
        ref={this.buttonRef}
        {...this.genericProps}
        className={classNames(styles.container, this.props.className)}
      >
        {this.props.children}
      </button>
    );
  }
}
