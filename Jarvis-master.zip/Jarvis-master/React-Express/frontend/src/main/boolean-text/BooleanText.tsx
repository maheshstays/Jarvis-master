import React, { Component } from 'react';

interface Props {
  value: boolean;
  trueText: string;
  falseText: string;
  children?: never;
}

export default class extends Component<Props> {
  public static defaultProps = {
    falseText: 'No',
    trueText: 'Yes',
  };

  public render() {
    return <span>{this.props.value ? this.props.trueText : this.props.falseText}</span>;
  }
}
