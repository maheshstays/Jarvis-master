import React from 'react';

interface Props {
  date: number;
  children?: never;
}

export default (props: Props) => {
  const date = new Date(props.date);
  const MONTHS: string[] = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jui', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  const text = `${MONTHS[date.getMonth()]} ${date.getDate()}, ${date.getFullYear()}`;

  return <span>{text}</span>;
};
