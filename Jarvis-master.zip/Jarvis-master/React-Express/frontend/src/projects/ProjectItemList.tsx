import { RouteComponentProps } from '@reach/router';
import classNames from 'classnames';
import React, { Suspense } from 'react';
import Project from '../domain/Project';
import ProjectService from '../services/relay/ProjectService';
import ProjectItem from './ProjectItem';

import stylesGlobal from './global.module.css';
import styles from './ProjectItemList.module.css';

interface Props extends RouteComponentProps<{}> {
  children?: never;
  projects?: Project[];
  studioName: string;
}

export default ({ projects, studioName }: Props) => (
  <div className={styles.container}>

    <div className={styles.header}>
      <div className={stylesGlobal.spacer}/>
      <div className={classNames(styles.headerCell, stylesGlobal.cell, stylesGlobal.cellImage)}>Title</div>
      <div className={classNames(styles.headerCell, stylesGlobal.cell, stylesGlobal.cellTitle)}/>
      <div className={classNames(styles.headerCell, stylesGlobal.cell, stylesGlobal.cellManagedBy)}>Managed By</div>
      <div className={classNames(styles.headerCell, stylesGlobal.cell, stylesGlobal.cellNutakuProducer)}>
        Nutaku Producer
      </div>
      <div className={classNames(styles.headerCell, stylesGlobal.cell, stylesGlobal.cellTier)}>Tier</div>
      <div className={classNames(styles.headerCell, stylesGlobal.cell, stylesGlobal.cellMilestone)}>Milestone</div>
      <div className={classNames(styles.headerCell, stylesGlobal.cell, stylesGlobal.cellFollow)}>Follow</div>
      <div className={stylesGlobal.spacer}/>
    </div>

    <div className={styles.content}>
      <Suspense fallback={<h2>LOADING...</h2>}>
        {(projects ?? ProjectService.fetchProjects(studioName)).map((project: Project) =>
          <ProjectItem key={project.id} project={project} studioName={studioName} />,
        )}
      </Suspense>
   </div>
  </div>
);
