import { Link } from '@reach/router';
import classNames from 'classnames';
import React from 'react';
import Text from 'react-texty';
import Project from '../domain/Project';
import DateText from '../main/date-text/DateText';
import FavoriteButton from './../main/favorite-button/FavoriteButton';

import { NUTAKU_PRODUCER } from '../constants';
import Contact from '../domain/Contact';
import stylesGlobal from './global.module.css';
import styles from './ProjectItem.module.css';

interface Props {
  children?: never;
  project: Project;
  studioName: string;
}

const ProjectItem = ({ project, studioName }: Props) => {
  const producerContact = project.contacts.find((contact: Contact) => contact.role.name === NUTAKU_PRODUCER);

  return (
    <div className={styles.container}>
      <div className={classNames(stylesGlobal.spacer, styles.spacer)}/>
      <div className={styles.imageContainer}>
        <div className={classNames(styles.cell, stylesGlobal.cell, styles.cellImage, stylesGlobal.cellImage)}>
          {project.thumbnailUrl && <img className={styles.gameImage} src={project.thumbnailUrl} alt="Project's thumbnail"/>}
        </div>
      </div>
      <div className={classNames(styles.cell, stylesGlobal.cell, styles.cellTitle, stylesGlobal.cellTitle)}>
        <Link
          id="project"
          to={`/studios/${encodeURIComponent(studioName)}/projects/${encodeURIComponent(project.name)}`}
          className={styles.link}
        >
          <Text className={styles.gameTitle}>
            {project.name}
          </Text>
        </Link>
      </div>
      <div className={classNames(styles.cell, stylesGlobal.cell, styles.cellManagedBy, stylesGlobal.cellManagedBy)}>
        {project.managedBy}
      </div>
      <div className={classNames(styles.cell, stylesGlobal.cell, stylesGlobal.cellNutakuProducer)}>{
        producerContact &&
          <a href={`mailto:${producerContact.email}`}>{producerContact.name ?? producerContact.email.split('@')[0]}</a>
      }</div>
      <div className={classNames(styles.cell, stylesGlobal.cell, stylesGlobal.cellTier)}>
        <div className={styles.tier}>
          {`Tier ${project.tier}`}
        </div>
      </div>
      <div className={classNames(styles.cell, stylesGlobal.cell, stylesGlobal.cellMilestone, styles.cellMilestone)}>
        <span><wbr/></span>
        <div
          className={classNames(styles.statusBackground,
          {[styles.neutral]: project.statusLevel === 'neutral'},
          {[styles.good]: project.statusLevel === 'good'},
          {[styles.warning]: project.statusLevel === 'warning'},
          {[styles.bad]: project.statusLevel === 'bad'})}
        >
          {project.statusName}
        </div>
        <span
          className={classNames(styles.statusText,
          {[styles.neutral]: project.statusLevel === 'neutral'},
          {[styles.good]: project.statusLevel === 'good'},
          {[styles.warning]: project.statusLevel === 'warning'},
          {[styles.bad]: project.statusLevel === 'bad'})}
        >
          <DateText date={project.statusDate}/>
        </span>
      </div>
      <div className={classNames(styles.cell, stylesGlobal.cell, stylesGlobal.cellFollow)}>
        <FavoriteButton projectId={project.id} />
      </div>
      <div className={classNames(stylesGlobal.spacer, styles.spacer)}/>
    </div>
  );
};

export default ProjectItem;
