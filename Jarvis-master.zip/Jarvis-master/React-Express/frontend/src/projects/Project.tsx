import { RouteComponentProps } from '@reach/router';
import React from 'react';
import DomainProject from '../domain/Project';
import ProjectService from '../services/relay/ProjectService';
import GameInformation from './project/GameInformation';
import LegalInformation from './project/LegalInformation';
import Milestones from './project/Milestones';
import PreviousPerformance from './project/PreviousPerformance';
import SidePanel from './project/SidePanel';
import TechnicalInformation from './project/TechnicalInformation';

import styles from './Project.module.css';

interface Props extends RouteComponentProps<{ projectName: string, studioName: string }> {
  children?: never;
}

export default ({ projectName, studioName }: Props) => {
  const noProject =
    <div>
      This project can't be found.
    </div>;

  if (!studioName || !projectName) {
    return noProject;
  }

  const project: DomainProject = ProjectService.fetchProject(studioName, projectName);
  if (!project) {
    return noProject;
  }

  return(
  <div className={styles.container}>
    <div className={styles.sidePanel}>
      <SidePanel project={project} studioName={studioName}/>
    </div>
    <div className={styles.content}>
      <div className={styles.sectionContainer}>
        <GameInformation projectId={project.id} comments={project.gameInformationComments}/>
      </div>
      <div className={styles.sectionContainer}>
        <PreviousPerformance projectId={project.id} comments={project.previousPerformanceComments}/>
      </div>
      <div className={styles.sectionContainer}>
        <TechnicalInformation project={project}/>
      </div>
      <div className={styles.sectionContainer}>
        <LegalInformation legalInformation={project.legalInformation}/>
      </div>
      <div className={styles.sectionContainer}>
        <Milestones milestones={project.milestones} comments={project.milestonesComments}/>
      </div>
    </div>
  </div>
  );
};
