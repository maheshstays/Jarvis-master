import React, { Component, createRef, RefObject } from 'react';
import InputField from '../../main/input-field/InputField';
import Popup from '../../main/popup/Popup';
import ProjectService from '../../services/relay/ProjectService';

interface Props {
  children?: never;
  studioId: string;
}

interface State {
  projectName: string;
}

export default class extends Component<Props, State> {
  public state: State = {
    projectName: '',
  };

  private popupRef: RefObject<Popup> = createRef<Popup>();

  public render() {
    return (
      <Popup
        ref={this.popupRef}
        extraButtons={[{ onClick: this.submit, text: 'Submit'}]}
      >
        <InputField
          label="Project Name"
          onChange={this.handleInputEdit('projectName')}
          value={this.state.projectName}
        />
      </Popup>
    );
  }

  public setVisibility(isVisible: boolean) {
    this.popupRef.current?.setVisibility(isVisible);
  }

  private handleInputEdit = (field: keyof State) => (event: React.ChangeEvent<HTMLInputElement>) => {
    this.setState({ [field]: event.target.value } as unknown as State);
  }

  private submit = () => {
    ProjectService.createProject(
      this.props.studioId,
      {
        name: this.state.projectName,
      },
      () => { this.popupRef.current?.setVisibility(false); window.location.reload(); },
      () => null, // TO DO: Error handling
    );
  }
}
