import React from 'react';
import DomainPlatformPerformance from '../../domain/PlatformPerformance';
import Platform from '../../main/platform/Platform';
import StarsControl from '../../main/stars-control/StarsControl';
import ThousThousandsSeparatedText from '../../main/thousands-separated-text/ThousandsSeparatedText';

import styles from './PlatformPerformance.module.css';

interface Props {
  children?: never;
  platformPerformance: DomainPlatformPerformance;
}

export default (props: Props) => (
  <div className={styles.container}>
    <Platform platform={props.platformPerformance.platform}/>
    <span className={styles.downloadsHeader}>Downloads</span>
    <span className={styles.downloads}>
      <ThousThousandsSeparatedText number={props.platformPerformance.downloads}/>
    </span>
    <StarsControl
      name={`rating-${props.platformPerformance.platform.name}`}
      score={props.platformPerformance.rating}
      selectable={false}
    />
  </div>
);
