import React from 'react';
import Comment from '../../domain/Comment';
import CollapsableSection from '../../main/collapsable/CollapsableSection';
import Contacts from '../../main/contacts/Contacts';
import PermissionService from '../../services/relay/PermissionService';

import styles from './GameInformation.module.css';

interface Props {
  children?: never;
  comments: Comment[];
  projectId: string;
}

export default (props: Props) => (
  <CollapsableSection
    contentClassName={styles.container}
    header="Game Information"
    comments={props.comments}
  >
      <div className={styles.whiteSpace}/>
      <div className={styles.contacts}>
        <Contacts contacts={PermissionService.fetchContactsForProject(props.projectId)}/>
      </div>
  </CollapsableSection>
);
