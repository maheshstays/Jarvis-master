import React from 'react';
import { ReactSVG } from 'react-svg';

import styles from './ImportantLink.module.css';

interface Props {
  icon: string;
  text: string;
  url: string;
  children?: never;
}

export default (props: Props) => (
  <a className={styles.container} href={props.url} target="_blank" rel="noopener noreferrer">
    <ReactSVG className={styles.icon} src={props.icon}/>
    <span className={styles.text}>{props.text}</span>
  </a>
);
