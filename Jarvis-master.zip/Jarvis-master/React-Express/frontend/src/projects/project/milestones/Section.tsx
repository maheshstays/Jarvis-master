import React, { ReactNode } from 'react';

import styles from './Section.module.css';

interface Props {
  title: string;
  children: ReactNode;
}

export default (props: Props) => (
  <div className={styles.container}>
    <div className={styles.header}>
      <p className={styles.title}>{props.title}</p>
    </div>
    <div className={styles.content}>
      {props.children}
    </div>
  </div>
);
