import React from 'react';
import { ReactSVG } from 'react-svg';
import DomainDeliverable from '../../../domain/milestones/Deliverable';
import Deliverable from './Deliverable';
import Section from './Section';

import Button, { ButtonColor } from '../../../main/button/Button';
import plus from '../assets/plus.svg';
import styles from './Deliverables.module.css';

interface Props {
  deliverables: DomainDeliverable[];
  children?: never;
}

export default ({deliverables}: Props) => {
  return (
    <Section title="Deliverables">
    {
      deliverables.map((deliverable) => (
        <div key={deliverable.id} className={styles.row}>
          <Deliverable deliverable={deliverable}/>
        </div>
      ))
    }
    <div className={styles.row}>
      <Button buttonColor={ButtonColor.Primary} className={styles.addButton}>
        <ReactSVG className={styles.plusIcon} src={plus}/>
        <span className={styles.buttonText}>Add Deliverable</span>
      </Button>
    </div>
  </Section>
  );
};
