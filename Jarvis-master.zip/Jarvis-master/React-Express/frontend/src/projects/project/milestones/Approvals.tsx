import React from 'react';
import DomainApproval from '../../../domain/milestones/Approval';
import Approval from './Approval';
import Section from './Section';

import styles from './Approvals.module.css';

interface Props {
  approvals: DomainApproval[];
  children?: never;
}

export default ({approvals}: Props) => {
  return (
    <Section title="Approvals"> {
      approvals.map((approval) => (
        <div key={approval.id} className={styles.row}>
          <Approval approval={approval} />
        </div>
      ))
    }
    </Section>
  );
};
