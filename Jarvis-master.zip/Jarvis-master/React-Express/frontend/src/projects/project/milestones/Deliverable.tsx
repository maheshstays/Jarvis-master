import classNames from 'classnames';
import React, { Component } from 'react';
import { ReactSVG } from 'react-svg';
import DomainDeliverable, { DeliverableStatus } from '../../../domain/milestones/Deliverable';

import deliverableStatus from './assets/deliverable-status.svg';
import styles from './Deliverable.module.css';

interface Props {
  deliverable: DomainDeliverable;
  children?: never;
}

interface State {
  editing: boolean;
  name: string;
  description: string;
  status: DeliverableStatus;
}

export default class extends Component<Props, State> {
  private statusText = [] as string[];

  constructor(props: Props) {
    super(props);
    this.state = {
      description: this.props.deliverable.description,
      editing: false,
      name: this.props.deliverable.name,
      status: this.props.deliverable.status,
    };

    this.statusText[DeliverableStatus.Delivered] = 'Paid';
    this.statusText[DeliverableStatus.Late] = 'Late';
    this.statusText[DeliverableStatus.ToBeDelivered] = 'To be Delivered';
  }

  public render() {
    const statusOptions: JSX.Element[] = [];
    for (let i = 0; i < this.statusText.length; i++) {
      statusOptions.push(<option key={i} value={i}>{this.statusText[i]}</option>);
    }
    console.log('[' + this.state.name + '] Using value: ' + this.state.status);
    return (
    <div className={styles.container}> {
      this.state.editing ?
      <select defaultValue={this.state.status} onChange={this.handleSelectEdit('status')}>
        {statusOptions}
      </select>
      :
      <ReactSVG
        className={classNames(
          styles.statusIcon,
          {[styles.delivered]: this.state.status === DeliverableStatus.Delivered},
          {[styles.toBeDelivered]: this.state.status === DeliverableStatus.ToBeDelivered},
          {[styles.late]: this.state.status === DeliverableStatus.Late})}
        src={deliverableStatus}
      />
      } <p className={styles.name}>{
        this.state.editing ?
          <input type="text" defaultValue={this.state.name} onChange={this.handleEdit('name')}/> :
          this.state.name
      }
      </p>
      <p className={styles.description}>{
        this.state.editing ?
          <input
            type="text"
            className={styles.rightInput}
            defaultValue={this.state.description}
            onChange={this.handleEdit('description')}
          />
          :
          this.state.description
      }</p>
      <p className={styles.edit} onClick={this.handleAction}>{this.state.editing ? ('Save') : ('Edit')}</p>
    </div>
    );
  }

  private handleAction = () => {
    if (this.state.editing) {
      // TODO: Save to backend
    }
    this.setState({ editing: !this.state.editing });
  }

  private handleSelectEdit = (field: keyof State) => (event: React.ChangeEvent<HTMLSelectElement>) => {
    this.setState({[field]: parseInt(event.target.value, 10)} as unknown as State);
  }

  private handleEdit = (field: keyof State) => (event: React.ChangeEvent<HTMLInputElement>) => {
    this.setState({ [field]: event.target.value } as unknown as State);
  }
}
