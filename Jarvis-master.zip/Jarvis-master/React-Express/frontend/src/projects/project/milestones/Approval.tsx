import React, { Component } from 'react';
import DomainApproval, { ApprovalStatus } from '../../../domain/milestones/Approval';
import ApprovalStatusIcon from './ApprovalStatusIcon';

import styles from './Approval.module.css';

interface Props {
  approval: DomainApproval;
  children?: never;
}

interface State {
  editing: boolean;
  status: ApprovalStatus;
  comment: string;
}

export default class extends Component<Props, State> {
  private statusText = [] as string[];

  constructor(props: Props) {
    super(props);
    this.state = {
      comment: this.props.approval.comment,
      editing: false,
      status: this.props.approval.status,
    };

    this.statusText[ApprovalStatus.Approved] = 'Paid';
    this.statusText[ApprovalStatus.Denied] = 'Denied';
    this.statusText[ApprovalStatus.NeedMoreInfo] = 'Need More Info';
  }

  public render() {
    const approvalStatusOptions: JSX.Element[] = [];
    for (let i = 0; i < this.statusText.length; i++) {
      approvalStatusOptions.push(<option key={i} value={i}>{this.statusText[i]}</option>);
    }

    return (
    <div className={styles.container}> {
        this.state.editing ?
        <p><select onChange={this.handleSelectEdit('status')}> {approvalStatusOptions} </select></p> :
        <ApprovalStatusIcon status={this.state.status}/>
      }{!this.state.editing ?
        <div className={styles.approver}>
          <p className={styles.approverName}>{this.props.approval.approverName}</p>
          <p className={styles.approverRole}>{this.props.approval.role.name}</p>
        </div> :
        null
      }<p className={styles.comment}>{
        this.state.editing ?
          <input
            type="text"
            className={styles.rightInput}
            defaultValue={this.state.comment}
            onChange={this.handleEdit('comment')}
          /> :
          ( this.state.comment)
      }</p>
      <p className={styles.edit} onClick={this.handleAction}>{this.state.editing ? ('Save') : ('Edit')}</p>
    </div>
    );
  }

  private handleAction = () => {
    if (this.state.editing) {
      // TODO: Save to backend
    }
    this.setState({ editing: !this.state.editing });
  }

  private handleSelectEdit = (field: keyof State) => (event: React.ChangeEvent<HTMLSelectElement>) => {
    this.setState({[field]: parseInt(event.target.value, 10)} as unknown as State);
  }

  private handleEdit = (field: keyof State) => (event: React.ChangeEvent<HTMLInputElement>) => {
    this.setState({ [field]: event.target.value } as unknown as State);
  }
}
