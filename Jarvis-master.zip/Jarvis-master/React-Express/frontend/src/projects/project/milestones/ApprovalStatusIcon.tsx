import classNames from 'classnames';
import React, { Component } from 'react';
import { ReactSVG } from 'react-svg';
import { ApprovalStatus } from '../../../domain/milestones/Approval';

import styles from './ApprovalStatusIcon.module.css';
import approved from './assets/approval-approved.svg';
import denied from './assets/approval-denied.svg';
import needMoreInfo from './assets/approval-need-more-info.svg';

interface Props {
  status: ApprovalStatus;
  children?: never;
}

export default class extends Component<Props> {
  private ICON_PER_STATUS: Record<ApprovalStatus, string> = {
    [ApprovalStatus.Approved]: approved,
    [ApprovalStatus.Denied]: denied,
    [ApprovalStatus.NeedMoreInfo]: needMoreInfo,
  };

  public render() {
    return (
    <div>
      <ReactSVG
        className={classNames(
          styles.statusIcon,
          {[styles.approved]: this.props.status === ApprovalStatus.Approved},
          {[styles.needMoreInfo]: this.props.status === ApprovalStatus.NeedMoreInfo},
          {[styles.denied]: this.props.status === ApprovalStatus.Denied})}
        src={this.ICON_PER_STATUS[this.props.status]}
      />
    </div>
    );
  }
}
