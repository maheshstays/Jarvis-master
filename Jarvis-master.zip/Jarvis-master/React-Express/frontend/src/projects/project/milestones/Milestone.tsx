import classNames from 'classnames';
import React, { Component } from 'react';
import { ReactSVG } from 'react-svg';
import DomainMilestone from '../../../domain/milestones/Milestone';
import { PaymentStatus } from '../../../domain/milestones/Milestone';
import CollapsableSection from '../../../main/collapsable/CollapsableSection';
import DateText from '../../../main/date-text/DateText';
import DollarText from '../../../main/dollar-text/DollarText';
import Approvals from './Approvals';
import Deliverables from './Deliverables';

import arrow from './assets/arrow.svg';
import styles from './Milestone.module.css';

interface Props {
  milestone: DomainMilestone;
  isActive: boolean;
  children?: never;
}

interface State {
  expanded: boolean;
  editing: boolean;
  name: string;
  dueDate?: number;
  approvalDate?: number;
  paymentAmount?: number;
  paymentStatus?: PaymentStatus;
}

export default class extends Component<Props, State> {
  private toggleFunctionReference?: () => void;
  private statusText = [] as string[];

  constructor(props: Props) {
    super(props);
    this.state = {
      approvalDate: this.props.milestone.approvalDate,
      dueDate: this.props.milestone.dueDate,
      editing: false,
      expanded: false,
      name: this.props.milestone.name,
      paymentAmount: this.props.milestone.paymentAmount,
      paymentStatus: this.props.milestone.paymentStatus,
    };

    this.statusText[PaymentStatus.Paid] = 'Paid';
    this.statusText[PaymentStatus.SentToAccounting] = 'Sent to Accounting';
  }

  public render() {
    const paymentStatusOptions: JSX.Element[] = [];
    for (let i = 0; i < this.statusText.length; i++) {
      paymentStatusOptions.push(<option key={i} value={i}>{this.statusText[i]}</option>);
    }

    const header =
    <div className={styles.header}>
      <div><div className={styles.rowSelector}/></div>
      <div className={styles.arrow}>
        <ReactSVG className={styles.icon} src={arrow}/>
      </div>
      <div className={styles.headerTexts}>
        <div
          className={classNames(styles.nameContainer, {[styles.editing]: this.state.editing})}
          onClick={this.handleClick}
        >
          <p className={classNames(styles.title, styles.name)}> {
          this.state.editing ?
          <input type="text" defaultValue={this.state.name} onChange={this.handleEdit('name')}/> :
          this.state.name
          }</p>
        </div>
        <p className={classNames(styles.title, styles.dueDate)}>{
          this.state.editing ?
          <input
            type="date"
            defaultValue={this.state.dueDate && new Date(this.state.dueDate).toISOString().substring(0, 10)}
            onChange={this.handleEditDate('dueDate')}
          />
          :
          this.state.dueDate && <DateText date={this.state.dueDate}/>
        }</p>
        <p className={classNames(styles.title, styles.approvalDate)}>{
          this.state.editing ?
          <input
            type="date"
            defaultValue={this.state.approvalDate && new Date(this.state.approvalDate).toISOString().substring(0, 10)}
            onChange={this.handleEditDate('approvalDate')}
          />
          :
          this.state.approvalDate && <DateText date={this.state.approvalDate}/>
        }</p>
        <p className={classNames(styles.title, styles.payment)}> {
          this.state.editing ?
          <input
            type="number"
            defaultValue={
              (this.state.paymentAmount != null) ?
              parseInt((this.state.paymentAmount / 100).toString(), 10) :
              0}
            onChange={this.handleCentsEdit('paymentAmount')}
          />
          :
          <DollarText cents={this.state.paymentAmount}/>
        }
        </p>
        <p className={classNames(styles.title, styles.status)}> {
          this.state.editing ?
          <select defaultValue={this.state.paymentStatus} onChange={this.handleSelectEdit('paymentStatus')}>
            {paymentStatusOptions}
          </select>
          :
          this.statusText[this.state.paymentStatus as number]
        }
        </p>
        <p className={classNames(styles.title, styles.action)} onClick={this.handleAction}>
          {this.state.editing ? ('Save') : ('Edit')}
        </p>
      </div>
    </div>;

    return (
    <CollapsableSection
      headerElement={header}
      getToggleReference={this.getToggleReference}
      containerClassName={classNames(
        styles.container,
        {[styles.expanded]: this.state.expanded},
        {[styles.active]: this.props.isActive})}
      collapsed={true}
    >
      <Deliverables deliverables={this.props.milestone.deliverables}/>
      <div className={styles.spacer}/>
      <Approvals approvals={this.props.milestone.approvals}/>
    </CollapsableSection>
    );
  }

  private getToggleReference = (toggleFunctionReference: () => void) => {
    this.toggleFunctionReference = toggleFunctionReference;
  }

  private handleClick = () => {
    if (this.state.editing) {
      return;
    }

    this.setState({expanded: !this.state.expanded});
    this.toggleFunctionReference!();
  }

  private handleAction = () => {
    if (this.state.editing) {
      // TODO: Save to backend
    }
    this.setState({
      editing: !this.state.editing,
    });
  }

  private handleSelectEdit = (field: keyof State) => (event: React.ChangeEvent<HTMLSelectElement>) => {
    this.setState({[field]: parseInt(event.target.value, 10)} as unknown as State);
  }

  private handleEdit = (field: keyof State) => (event: React.ChangeEvent<HTMLInputElement>) => {
    this.setState({ [field]: event.target.value } as unknown as State);
  }

  private handleCentsEdit = (field: keyof State) => (event: React.ChangeEvent<HTMLInputElement>) => {
    this.setState({ [field]: parseInt(event.target.value, 10) * 100 } as unknown as State);
  }

  private handleEditDate = (field: keyof State) => (event: React.ChangeEvent<HTMLInputElement>) => {
    if (event.target.value == null || event.target.value === '')  {
      this.setState({ [field]: null } as unknown as State);
    } else {
      this.setState({ [field]: new Date(Date.parse(event.target.value)) } as unknown as State);
    }
  }
}
