import classNames from 'classnames';
import React, { Component } from 'react';
import { ReactSVG } from 'react-svg';
import Comment from '../../domain/Comment';
import DomainMilestone, { PaymentStatus } from '../../domain/milestones/Milestone';
import Button, { ButtonColor } from '../../main/button/Button';
import CollapsableSection from '../../main/collapsable/CollapsableSection';
import Milestone from './milestones/Milestone';

import plus from './assets/plus.svg';
import styles from './Milestones.module.css';

interface Props {
  milestones: DomainMilestone[];
  comments: Comment[];
  children?: never;
}

export default class extends Component<Props> {

  public render() {
    const header =
    <div className={styles.header}>
      <div className={styles.spacer}/>
      <div className={classNames(styles.title, styles.name)}>Milestone</div>
      <div className={classNames(styles.title, styles.dueDate)}>Date</div>
      <div className={classNames(styles.title, styles.approvalDate)}>Approval Date</div>
      <div className={classNames(styles.title, styles.payment)}>Payment</div>
      <div className={classNames(styles.title, styles.status)}>Status</div>
      <div className={classNames(styles.title, styles.action)}>Action</div>
    </div>;

    let milestones: JSX.Element[] = [];
    if (this.props.milestones.length > 0) {
      let prevMilestone = this.props.milestones[0];
      let foundActive = false;
      milestones = this.props.milestones.map((milestone) => {
        const isActive = !foundActive && this.isMilestoneActive(prevMilestone, milestone);
        if (isActive) {
          foundActive = true;
        }
        prevMilestone = milestone;
        return <Milestone key={milestone.id} isActive={isActive} milestone={milestone}/>;
      });
    }

    return (
    <CollapsableSection
      contentClassName={styles.container}
      header="Milestones"
      comments={this.props.comments}
    >
      {header}
      {milestones}
      <Button buttonColor={ButtonColor.Primary} className={styles.addButton}>
        <ReactSVG className={styles.plusIcon} src={plus}/>
        <p className={styles.buttonText}>Add Milestone</p>
      </Button>
    </CollapsableSection>
    );
  }

  private isMilestoneActive(previousMilestone: DomainMilestone, milestone: DomainMilestone): boolean {
      return (previousMilestone.paymentStatus === PaymentStatus.Paid ||
              previousMilestone.paymentStatus === PaymentStatus.SentToAccounting) &&
             milestone.paymentStatus == null;
  }
}
