import classNames from 'classnames';
import React from 'react';
import Comment from '../../domain/Comment';
import DomainPlatformPerformance from '../../domain/PlatformPerformance';
import DomainPreviousPerformance from '../../domain/PreviousPerformance';
import CollapsableSection from '../../main/collapsable/CollapsableSection';
import ProjectService from '../../services/relay/ProjectService';
import PlatformPerformance from './PlatformPerformance';

import styles from './PreviousPerformance.module.css';

interface Props {
  children?: never;
  projectId: string;
  comments: Comment[];
}

const PreviousPerformance: React.StatelessComponent<Props> = (props: Props) => {

  const previousPerformance: DomainPreviousPerformance = ProjectService.fetchPreviousPerformance(props.projectId);
  const NB_COLUMNS = 3;
  const columns = [];
  for (let i = 0; i < NB_COLUMNS; i++) {
    if (i < previousPerformance.platformsPerformance.length) {
      const domainPerformance: DomainPlatformPerformance = previousPerformance.platformsPerformance[i];
      columns.push(
        <div key={domainPerformance.id} className={styles.platform}>
          <PlatformPerformance platformPerformance={domainPerformance} />
        </div>,
      );
    } else {
      columns.push(<div key={`empty-${i}`} className={styles.platform}/>);
    }
  }
  const platformsPerformances = <div className={styles.platformsContainer}>{columns}</div>;

  return (
  <CollapsableSection
    comments={props.comments}
    contentClassName={styles.container}
    header="Previous Performance"
  >
    <div className={classNames(styles.infoContainer)}>
      <div className={styles.infoItem}>
        <span className={styles.infoTitle}>Previous Game Reference</span>
        <a href={previousPerformance.referenceUrl} target="_blank" rel="noopener noreferrer">
          {previousPerformance.referenceUrl}
        </a>
      </div>
      <div className={styles.infoItem}>
        <span className={styles.infoTitle}>Previous Game Trailer</span>
        <a href={previousPerformance.trailerUrl} target="_blank" rel="noopener noreferrer">
          {previousPerformance.trailerUrl}
        </a>
      </div>
    </div>
    {platformsPerformances}
  </CollapsableSection>
  );
};

export default PreviousPerformance;
