import React, { Component } from 'react';
import { ReactSVG } from 'react-svg';
import KPIDomain from '../../domain/KPI';

import kpi from './assets/kpi.svg';
import styles from './KPI.module.css';

interface Props {
  kpi: KPIDomain;
  children?: never;
}

class KPI extends Component<Props> {
  public render() {
    return (
    <div className={styles.container}>
      <div className={styles.textContainer}>
        <span className={styles.progress}>{this.ratioToPercent(this.props.kpi.progressRatio)}</span>
        <span className={styles.name}>{this.props.kpi.name}</span>
      </div>
      <ReactSVG src={kpi} className={styles.graphic}/>
    </div>
    );
  }

  private ratioToPercent = (ratio: number): string => {
    return `${Math.trunc(ratio * 100).toString()}%`;
  }
}

export default KPI;
