import { Link } from '@reach/router';
import classNames from 'classnames';
import React from 'react';
import Project from '../../domain/Project';
import CollapsableSection from '../../main/collapsable/CollapsableSection';
import DateText from '../../main/date-text/DateText';
import DollarText from '../../main/dollar-text/DollarText';
import EllispsisButton from '../../main/ellipsis-button/EllispsisButton';
import FavoriteButton from '../../main/favorite-button/FavoriteButton';
import ImportantLink from './ImportantLink';
import KPI from './KPI';

import discord from './assets/discord.svg';
import googleDrive from './assets/google-drive.svg';
import jira from './assets/jira.svg';
import playfab from './assets/playfab.svg';
import styles from './SidePanel.module.css';

interface Props {
  children?: never;
  project: Project;
  studioName: string;
}

export default (props: Props) => (
  <div className={styles.container}>
    <div className={styles.topContent}>
      <div className={styles.imageSection}>
        <div className={styles.ellipsisContainer}><EllispsisButton/></div>
        <div className={styles.imageContainer}>
          {props.project.thumbnailUrl && <img className={styles.image} src={props.project.thumbnailUrl} alt="Project's thumbnail" />}
        </div>
      </div>
    </div>
    <div className={styles.bottomContent}>
      <div className={styles.projectTitleContainer}>
        <Link
          id="studio"
          to={`/studios/${encodeURIComponent(props.studioName)}`}
        >
          {props.studioName}
        </Link>
        <div className={styles.projectTitleRow}>
          <div className={styles.projectTitle}>{props.project.name}</div>
          <div className={styles.push}/>
          <div className={styles.favorite}><FavoriteButton projectId={props.project.id}/></div>
        </div>
      </div>
      <div className={styles.blocksContainer}>
        <div className={styles.blockRow}>
          <div className={styles.block}>
            <p className={styles.title}>Total Investment</p>
            <p className={styles.text}><DollarText cents={123456789}/></p>
          </div>
          <div className={styles.block}>
            <span className={styles.title}>Revenue Share</span>
            <div className={styles.revenueShare}>
              <p className={styles.text}>40/30/30</p>
              <p className={styles.revenueShareDetail}>(PL/NP/DV)</p>
            </div>
          </div>
        </div>

        <div className={styles.blockRow}>
          <div className={styles.block}>
            <p className={styles.title}>Game Advance</p>
            <p className={styles.text}><DollarText cents={12345}/></p>
          </div>
          <div className={styles.block}>
            <p className={styles.title}>Recoupable Balance</p>
            <p className={styles.text}><DollarText cents={1234}/></p>
          </div>
        </div>

        <div className={styles.blockRow}>
          <div className={styles.block}>
            <p className={styles.title}>Another Item</p>
            <p className={styles.text}><DollarText cents={123}/></p>
          </div>
          <div className={styles.block}>
            <p className={styles.title}>One More Item</p>
            <p className={styles.text}><DollarText cents={12}/></p>
          </div>
        </div>
      </div>

      <div className={styles.stateContainer}>
        <div className={styles.tierContainer}>
          <p className={styles.tierTitle}>Tier</p>
          <p className={styles.tier}>{props.project.tier}</p>
        </div>
        <div className={styles.statusContainer}>
          <div
            className={classNames(styles.statusBackground,
            {[styles.neutral]: props.project.statusLevel === 'neutral'},
            {[styles.good]: props.project.statusLevel === 'good'},
            {[styles.warning]: props.project.statusLevel === 'warning'},
            {[styles.bad]: props.project.statusLevel === 'bad'})}
          >
            <p>{props.project.statusName}</p>
            <p><DateText date={props.project.statusDate}/></p>
          </div>
        </div>
      </div>

      <div className={styles.kpiContainer}>
        <div className={styles.kpi}><KPI kpi={props.project.projectCompletionKPI}/></div>
        <div className={styles.kpi}><KPI kpi={props.project.totalFundingKPI}/></div>
      </div>
    </div>
    <CollapsableSection
      headerClassName={styles.linksHeader}
      contentClassName={styles.linksContent}
      containerClassName={styles.linksContainer}
      collapsed={true}
      hideComments={true}
      hideEllipsis={true}
      header="Important Links"
    >
      <div className={styles.linkColumn}>
        <div className={styles.link}>
          <ImportantLink url={props.project.googleDriveUrl} icon={googleDrive} text="Project Drive"/>
        </div>
        <div className={styles.link}>
          <ImportantLink url={props.project.jiraUrl} icon={jira} text="Jira Project"/>
        </div>
      </div>
      <div className={styles.linkColumn}>
        <div className={styles.link}>
          <ImportantLink url={props.project.playfabUrl} icon={playfab} text="PlayFab"/>
        </div>
        <div className={styles.link}>
          <ImportantLink url={props.project.discordUrl} icon={discord} text="Discord"/>
        </div>
      </div>
    </CollapsableSection>
  </div>
);
