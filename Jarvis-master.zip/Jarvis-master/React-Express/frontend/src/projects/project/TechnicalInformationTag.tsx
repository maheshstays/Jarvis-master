import React from 'react';

import styles from './TechnicalInformationTag.module.css';

interface Props {
  children?: never;
  text: string;
}

export default (props: Props) => (
  <div className={styles.container}>
    {props.text}
  </div>
);
