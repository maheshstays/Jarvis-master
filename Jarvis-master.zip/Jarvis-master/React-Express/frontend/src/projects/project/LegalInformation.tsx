import React from 'react';
import DomainLegalInformation from '../../domain/LegalInformation';
import BooleanText from '../../main/boolean-text/BooleanText';
import CollapsableSection from '../../main/collapsable/CollapsableSection';
import DateText from '../../main/date-text/DateText';

import styles from './LegalInformation.module.css';

interface Props {
  legalInformation: DomainLegalInformation;
  children?: never;
}

export default (props: Props) => (
  <CollapsableSection
    contentClassName={styles.container}
    header="Legal Information"
    comments={props.legalInformation.comments}
  >
    <div className={styles.row}>
      <div className={styles.block}>
        <span className={styles.title}>Publishing Agreement</span>
        <span className={styles.text}>Signed:&nbsp;
          <BooleanText value={props.legalInformation.publishingSignatureDate != null}/>
        </span>
        { props.legalInformation.publishingSignatureDate != null &&
          <span className={styles.text}>
            Signature Date: <DateText date={props.legalInformation.publishingSignatureDate}/>
          </span>
        }
      </div>
      <div className={styles.block}>
        <span className={styles.title}>Publisher</span>
        <span className={styles.text}>{props.legalInformation.publisher}</span>
      </div>
      <div className={styles.block}>
        <span className={styles.title}>IP Holder</span>
        <span className={styles.text}>{props.legalInformation.ipHolder}</span>
      </div>
      <div className={styles.block}>
        <span className={styles.title}>Advance By</span>
        <span className={styles.text}>{props.legalInformation.advanceBy}</span>
      </div>
    </div>
    <div className={styles.row}>
      <div className={styles.block}>
        <span className={styles.title}>Nutaku.net Agreement</span>
        <span className={styles.text}>Signed:&nbsp;
          <BooleanText value={props.legalInformation.nutakuSignatureDate != null}/>
        </span>
        { props.legalInformation.nutakuSignatureDate != null &&
          <span className={styles.text}>
            Signature Date: <DateText date={props.legalInformation.nutakuSignatureDate}/>
          </span>
        }
      </div>
      <div className={styles.block}>
        <span className={styles.title}>Is Exclusive</span>
        <span className={styles.text}><BooleanText value={props.legalInformation.isExclusive}/></span>
      </div>
      <div className={styles.block}>
        <span className={styles.title}>Nutaku Pays Free Gold</span>
        <span className={styles.text}><BooleanText value={props.legalInformation.paysFreeGold}/></span>
      </div>
      <div className={styles.block}>
        <span className={styles.title}>Has Bizdev Commission</span>
        <span className={styles.text}><BooleanText value={props.legalInformation.hasBizDevCommission}/></span>
      </div>
    </div>
  </CollapsableSection>
);
