import React, { Component } from 'react';
import Project from '../../domain/Project';
import TechnicalInformationDomain from '../../domain/TechnicalInformation';
import BooleanText from '../../main/boolean-text/BooleanText';
import CollapsableSection from '../../main/collapsable/CollapsableSection';
import ProjectService from '../../services/relay/ProjectService';
import Tag from './TechnicalInformationTag';

import styles from './TechnicalInformation.module.css';

interface Props {
  children?: never;
  project: Project;
}

export default class extends Component<Props> {

  public render() {
    const projectId: string = this.props.project.id;
    const technicalInformation: TechnicalInformationDomain = ProjectService.fetchTechnicalInformation(projectId);

    return (
    <CollapsableSection
      comments={this.props.project.technicalInformationComments}
      contentClassName={styles.container}
      header="Technical Information"
    >
      <div className={styles.row}>
        <div className={styles.block}>
          <span className={styles.title}>Languages</span>
          <div className={styles.tags}>
            {this.textToTag(technicalInformation.languages)}
          </div>
        </div>
        <div className={styles.block}>
          <span className={styles.title}>Category</span>
          <div className={styles.tags}>
            {this.textToTag(technicalInformation.categories)}
          </div>
        </div>
        <div className={styles.block}>
          <span className={styles.title}>Engine</span>
          <span className={styles.text}>{technicalInformation.engine}</span>
        </div>
        <div className={styles.block}>
          <span className={styles.title}>Cross Save State</span>
          <span className={styles.text}><BooleanText value={technicalInformation.crossSaveState}/></span>
        </div>
      </div>
      <div className={styles.row}>
        <div className={styles.block}>
          <span className={styles.title}>Platforms</span>
          <div className={styles.tags}>
            {this.textToTag(technicalInformation.platforms)}
          </div>
        </div>
        <div className={styles.block}>
          <span className={styles.title}>Genre</span>
          <div className={styles.tags}>
            {this.textToTag(technicalInformation.genres)}
          </div>
        </div>
        <div className={styles.block}>
          <span className={styles.title}>Nutaku Engine Category</span>
          <span className={styles.text}>{technicalInformation.nutakuEngineCategory}</span>
        </div>
        <div className={styles.block}>
          <span className={styles.title}>Requirement to Launch</span>
          <span className={styles.text}>{technicalInformation.requirementToLaunch}</span>
        </div>
      </div>
    </CollapsableSection>
    );
  }

  private textToTag(texts: string[]) {
    const tags = [];
    for (const text of texts) {
      tags.push(<Tag key={text} text={text}/>);
    }
    return tags;
  }
}
