import { RouteComponentProps } from '@reach/router';
import React from 'react';

interface Props extends RouteComponentProps<{}> {
  children?: never;
}

export default (props: Props) => (
  <div />
);
