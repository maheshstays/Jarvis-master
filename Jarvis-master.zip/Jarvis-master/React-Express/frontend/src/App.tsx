import { Redirect, Router } from '@reach/router';
import React, { Suspense, useEffect } from 'react';
import { RelayEnvironmentProvider } from 'react-relay/hooks';
import Login from './authentication/Login';
import RequireAuth from './authentication/RequireAuth';
import { UserProvider } from './authentication/UserContext';
import Dashboard from './dashboard/Dashboard';
import AuthenticationErrorBoundary from './main/error/AuthenticationErrorBoundary';
import PrintingErrorBoundary from './main/error/PrintingErrorBoundary';
import NavigationMenu from './main/navigation/NavigationMenu';
import Project from './projects/Project';
import Search from './search/Search';
import environment from './services/relay';
import AuthService from './services/relay/AuthService';
import Studio from './studios/Studio';
import Studios from './studios/Studios';

import styles from './App.module.css';

export default () => {
  useEffect(AuthService.initialize, []);

  return (
    <div className={styles.container}>
      <RelayEnvironmentProvider environment={environment}>
        <UserProvider>
          <NavigationMenu />
          <PrintingErrorBoundary>
            <AuthenticationErrorBoundary>
              <Suspense fallback={<h1>LOADING...</h1>}>
                <Router>
                  <Login path="login" />
                  <RequireAuth path="/">
                    <Redirect noThrow={true} from="/" to="studios" />
                    <Studios path="studios" />
                    <Search path="search" />
                    <Dashboard path="dashboard" />
                    <Studio path="studios/:studioName" />
                    <Project path="studios/:studioName/projects/:projectName" />
                  </RequireAuth>
                </Router>
              </Suspense>
            </AuthenticationErrorBoundary>
          </PrintingErrorBoundary>
        </UserProvider>
      </RelayEnvironmentProvider>
    </div>
  );
};
