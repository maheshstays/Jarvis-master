import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { Link } from '@reach/router';
import classNames from 'classnames';
import React, { Component } from 'react';
import { ReactSVG } from 'react-svg';
import { DEVELOPER_PRODUCER, NUTAKU_BIZ_DEV } from '../constants';
import Contact from '../domain/Contact';
import Studio from '../domain/Studio';
import ProjectItemList from '../projects/ProjectItemList';

import nutakuLogo from './assets/nutaku-logo.svg';
import styles from './StudioItem.module.css';

interface Props {
  children?: never;
  studio: Studio;
}

interface State {
  collapsed: boolean;
}

export default class extends Component<Props, State> {
  constructor(props: Props) {
    super(props);
    this.state = {
      collapsed: true,
    };
  }

  public render() {
    const { studio } = this.props;
    const developerContact = studio.contacts.find((contact: Contact) => contact.role.name === DEVELOPER_PRODUCER);
    const bizDevContact = studio.contacts.find((contact: Contact) => contact.role.name === NUTAKU_BIZ_DEV);

    return (
      <div className={classNames(styles.container, { [styles.collapsed]: this.state.collapsed })}>
        <div>
          <div className={styles.studioContainer}>
            <div className={styles.thumbnail}>
              <div className={styles.imageContainer}>
                {studio.logoUrl && <img className={styles.image} src={studio.logoUrl} alt="Studio's thumbnail" />}
              </div>
            </div>
            <div className={classNames(styles.studio, styles.column)}>
              <div className={styles.title}>Studio</div>
              <div className={styles.studioName}>{studio.name}</div>
              <a
                href={studio.websiteUrl}
                target="_blank"
                rel="noopener noreferrer"
                className={styles.link}
              >
                {studio.websiteUrl}
              </a>
              <div className={styles.actions}>
                <Link
                  id="studio"
                  to={encodeURIComponent(studio.name)}
                  className={classNames(styles.button, styles.linkButton)}
                >
                  View Studio
                </Link>
                <button className={styles.button} onClick={this.handleViewGamesButtonClick}>
                  View Games&nbsp;<FontAwesomeIcon icon={this.state.collapsed ? 'angle-up' : 'angle-down'} size="lg" />
                </button>
              </div>
            </div>
            <div className={classNames(styles.developerContact, styles.column)}>
              <div className={styles.title}>Developer Contact</div>
              <span className={styles.secondRow}>
                {developerContact?.name || ''}
              </span>
              <a
                href={`mailto:${developerContact?.email || ''}`}
                className={styles.link}
              >
                {developerContact?.email || ''}
              </a>
            </div>
            <div className={classNames(styles.nutakuBizDev, styles.column)}>
              <div className={styles.title}>Nutaku Biz-Dev</div>
              <div className={styles.secondRow}>{bizDevContact?.name || ''}</div>
              <a
                href={`mailto:${bizDevContact?.email || ''}`}
                className={styles.link}
              >
                {bizDevContact?.email || ''}
              </a>
            </div>
            <div className={styles.tail}>
              <ReactSVG
                src={nutakuLogo}
                className={styles.nutakuLogo}
                beforeInjection={(svg: Element) => {
                  svg.classList.add(styles.svgNutakuLogo);
                }}
              />
            </div>
          </div>
        </div>
        <div className={styles.projectsContainer}>
          <ProjectItemList projects={studio.projects} studioName={studio.name} />
        </div>
      </div>
    );
  }

  private handleViewGamesButtonClick = () => {
    this.setState({ collapsed: !this.state.collapsed });
  }
}
