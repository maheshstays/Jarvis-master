import { RouteComponentProps } from '@reach/router';
import React, { createRef, RefObject } from 'react';
import { ReactSVG } from 'react-svg';
import Studio from '../domain/Studio';
import Button, { ButtonColor } from '../main/button/Button';
import StudioService from '../services/relay/StudioService';
import StudioCreationPopup from './popup/StudioCreationPopup';
import StudioItem from './StudioItem';

import plus from './assets/plus.svg';
import styles from './Studios.module.css';

interface Props extends RouteComponentProps<{}> {
  children?: never;
}

const Studios = (_: Props) => {
  const creationPopupRef: RefObject<StudioCreationPopup> = createRef<StudioCreationPopup>();

  return (
    <div className={styles.container}>
      <div className={styles.headerRow}>
        <h1>Studios</h1>
        <div className={styles.push}/>
        <Button
          buttonColor={ButtonColor.Ternary}
          onClick={() => {
            if (creationPopupRef.current) {
              creationPopupRef.current.setVisibility(true);
            }
          }}
        >
          <ReactSVG className={styles.plusIcon} src={plus}/>
          Add Studio
        </Button>
      </div>
        {StudioService.fetchStudios().map((studio: Studio) => (
          <div key={studio.id} className={styles.item}>
            <StudioItem studio={studio} />
          </div>
        ))}
      <StudioCreationPopup ref={creationPopupRef} />
    </div>
  );
};

export default Studios;
