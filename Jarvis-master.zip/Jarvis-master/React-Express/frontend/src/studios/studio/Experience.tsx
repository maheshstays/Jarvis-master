import React, { Component, createRef, Fragment, RefObject } from 'react';
import Studio from '../../domain/Studio';
import StudioExperience from '../../domain/StudioExperience';
import BooleanText from '../../main/boolean-text/BooleanText';
import CollapsableSection from '../../main/collapsable/CollapsableSection';
import StarsControl from '../../main/stars-control/StarsControl';
import StudioEditPopup from '../popup/StudioEditPopup';

import styles from './Experience.module.css';

interface Props {
  children?: never;
  studio: Studio;
}

export default class extends Component<Props> {
  private editPopupRef: RefObject<StudioEditPopup> = createRef<StudioEditPopup>();

  public render() {
    const experience: StudioExperience = this.props.studio.experience;
    return (
      <Fragment>
        <CollapsableSection
          comments={this.props.studio.comments}
          contentClassName={styles.container}
          header="Studio Experience"
          onEllipsisClick={() => { this.editPopupRef.current?.setUpdatePopupVisibility(true); }}
        >
          <div className={styles.leftContainer}>
            <p className={styles.title}>Most Successful Title</p>
            <p className={styles.text}>{experience.successfulTitle}</p>
            <a href={experience.successfulUrl} target="_blank" rel="noopener noreferrer">
              {experience.successfulUrl}
            </a>
            <StarsControl name="studio-experience" selectable={false} score={experience.successfulRating ?? 0}/>
          </div>
          <div className={styles.rightContainer}>
            <div className={styles.itemContainer}>
              <p className={styles.title}>Games Launched</p>
              <p className={styles.text}>{experience.gamesLaunched}</p>
            </div>
            <div className={styles.itemContainer}>
              <span className={styles.title}>Experience with f2p?</span>
              <span className={styles.text}>{experience.hasF2pExperience ? 'Yes' : 'No'}</span>
            </div>
            <div className={styles.itemContainer}>
              <p className={styles.title}>Experience with live-ops?</p>
              <p className={styles.text}><BooleanText value={experience.hasLiveOpsExperience}/></p>
            </div>
          </div>
        </CollapsableSection>
        <StudioEditPopup ref={this.editPopupRef} studio={this.props.studio}/>
      </Fragment>
    );
  }
}
