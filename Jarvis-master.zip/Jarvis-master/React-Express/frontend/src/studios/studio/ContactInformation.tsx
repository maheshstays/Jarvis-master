import React, { Component, createRef, Fragment, RefObject, Suspense } from 'react';
import Studio from '../../domain/Studio';
import CollapsableSection from '../../main/collapsable/CollapsableSection';
import Contacts from '../../main/contacts/Contacts';
import { getYearsInterval } from '../../main/utils/DateUtils';
import PermissionService from '../../services/relay/PermissionService';
import StudioEditPopup from '../popup/StudioEditPopup';

import styles from './ContactInformation.module.css';

interface Props {
  children?: never;
  studio: Studio;
}

export default class extends Component<Props> {
  private editPopupRef: RefObject<StudioEditPopup> = createRef<StudioEditPopup>();

  public render() {
    const studio: Studio = this.props.studio;
    return (
      <Fragment>
        <CollapsableSection
          comments={studio.comments}
          header="Studio Contact Information"
          onEllipsisClick={() => { this.editPopupRef.current?.setUpdatePopupVisibility(true); }}
        >
          <div className={styles.container}>
            <div className={styles.leftSide}>
              <div className={styles.imageContainer}>
                {studio.logoUrl && <img className={styles.image} src={studio.logoUrl} alt="Studio's thumbnail" />}
              </div>
              <div className={styles.addressContainer}>
                <p className={styles.studioName}>{studio.name}</p>
                <a href={studio.websiteUrl} target="_blank" rel="noopener noreferrer">{studio.websiteUrl}</a>
                <div className={styles.address}>
                  <p>{studio.address.street}</p>
                  <p>{
                    studio.address.city && studio.address.state && studio.address.country &&
                    `${studio.address.city}, ${studio.address.state}, ${studio.address.country}`
                  }</p>
                  <p>{studio.address.zipcode}</p>
                </div>
                <p className={styles.phone}>{studio.phoneNumber}</p>
              </div>
            </div>
            <div className={styles.rightSide}>
              <div className={styles.topInfo}>
                <div className={styles.topInfoItem}>
                  <p className={styles.title}>Studio Age</p>
                  <p className={styles.text}>{studio.foundingDate
                    ? getYearsInterval(new Date(), new Date(studio.foundingDate))
                    : ' '
                  }</p>
                </div>
                <div className={styles.topInfoItem}>
                  <span className={styles.title}>Studio Size</span>
                  <span className={styles.text}>{studio.employees && `${studio.employees} employees`}</span>
                </div>
                <div className={styles.topInfoItem}/>
              </div>
              <div className={styles.contactTitle}>
                <p className={styles.title}>Contact Information</p>
              </div>
              <Suspense fallback={<h2>LOADING...</h2>}>
                <Contacts contacts={PermissionService.fetchContactsForStudio(studio.id)}/>
              </Suspense>
            </div>
          </div>
        </CollapsableSection>
        <StudioEditPopup ref={this.editPopupRef} studio={studio}/>
      </Fragment>
    );
  }
}
