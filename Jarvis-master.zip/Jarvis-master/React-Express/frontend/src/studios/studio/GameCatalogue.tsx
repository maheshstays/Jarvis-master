import React, { Component, createRef, RefObject } from 'react';
import CollapsableSection from '../../main/collapsable/CollapsableSection';
import ProjectCreationPopup from '../../projects/creation-popup/ProjectCreationPopup';
import ProjectItemList from '../../projects/ProjectItemList';

import Project from '../../domain/Project';
import styles from './GameCatalogue.module.css';

interface Props {
  children?: never;
  projects?: Project[];
  studioId: string;
  studioName: string;
}

export default class extends Component<Props> {
  private creationPopupRef: RefObject<ProjectCreationPopup> = createRef<ProjectCreationPopup>();

  public render() {
    return (
      <CollapsableSection
        hideComments={true}
        contentClassName={styles.container}
        header="Developer Game Catalogue"
        onEllipsisClick={this.showCreateProjectPopup}
      >
        <ProjectCreationPopup studioId={this.props.studioId} ref={this.creationPopupRef}/>
        <ProjectItemList projects={this.props.projects} studioName={this.props.studioName}/>
      </CollapsableSection>
    );
  }

  private showCreateProjectPopup = () => {
    this.creationPopupRef.current?.setVisibility(true);
  }
}
