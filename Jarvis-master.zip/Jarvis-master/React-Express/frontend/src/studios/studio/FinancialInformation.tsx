import classNames from 'classnames';
import React, { Component, createRef, Fragment, RefObject } from 'react';
import Text from 'react-texty';
import Studio from '../../domain/Studio';
import StudioFinancialInformation from '../../domain/StudioFinancialInformation';
import StudioFinancialInformationTableEntry from '../../domain/StudioFinancialInformationTableEntry';
import CollapsableSection from '../../main/collapsable/CollapsableSection';
import StudioEditPopup from '../popup/StudioEditPopup';

import stylesGlobal from '../../projects/global.module.css';
import styles from './FinancialInformation.module.css';

interface Props {
  studio: Studio;
  children?: never;
}

const StudioFinancialInfo = new StudioFinancialInformation({
  address: ['1234 Saint Rue St.', 'Montréal, QC, Canada', 'H1A 0A1'],
  financialViability: 'Sed eget cursus nisl. Praesent et facilisis diam. Nullam id luctus enim, quis sodales justo. In gravida ac velit at accumsan. Phasellus a posuere nisl. Donec posuere mauris vel dictum condimentum. Donec ac efficitur risus, quis pulvinar ligula. Curabitur volutpat quam eu sagittis consequat. Aenean at aliquam lacus, non ultricies libero. Curabitur viverra placerat felis molestie vestibulum.',
  infoPairs: [{title: 'Title:', name: 'Name'}, {title: 'Title:', name: 'Name'}, {title: 'Title:', name: 'Name'}, {title: 'Title:', name: 'Name'}],
  name: 'Financial Institution Name',
});

function ConstructStudioFinancialInfoTableWith(infoPairs: StudioFinancialInformationTableEntry[]): JSX.Element[] {
  const table = [];
  for (let i = 0; i < infoPairs.length; i++) {
    if (i % 2 === 1) {
      continue;
    }

    const curPair = infoPairs[i];
    if (i < infoPairs.length - 1) {
      const nextPair = infoPairs[i + 1];
      table.push(<div className={styles.container}>
                  <div className={classNames(styles.rightSubContainer, styles.textHeader)}>{curPair.title}</div>
                  <div
                    className={classNames(styles.rightSubContainer,
                    styles.textHeader, styles.textBold, styles.textRightMargin)}
                  >
                    {curPair.name}
                  </div>
                  <div className={classNames(styles.rightSubContainer, styles.textHeader)}>{nextPair.title}</div>
                  <div className={classNames(styles.rightSubContainer, styles.textHeader, styles.textBold)}>
                    {nextPair.name}
                  </div>
                </div>);
    } else {
      table.push(<div className={styles.container}>
                  <div className={classNames(styles.rightSubContainer, styles.textHeader)}>{curPair.title}</div>
                  <div
                    className={
                      classNames(styles.rightSubContainer, styles.textHeader, styles.textBold, styles.textRightMargin)
                    }
                  >
                    {curPair.name}
                  </div>
                  <div className={classNames(styles.rightSubContainer)}/>
                  <div className={classNames(styles.rightSubContainer)}/>
                </div>);
    }
  }
  return table;
}

export default class extends Component<Props> {
  private editPopupRef: RefObject<StudioEditPopup> = createRef<StudioEditPopup>();

  public render() {
    return (
      <Fragment>
        <CollapsableSection
          header="Financial Information"
          onEllipsisClick={() => { this.editPopupRef.current?.setUpdatePopupVisibility(true); }}
        >
          <div className={styles.container}>
            <div className={classNames(styles.leftSection)}>
              <div className={classNames(styles.institutionName, styles.textBold)}>{StudioFinancialInfo.name}</div>
              <div className={styles.textContent}>
                {StudioFinancialInfo.address.map((addressLine: string, index: number) => (
                  <Text key={index}>{addressLine}</Text>
                ))}
              </div>
            </div>
            <div className={classNames(styles.rightSection)}>
              <div className={styles.container}>
                <div className={classNames(styles.rightSubContainer, styles.textHeader, stylesGlobal.textUpperCase)}>
                  Title
                </div>
                <div
                  className={classNames(
                    styles.rightSubContainer, styles.textHeader, stylesGlobal.textUpperCase, styles.textRightPadding)
                  }
                >
                  Name
                </div>
                <div className={classNames(styles.rightSubContainer, styles.textHeader, stylesGlobal.textUpperCase)}>
                  Title
                </div>
                <div className={classNames(styles.rightSubContainer, styles.textHeader, stylesGlobal.textUpperCase)}>
                  Name
                </div>
              </div>
                {ConstructStudioFinancialInfoTableWith(StudioFinancialInfo.infoPairs).map(
                  (info: JSX.Element, index: number) => (<div key={index}>{info}</div>))}
              <div>
                <div className={classNames(styles.textHeader, stylesGlobal.textUpperCase)}>
                  Financial viability
                </div>
                <div className={styles.textContent}>
                  {StudioFinancialInfo.financialViability}
                </div>
              </div>
            </div>
          </div>
        </CollapsableSection>
        <StudioEditPopup ref={this.editPopupRef} studio={this.props.studio}/>
      </Fragment>
    );
  }
}
