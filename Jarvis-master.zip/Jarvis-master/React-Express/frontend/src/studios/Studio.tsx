import { RouteComponentProps } from '@reach/router';
import React from 'react';
import DomainStudio from '../domain/Studio';
import StudioService from '../services/relay/StudioService';
import ContactInformation from './studio/ContactInformation';
import Experience from './studio/Experience';
import FinancialInformation from './studio/FinancialInformation';
import GameCatalogue from './studio/GameCatalogue';

import styles from './Studio.module.css';

interface Props extends RouteComponentProps<{ studioName: string }> {
  children?: never;
}

const Studio = (props: Props) => {
  const noStudio =
    <div>
      This studio can't be found.
    </div>;

  if (!props.studioName) {
    return noStudio;
  }

  const studio: DomainStudio = StudioService.fetchStudio(props.studioName);

  if (!studio) {
    return noStudio;
  }

  return (
  <div className={styles.container}>
    <div className={styles.sectionContainer}>
      <ContactInformation studio={studio}/>
    </div>
    <div className={styles.sectionContainer}>
      <FinancialInformation studio={studio}/>
    </div>
    <div className={styles.sectionContainer}>
      <Experience studio={studio}/>
    </div>
    <div className={styles.sectionContainer}>
      <GameCatalogue projects={studio.projects} studioId={studio.id} studioName={studio.name}/>
    </div>
  </div>
  );
};

export default Studio;
