import React, { Component, createRef, RefObject } from 'react';
import Popup from '../../main/popup/Popup';
import Tabs from '../../main/tabs/Tabs';
import StudioService from '../../services/relay/StudioService';
import FinancialInformationTab, { FinancialInformationPartialState } from './tabs/FinancialInformationTab';
import StudioExperienceTab, { StudioExperiencePartialState } from './tabs/StudioExperienceTab';
import StudioInformationTab, { StudioInformationPartialState } from './tabs/StudioInformationTab';

interface Props {
  children?: never;
}

interface State {
  studioInformation?: StudioInformationPartialState;
  financialInformation?: FinancialInformationPartialState;
  studioExperience?: StudioExperiencePartialState;
}

export default class extends Component<Props, State> {
  public state: State = {};

  private popupRef: RefObject<Popup> = createRef<Popup>();

  public render() {
    return (
      <form onSubmit={(event) => { event.preventDefault(); this.submit(); }}>
        <Popup
          defaultWidth="42.5em"
          ref={this.popupRef}
          extraButtons={[{ text: 'Submit', type: 'submit' }]}
        >
            <Tabs>
              {{
                content: <StudioInformationTab
                  content={this.state.studioInformation}
                  update={this.updateStudioInformation}
                />,
                header: 'Studio Info',
              }}
              {{
                content: <FinancialInformationTab
                  content={this.state.financialInformation}
                  update={this.updateFinancialInformation}
                />,
                header: 'Financial Info',
              }}
              {{
                content: <StudioExperienceTab
                  content={this.state.studioExperience}
                  update={this.updateStudioExperience}
                />,
                header: 'Studio Experience',
              }}
            </Tabs>
        </Popup>
      </form>
    );
  }

  public setVisibility(isVisible: boolean) {
    this.popupRef.current?.setVisibility(isVisible);
  }

  private submit = () => {
    if (this.state.studioInformation?.studioName) {
      StudioService.createStudio({
          address: {
            city: this.state.studioInformation?.studioCity,
            country: this.state.studioInformation?.studioCountry,
            state: this.state.studioInformation?.studioProvince,
            street: this.state.studioInformation?.studioStreet,
            zipcode: this.state.studioInformation?.studioPostalCode,
          },
          employees: this.state.studioInformation?.nbPeople,
          foundingDate: this.state.studioInformation?.foundationDate,
          gamesLaunched: this.state.studioExperience?.gamesLaunched,
          hasF2pExperience: this.state.studioExperience?.hasF2pExperience,
          hasLiveOpsExperience: this.state.studioExperience?.hasLiveOpsExperience,
          logoUrl: this.state.studioInformation.studioImageUrl,
          name: this.state.studioInformation!.studioName,
          successfulRating: this.state.studioExperience?.mostSuccessfulTitleRating,
          successfulTitle: this.state.studioExperience?.mostSuccessfulTitleName,
          successfulUrl: this.state.studioExperience?.mostSuccessfulTitleUrl,
          websiteUrl: this.state.studioInformation?.websiteUrl,
        },
        () => { this.popupRef.current?.setVisibility(false); window.location.reload(); },
        () => null, // TO DO: Error handling
      );
    }
  }

  private updateFinancialInformation = (financialInformation: FinancialInformationPartialState) => {
    this.setState({ financialInformation: { ...this.state.financialInformation, ...financialInformation } });
  }

  private updateStudioExperience = (studioExperience: StudioExperiencePartialState) => {
    this.setState({ studioExperience: { ...this.state.studioExperience, ...studioExperience } });
  }

  private updateStudioInformation = (studioInformation: StudioInformationPartialState) => {
    this.setState({ studioInformation: { ...this.state.studioInformation, ...studioInformation } });
  }
}
