import React, { Component } from 'react';
import InputField from '../../../main/input-field/InputField';
import Textarea from '../../../main/textarea/Textarea';
import { getDateString } from '../../../main/utils/DateUtils';

import styles from './StudioInformationTab.module.css';

interface Props {
  children?: never;
  content?: StudioInformationPartialState;
  update: (info: StudioInformationPartialState) => void;
}

export interface StudioInformationPartialState {
  studioStreet: string;
  studioCity: string;
  studioProvince: string;
  studioCountry: string;
  studioPostalCode: string;
  studioName: string;
  studioImageUrl: string;
  websiteUrl: string;
  foundationDate: number;
  nbPeople: number;
  comment: string;
}

export default class extends Component<Props> {
  public render() {
    return (
      <div className={styles.container}>
        <div className={styles.horizontal}>
          <InputField
            containerClassName={styles.twoFields}
            label="Studio Name"
            placeholder="Enter Studio Name"
            value={this.props.content?.studioName ?? ''}
            onChange={this.handleInputEdit('studioName')}
            required={true}
          />
          <InputField
            containerClassName={styles.twoFields}
            type="date"
            label="Foundation Date"
            value={getDateString(new Date(this.props.content?.foundationDate ?? Date.now()))}
            onChange={this.handleInputEdit('foundationDate')}
          />
        </div>
        <InputField
          label="Studio Image URL"
          placeholder="Enter URL"
          value={this.props.content?.studioImageUrl ?? ''}
          onChange={this.handleInputEdit('studioImageUrl')}
        />
        <div className={styles.horizontal}>
          <InputField
            containerClassName={styles.twoFields}
            label="Studio Location"
            subLabel="Street"
            placeholder="Street"
            value={this.props.content?.studioStreet ?? ''}
            onChange={this.handleInputEdit('studioStreet')}
          />
          <InputField
            containerClassName={styles.twoFields}
            label="City"
            placeholder="City"
            value={this.props.content?.studioCity ?? ''}
            onChange={this.handleInputEdit('studioCity')}
          />
        </div>
        <div className={styles.horizontal}>
          <InputField
            containerClassName={styles.twoFields}
            label="Province"
            placeholder="Province"
            value={this.props.content?.studioProvince ?? ''}
            onChange={this.handleInputEdit('studioProvince')}
          />
          <InputField
            containerClassName={styles.twoFields}
            label="Country"
            placeholder="Country"
            value={this.props.content?.studioCountry ?? ''}
            onChange={this.handleInputEdit('studioCountry')}
          />
        </div>
        <div className={styles.horizontal}>
          <InputField
            containerClassName={styles.twoFields}
            label="Postal Code"
            placeholder="Postal Code"
            value={this.props.content?.studioPostalCode ?? ''}
            onChange={this.handleInputEdit('studioPostalCode')}
          />
          <div className={styles.twoFields}/>
        </div>
        <div className={styles.horizontal}>
          <InputField
            containerClassName={styles.twoFields}
            label="Studio Website"
            placeholder="Enter URL"
            value={this.props.content?.websiteUrl ?? ''}
            onChange={this.handleInputEdit('websiteUrl')}
          />
          <InputField
            containerClassName={styles.twoFields}
            type="number"
            label="Studio Size"
            subLabel="Number of People"
            placeholder="0"
            min={0}
            value={this.props.content?.nbPeople ?? 0}
            onChange={this.handleInputEdit('nbPeople')}
          />
        </div>
        <Textarea
          label="Studio Financial Viability"
          subLabel="General Comments"
          placeholder="Enter Comments"
          value={this.props.content?.comment ?? ''}
          onChange={this.handleTextareaEdit('comment')}
        />
      </div>
    );
  }

  private handleInputEdit =
    (field: keyof StudioInformationPartialState) => (event: React.ChangeEvent<HTMLInputElement>) => {
    let value;

    switch (event.target.type) {
      case 'number': value = event.target.valueAsNumber; break;
      case 'checkbox': value = event.target.checked; break;
      case 'date': value = new Date(event.target.value).getTime(); break;
      default: value = event.target.value;
    }
    this.props.update({ [field]: value } as unknown as StudioInformationPartialState);
  }

  private handleTextareaEdit =
    (field: keyof StudioInformationPartialState) => (event: React.ChangeEvent<HTMLTextAreaElement>) => {
    this.props.update({ [field]: event.target.value } as unknown as StudioInformationPartialState);
  }
}
