import React, { Component } from 'react';
import InputField from '../../../main/input-field/InputField';
import StarsControl from '../../../main/stars-control/StarsControl';
import Textarea from '../../../main/textarea/Textarea';

import YesNoToggle from '../../../main/yes-no-toggle/YesNoToggle';
import styles from './StudioExperienceTab.module.css';

interface Props {
  children?: never;
  content?: StudioExperiencePartialState;
  update: (info: StudioExperiencePartialState) => void;
}

export interface StudioExperiencePartialState {
  gamesLaunched: number;
  mostSuccessfulTitleName: string;
  mostSuccessfulTitleUrl: string;
  mostSuccessfulTitleRating: number;
  notableTitlesUrls: string;
  hasF2pExperience: boolean;
  hasLiveOpsExperience: boolean;
}

export default class extends Component<Props> {
  public render() {
    return (
      <div className={styles.container}>
        <InputField
          type="number"
          label="Games Launched"
          placeholder="0"
          min={0}
          value={this.props.content?.gamesLaunched ?? 0}
          onChange={this.handleInputEdit('gamesLaunched')}
        />
        <InputField
          label="Most Successful Title"
          subLabel="Name"
          placeholder="Enter Name"
          value={this.props.content?.mostSuccessfulTitleName ?? ''}
          onChange={this.handleInputEdit('mostSuccessfulTitleName')}
        />
        <InputField
          label="Most Successful Title"
          subLabel="Url"
          placeholder="Enter URL"
          value={this.props.content?.mostSuccessfulTitleUrl ?? ''}
          onChange={this.handleInputEdit('mostSuccessfulTitleUrl')}
        />
        <StarsControl
          label="Most Successful Title Rating"
          name="most-successful-title-rating"
          selectable={true}
          score={this.props.content?.mostSuccessfulTitleRating ?? 0}
          onChange={this.handleStarsControlEdit('mostSuccessfulTitleRating')}
        />
        <Textarea
          label="Other Notable Titles"
          subLabel="URLs"
          placeholder="Enter 1 URL per line"
          value={this.props.content?.notableTitlesUrls ?? ''}
          onChange={this.handleTextareaEdit('notableTitlesUrls')}
        />
        <div className={styles.horizontal}>
          {/* <InputField
            containerClassName={styles.twoFields}
            type="checkbox"
            label="Experience With F2P"
            value={this.props.content?.hasF2pExperience ?? false}
            onChange={this.handleInputEdit('hasF2pExperience')}
          />
          <InputField
            containerClassName={styles.twoFields}
            type="checkbox"
            label="Experience With Live-Ops"
            value={this.props.content?.hasLiveOpsExperience ?? false}
            onChange={this.handleInputEdit('hasLiveOpsExperience')}
          /> */}
          <div className={styles.twoFields}>
            <YesNoToggle
              label="Experience With F2P"
              onChange={this.handleInputEdit('hasF2pExperience')}
              value={this.props.content?.hasF2pExperience ?? false}
            />
          </div>
          <div className={styles.twoFields}>
            <YesNoToggle
              label="Experience With Live-Ops"
              onChange={this.handleInputEdit('hasLiveOpsExperience')}
              value={this.props.content?.hasLiveOpsExperience ?? false}
            />
          </div>
        </div>
      </div>
    );
  }

  private handleInputEdit =
    (field: keyof StudioExperiencePartialState) => (event: React.ChangeEvent<HTMLInputElement>) => {
    let value;

    switch (event.target.type) {
      case 'number': value = event.target.valueAsNumber; break;
      case 'checkbox': value = event.target.checked; break;
      default: value = event.target.value;
    }

    this.props.update({ [field]: value } as unknown as StudioExperiencePartialState);
  }

  private handleStarsControlEdit =
    (field: keyof StudioExperiencePartialState) => (event: React.ChangeEvent<HTMLInputElement>) => {
    this.props.update({ [field]: parseInt(event.target.value, 10) } as unknown as StudioExperiencePartialState);
  }

  private handleTextareaEdit =
    (field: keyof StudioExperiencePartialState) => (event: React.ChangeEvent<HTMLTextAreaElement>) => {
    this.props.update({ [field]: event.target.value } as unknown as StudioExperiencePartialState);
  }
}
