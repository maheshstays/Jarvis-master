import React, { Component } from 'react';
import InputField from '../../../main/input-field/InputField';
import Textarea from '../../../main/textarea/Textarea';

import styles from './FinancialInformationTab.module.css';

interface Props {
  children?: never;
  content?: FinancialInformationPartialState;
  update: (info: FinancialInformationPartialState) => void;
}

export interface FinancialInformationPartialState {
  financialInstitutionName: string;
  financialStreet: string;
  financialCity: string;
  financialProvince: string;
  financialCountry: string;
  financialPostalCode: string;
  financialViability: string;
}

export default class extends Component<Props> {
  public render() {
    return (
      <div className={styles.container}>
        <InputField
          label="Financial Institution Name"
          placeholder="Enter Financial Institution Name"
          value={this.props.content?.financialInstitutionName ?? ''}
          onChange={this.handleInputEdit('financialInstitutionName')}
        />
        <div className={styles.horizontal}>
          <InputField
            containerClassName={styles.twoFields}
            label="Institution Location"
            subLabel="Street"
            placeholder="Street"
            value={this.props.content?.financialStreet ?? ''}
            onChange={this.handleInputEdit('financialStreet')}
          />
          <InputField
            containerClassName={styles.twoFields}
            label="City"
            placeholder="City"
            value={this.props.content?.financialCity ?? ''}
            onChange={this.handleInputEdit('financialCity')}
          />
        </div>
        <div className={styles.horizontal}>
          <InputField
            containerClassName={styles.twoFields}
            label="Province"
            placeholder="Province"
            value={this.props.content?.financialProvince ?? ''}
            onChange={this.handleInputEdit('financialProvince')}
          />
          <InputField
            containerClassName={styles.twoFields}
            label="Country"
            placeholder="Country"
            value={this.props.content?.financialCountry ?? ''}
            onChange={this.handleInputEdit('financialCountry')}
          />
        </div>
        <div className={styles.horizontal}>
          <InputField
            containerClassName={styles.twoFields}
            label="Postal Code"
            placeholder="Postal Code"
            value={this.props.content?.financialPostalCode ?? ''}
            onChange={this.handleInputEdit('financialPostalCode')}
          />
          <div className={styles.twoFields}/>
        </div>
        <Textarea
          label="Financial Viability"
          placeholder="Financial Viability"
          value={this.props.content?.financialViability ?? ''}
          onChange={this.handleTextareaEdit('financialViability')}
        />
      </div>
    );
  }

  private handleInputEdit =
    (field: keyof FinancialInformationPartialState) => (event: React.ChangeEvent<HTMLInputElement>) => {
    let value;

    switch (event.target.type) {
      case 'number': value = event.target.valueAsNumber; break;
      case 'checkbox': value = event.target.checked; break;
      default: value = event.target.value;
    }

    this.props.update({ [field]: value } as unknown as FinancialInformationPartialState);
  }

  private handleTextareaEdit =
    (field: keyof FinancialInformationPartialState) => (event: React.ChangeEvent<HTMLTextAreaElement>) => {
    this.props.update({ [field]: event.target.value } as unknown as FinancialInformationPartialState);
  }
}
