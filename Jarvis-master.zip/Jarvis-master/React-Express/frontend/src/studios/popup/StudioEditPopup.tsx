import React, { Component, createRef, Fragment, RefObject } from 'react';
import Studio from '../../domain/Studio';
import Popup from '../../main/popup/Popup';
import Tabs from '../../main/tabs/Tabs';
import StudioService from '../../services/relay/StudioService';
import FinancialInformationTab, { FinancialInformationPartialState } from './tabs/FinancialInformationTab';
import StudioExperienceTab, { StudioExperiencePartialState } from './tabs/StudioExperienceTab';
import StudioInformationTab, { StudioInformationPartialState } from './tabs/StudioInformationTab';

interface Props {
  studio: Studio;
  children?: never;
}

interface State {
  studioInformation?: StudioInformationPartialState;
  financialInformation?: FinancialInformationPartialState;
  studioExperience?: StudioExperiencePartialState;
}

export default class extends Component<Props, State> {
  public state: State = {};

  private updatePopupRef: RefObject<Popup> = createRef<Popup>();
  private confirmDeletePopupRef: RefObject<Popup> = createRef<Popup>();

  public constructor(props: Props) {
    super(props);
    this.state = {
      financialInformation: {
        financialCity: '',
        financialCountry: '',
        financialInstitutionName: '',
        financialPostalCode: '',
        financialProvince: '',
        financialStreet: '',
        financialViability: '',
      },
      studioExperience: {
        gamesLaunched: props.studio.experience.gamesLaunched ?? 0,
        hasF2pExperience: props.studio.experience.hasF2pExperience,
        hasLiveOpsExperience: props.studio.experience.hasLiveOpsExperience,
        mostSuccessfulTitleName: props.studio.experience.successfulTitle ?? '',
        mostSuccessfulTitleRating: props.studio.experience.successfulRating ?? 5,
        mostSuccessfulTitleUrl: props.studio.experience.successfulUrl ?? '',
        notableTitlesUrls: '',
      },
      studioInformation: {
        comment: '',
        foundationDate: props.studio.foundingDate ?? 0,
        nbPeople: props.studio.employees ?? 0,
        studioCity: props.studio.address.city ?? '',
        studioCountry: props.studio.address.country ?? '',
        studioImageUrl: props.studio.logoUrl ?? '',
        studioName: props.studio.name ?? '',
        studioPostalCode: props.studio.address.zipcode ?? '',
        studioProvince: props.studio.address.state ?? '',
        studioStreet: props.studio.address.street ?? '',
        websiteUrl: props.studio.websiteUrl ?? '',
      },
    };
  }

  public render() {
    return (
      <Fragment>
        <form onSubmit={(event) => { event.preventDefault(); this.submit(); }}>
          <Popup
            defaultWidth="42.5em"
            ref={this.updatePopupRef}
            extraButtons={[
              { text: 'Update', type: 'submit' },
              { text: 'Delete', onClick: () => { this.setConfirmationPopupVisibility(true); }},
            ]}
          >
              <Tabs>
                {{
                  content: <StudioInformationTab
                    content={this.state.studioInformation}
                    update={this.updateStudioInformation}
                  />,
                  header: 'Studio Info',
                }}
                {{
                  content: <FinancialInformationTab
                    content={this.state.financialInformation}
                    update={this.updateFinancialInformation}
                  />,
                  header: 'Financial Info',
                }}
                {{
                  content: <StudioExperienceTab
                    content={this.state.studioExperience}
                    update={this.updateStudioExperience}
                  />,
                  header: 'Studio Experience',
                }}
              </Tabs>
          </Popup>
        </form>
        <Popup
          defaultWidth="42.5em"
          ref={this.confirmDeletePopupRef}
          closeButton={{onClick: () => {
            this.setConfirmationPopupVisibility(false);
            this.setUpdatePopupVisibility(true);
          },
          text: 'No'}}
          extraButtons={[{ text: 'Yes', onClick: this.deleteStudio}]}
        >
          <p>Are you sure you want to delete this studio?</p>
        </Popup>
      </Fragment>
    );
  }

  public setUpdatePopupVisibility(isVisible: boolean) {
    this.updatePopupRef.current?.setVisibility(isVisible);
  }

  private setConfirmationPopupVisibility(isVisible: boolean) {
    this.setUpdatePopupVisibility(false);
    this.confirmDeletePopupRef.current?.setVisibility(isVisible);
  }

  private submit = () => {
    if (this.state.studioInformation?.studioName) {
      StudioService.updateStudio({
          address: {
            city: this.state.studioInformation?.studioCity,
            country: this.state.studioInformation?.studioCountry,
            state: this.state.studioInformation?.studioProvince,
            street: this.state.studioInformation?.studioStreet,
            zipcode: this.state.studioInformation?.studioPostalCode,
          },
          employees: this.state.studioInformation?.nbPeople,
          foundingDate: this.state.studioInformation?.foundationDate,
          gamesLaunched: this.state.studioExperience?.gamesLaunched,
          hasF2pExperience: this.state.studioExperience?.hasF2pExperience,
          hasLiveOpsExperience: this.state.studioExperience?.hasLiveOpsExperience,
          id: this.props.studio.id,
          name: this.state.studioInformation!.studioName,
          successfulRating: this.state.studioExperience?.mostSuccessfulTitleRating,
          successfulTitle: this.state.studioExperience?.mostSuccessfulTitleName,
          successfulUrl: this.state.studioExperience?.mostSuccessfulTitleUrl,
          websiteUrl: this.state.studioInformation?.websiteUrl,
        },
        () => { this.updatePopupRef.current?.setVisibility(false); window.location.reload(); },
        () => null, // TO DO: Error handling
      );
    }
  }

  private deleteStudio = () => {
    StudioService.deleteStudio(
      this.props.studio.id,
      () => { this.setConfirmationPopupVisibility(false); window.location.reload(); },
      () => null, // TO DO: Error handling
    );
  }

  private updateFinancialInformation = (financialInformation: FinancialInformationPartialState) => {
    this.setState({ financialInformation: { ...this.state.financialInformation, ...financialInformation } });
  }

  private updateStudioExperience = (studioExperience: StudioExperiencePartialState) => {
    this.setState({ studioExperience: { ...this.state.studioExperience, ...studioExperience } });
  }

  private updateStudioInformation = (studioInformation: StudioInformationPartialState) => {
    this.setState({ studioInformation: { ...this.state.studioInformation, ...studioInformation } });
  }
}
