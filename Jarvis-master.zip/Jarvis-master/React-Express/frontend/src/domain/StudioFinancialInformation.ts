import StudioFinancialInformationTableEntry from './StudioFinancialInformationTableEntry';

interface StudioFinancialInformationArgs {
  name: string;
  address: string[];
  infoPairs: StudioFinancialInformationTableEntry[];
  financialViability: string;
}

export default class {
  public readonly name: string;
  public readonly address: string[];
  public readonly infoPairs: StudioFinancialInformationTableEntry[];
  public readonly financialViability: string;

  constructor(args: StudioFinancialInformationArgs) {
    this.name = args.name;
    this.address = args.address;
    this.infoPairs = args.infoPairs;
    this.financialViability = args.financialViability;
  }
}
