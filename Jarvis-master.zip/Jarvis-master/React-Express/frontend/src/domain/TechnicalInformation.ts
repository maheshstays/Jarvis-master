
interface TechnicalInformationArgs {
  languages: string[];
  categories: string[];
  platforms: string[];
  genres: string[];
  engine: string;
  crossSaveState: boolean;
  nutakuEngineCategory: string;
  requirementToLaunch: string;
}

export default class {
  public readonly languages: string[];
  public readonly categories: string[];
  public readonly platforms: string[];
  public readonly genres: string[];
  public readonly engine: string;
  public readonly crossSaveState: boolean;
  public readonly nutakuEngineCategory: string;
  public readonly requirementToLaunch: string;

  constructor(args: TechnicalInformationArgs) {
    this.languages = args.languages;
    this.categories = args.categories;
    this.platforms = args.platforms;
    this.genres = args.genres;
    this.engine = args.engine;
    this.crossSaveState = args.crossSaveState;
    this.nutakuEngineCategory = args.nutakuEngineCategory;
    this.requirementToLaunch = args.requirementToLaunch;
  }
}
