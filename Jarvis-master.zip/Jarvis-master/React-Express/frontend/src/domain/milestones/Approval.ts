import Role from '../Role';

export enum ApprovalStatus {
  Approved,
  NeedMoreInfo,
  Denied,
}

interface DeliverableArgs {
  id: string;
  approverName: string;
  role: Role;
  comment: string;
  status: ApprovalStatus;
}

export default class {
  public readonly id: string;
  public readonly approverName: string;
  public readonly role: Role;
  public readonly comment: string;
  public readonly status: ApprovalStatus;

  constructor(args: DeliverableArgs) {
    this.id = args.id;
    this.approverName = args.approverName;
    this.role = args.role;
    this.comment = args.comment;
    this.status = args.status;
  }
}
