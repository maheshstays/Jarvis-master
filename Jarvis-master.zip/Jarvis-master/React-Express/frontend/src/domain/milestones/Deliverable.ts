export enum DeliverableStatus {
  Delivered,
  ToBeDelivered,
  Late,
}

interface DeliverableArgs {
  id: string;
  name: string;
  description: string;
  status: DeliverableStatus;
}

export default class {
  public readonly id: string;
  public readonly name: string;
  public readonly description: string;
  public readonly status: DeliverableStatus;

  constructor(args: DeliverableArgs) {
    this.id = args.id;
    this.name = args.name;
    this.description = args.description;
    this.status = args.status;
  }
}
