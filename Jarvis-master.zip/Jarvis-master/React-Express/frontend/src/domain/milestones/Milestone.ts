import Approval from './Approval';
import Deliverable from './Deliverable';

export enum PaymentStatus {
  Paid,
  SentToAccounting,
}

interface MilestoneArgs {
  id: string;
  name: string;
  dueDate: number | null;
  approvalDate: number | null;
  paymentAmount: number | null;
  paymentStatus: PaymentStatus | null;
  deliverables: Deliverable[];
  approvals: Approval[];
}

export default class {
  public readonly id: string;
  public readonly name: string;
  public readonly dueDate?: number;
  public readonly approvalDate?: number;
  public readonly paymentAmount?: number;
  public readonly paymentStatus?: PaymentStatus;
  public readonly deliverables: Deliverable[];
  public readonly approvals: Approval[];

  constructor(args: MilestoneArgs) {
    this.id = args.id;
    this.name = args.name;
    this.dueDate = args.dueDate ?? undefined;
    this.approvalDate = args.approvalDate ?? undefined;
    this.paymentAmount = args.paymentAmount ?? undefined;
    this.paymentStatus = args.paymentStatus ?? undefined;
    this.deliverables = args.deliverables;
    this.approvals = args.approvals;
  }
}
