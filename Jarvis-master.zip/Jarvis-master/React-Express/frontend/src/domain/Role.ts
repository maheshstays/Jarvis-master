interface RoleArgs {
  id: string;
  name: string;
}

export default class {
  public readonly id: string;
  public readonly name: string;

  constructor(args: RoleArgs) {
    this.id = args.id;
    this.name = args.name;
  }
}
