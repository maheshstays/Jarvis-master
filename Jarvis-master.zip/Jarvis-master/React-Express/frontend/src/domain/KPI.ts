interface KPIArgs {
  progressRatio: number;
  name: string;
}

export default class {
  public readonly progressRatio: number;
  public readonly name: string;

  constructor(args: KPIArgs) {
    this.progressRatio = args.progressRatio;
    this.name = args.name;
  }
}
