interface PlatformArgs {
  id: string;
  name: string;
  icon: string;
}

export default class {
  public readonly id: string;
  public readonly name: string;
  public readonly icon: string;

  constructor(args: PlatformArgs) {
    this.id = args.id;
    this.name = args.name;
    this.icon = args.icon;
  }
}
