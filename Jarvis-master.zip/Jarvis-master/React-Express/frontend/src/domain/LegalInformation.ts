import Comment from './Comment';

interface LegalInformationArgs {
  publishingSignatureDate: number | null;
  nutakuSignatureDate: number | null;
  publisher: string;
  ipHolder: string;
  advanceBy: string;
  isExclusive: boolean;
  paysFreeGold: boolean;
  hasBizDevCommission: boolean;
  comments: Comment[];
}

export default class {
  public readonly publishingSignatureDate?: number;
  public readonly nutakuSignatureDate?: number;
  public readonly publisher: string;
  public readonly ipHolder: string;
  public readonly advanceBy: string;
  public readonly isExclusive: boolean;
  public readonly paysFreeGold: boolean;
  public readonly hasBizDevCommission: boolean;
  public readonly comments: Comment[];

  constructor(args: LegalInformationArgs) {
    this.publishingSignatureDate = args.publishingSignatureDate ?? undefined;
    this.nutakuSignatureDate = args.nutakuSignatureDate ?? undefined;
    this.publisher = args.publisher;
    this.ipHolder = args.ipHolder;
    this.advanceBy = args.advanceBy;
    this.isExclusive = args.isExclusive;
    this.paysFreeGold = args.paysFreeGold;
    this.hasBizDevCommission = args.hasBizDevCommission;
    this.comments = args.comments;
  }
}
