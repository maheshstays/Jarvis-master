interface CommentArgs {
  id: string;
  author: string;
  date: number;
  text: string | null;
}

export default class {
  public readonly id: string;
  public readonly author: string;
  public readonly date: number;
  public readonly text?: string;

  constructor(args: CommentArgs) {
    this.id = args.id;
    this.author = args.author;
    this.date = args.date;
    this.text = args.text ?? undefined;
  }
}
