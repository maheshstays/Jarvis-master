import Role from './Role';

interface ContactArgs {
  email: string;
  name: string | null;
  role: Role;
  skype: string | null;
}

export default class {
  public readonly email: string;
  public readonly name?: string;
  public readonly role: Role;
  public readonly skype?: string;

  constructor(args: ContactArgs) {
    this.email = args.email;
    this.name = args.name ?? undefined;
    this.role = args.role;
    this.skype = args.skype ?? undefined;
  }
}
