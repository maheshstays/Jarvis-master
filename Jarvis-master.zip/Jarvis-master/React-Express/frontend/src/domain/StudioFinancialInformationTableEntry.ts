interface StudioFinancialInformationTableEntryArgs {
  title: string;
  name: string;
}

export default class {
  public readonly title: string;
  public readonly name: string;

  constructor(args: StudioFinancialInformationTableEntryArgs) {
    this.title = args.title;
    this.name = args.name;
  }
}
