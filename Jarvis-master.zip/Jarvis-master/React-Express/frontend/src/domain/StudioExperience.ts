import Comment from './Comment';

interface StudioExperienceArgs {
  comments: Comment[];
  gamesLaunched: number | null;
  hasF2pExperience: boolean;
  hasLiveOpsExperience: boolean;
  successfulRating: number | null;
  successfulTitle: string | null;
  successfulUrl: string | null;
}

export default class {
  public readonly comments: Comment[];
  public readonly gamesLaunched?: number;
  public readonly hasF2pExperience: boolean;
  public readonly hasLiveOpsExperience: boolean;
  public readonly successfulRating?: number;
  public readonly successfulTitle?: string;
  public readonly successfulUrl?: string;

  constructor(args: StudioExperienceArgs) {
    this.comments = args.comments;
    this.gamesLaunched = args.gamesLaunched ?? undefined;
    this.hasF2pExperience = args.hasF2pExperience;
    this.hasLiveOpsExperience = args.hasLiveOpsExperience;
    this.successfulRating = args.successfulRating ?? undefined;
    this.successfulTitle = args.successfulTitle ?? undefined;
    this.successfulUrl = args.successfulUrl ?? undefined;
  }
}
