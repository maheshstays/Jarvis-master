import Address from './Address';
import Comment from './Comment';
import Contact from './Contact';
import Project from './Project';
import StudioExperience from './StudioExperience';

interface StudioArgs {
  id: string;
  address: Address;
  comments: Comment[];
  contacts: Contact[];
  employees: number | null;
  experience: StudioExperience;
  foundingDate: number | null;
  logoUrl: string | null;
  name: string;
  phoneNumber: string | null;
  projects: Project[];
  websiteUrl: string | null;
}

export default class {
  public readonly id: string;
  public readonly address: Address;
  public readonly comments: Comment[];
  public readonly contacts: Contact[];
  public readonly employees?: number;
  public readonly experience: StudioExperience;
  public readonly foundingDate?: number;
  public readonly logoUrl?: string;
  public readonly name: string;
  public readonly phoneNumber?: string;
  public readonly projects: Project[];
  public readonly websiteUrl?: string;

  constructor(args: StudioArgs) {
    this.id = args.id;
    this.address = args.address;
    this.comments = args.comments;
    this.contacts = args.contacts;
    this.employees = args.employees ?? undefined;
    this.experience = args.experience;
    this.foundingDate = args.foundingDate ?? undefined;
    this.logoUrl = args.logoUrl ?? undefined;
    this.name = args.name;
    this.phoneNumber = args.phoneNumber ?? undefined;
    this.projects = args.projects;
    this.websiteUrl = args.websiteUrl ?? undefined;
  }
}
