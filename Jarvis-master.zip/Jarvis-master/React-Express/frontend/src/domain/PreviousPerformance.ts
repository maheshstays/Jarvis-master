import PlatformPerformance from './PlatformPerformance';

interface PreviousPerformanceArgs {
  id: string;
  gameName: string;
  referenceUrl: string;
  trailerUrl: string;
  platformsPerformance: PlatformPerformance[];
}

export default class {
  public readonly id: string;
  public readonly gameName: string;
  public readonly referenceUrl: string;
  public readonly trailerUrl: string;
  public readonly platformsPerformance: PlatformPerformance[];

  constructor(args: PreviousPerformanceArgs) {
    this.id = args.id;
    this.gameName = args.gameName;
    this.referenceUrl = args.referenceUrl;
    this.trailerUrl = args.trailerUrl;
    this.platformsPerformance = args.platformsPerformance;
  }
}
