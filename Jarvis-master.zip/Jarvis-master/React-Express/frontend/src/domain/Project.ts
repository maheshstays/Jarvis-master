import Comment from './Comment';
import Contact from './Contact';
import KPI from './KPI';
import LegalInformation from './LegalInformation';
import Milestone from './milestones/Milestone';

interface ProjectArgs {
  contacts: Contact[];
  id: string;
  name: string;
  thumbnailUrl: string | null;
  managedBy: string | null;
  statusName: string;
  statusLevel: string;
  statusDate: number;
  tier: number;
  projectCompletionKPI: KPI;
  totalFundingKPI: KPI;
  playfabUrl: string;
  googleDriveUrl: string;
  jiraUrl: string;
  discordUrl: string;
  legalInformation: LegalInformation;
  milestones: Milestone[];
  gameInformationComments: Comment[];
  milestonesComments: Comment[];
  previousPerformanceComments: Comment[];
  technicalInformationComments: Comment[];
}

export default class {
  public readonly id: string;
  public readonly name: string;
  public readonly thumbnailUrl?: string;
  public readonly managedBy?: string;
  public readonly contacts: Contact[];
  public readonly statusName: string;
  public readonly statusLevel: string;
  public readonly statusDate: number;
  public readonly tier: number;
  public readonly projectCompletionKPI: KPI;
  public readonly totalFundingKPI: KPI;
  public readonly playfabUrl: string;
  public readonly googleDriveUrl: string;
  public readonly jiraUrl: string;
  public readonly discordUrl: string;
  public readonly legalInformation: LegalInformation;
  public readonly milestones: Milestone[];
  public readonly gameInformationComments: Comment[];
  public readonly milestonesComments: Comment[];
  public readonly previousPerformanceComments: Comment[];
  public readonly technicalInformationComments: Comment[];

  constructor(args: ProjectArgs) {
    this.id = args.id;
    this.name = args.name;
    this.thumbnailUrl = args.thumbnailUrl ?? undefined;
    this.managedBy = args.managedBy ?? undefined;
    this.contacts = args.contacts;
    this.statusName = args.statusName;
    this.statusLevel = args.statusLevel;
    this.statusDate = args.statusDate;
    this.tier = args.tier;
    this.projectCompletionKPI = args.projectCompletionKPI;
    this.totalFundingKPI = args.totalFundingKPI;
    this.playfabUrl = args.playfabUrl;
    this.googleDriveUrl = args.googleDriveUrl;
    this.jiraUrl = args.jiraUrl;
    this.discordUrl = args.discordUrl;
    this.legalInformation = args.legalInformation;
    this.milestones = args.milestones;
    this.gameInformationComments = args.gameInformationComments;
    this.milestonesComments = args.milestonesComments;
    this.previousPerformanceComments = args.previousPerformanceComments;
    this.technicalInformationComments = args.technicalInformationComments;
  }
}
