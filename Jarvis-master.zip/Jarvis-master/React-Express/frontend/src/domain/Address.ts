interface AddressArgs {
  city: string | null;
  country: string | null;
  state: string | null;
  street: string | null;
  zipcode: string | null;
}

export default class {
  public readonly city?: string;
  public readonly country?: string;
  public readonly state?: string;
  public readonly street?: string;
  public readonly zipcode?: string;

  constructor(args: AddressArgs | null) {
    if (args) {
      this.city = args.city ?? undefined;
      this.country = args.country ?? undefined;
      this.state = args.state ?? undefined;
      this.street = args.street ?? undefined;
      this.zipcode = args.zipcode ?? undefined;
    }
  }
}
