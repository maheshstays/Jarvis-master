import Platform from './Platform';

interface PlatformPerformanceArgs {
  id: string;
  platform: Platform;
  downloads: number;
  rating: number;
}

export default class PlatformPerformance {
  public readonly id: string;
  public readonly platform: Platform;
  public readonly downloads: number;
  public readonly rating: number;

  constructor(args: PlatformPerformanceArgs) {
    this.id = args.id;
    this.platform = args.platform;
    this.downloads = args.downloads;
    this.rating = args.rating;
  }
}
