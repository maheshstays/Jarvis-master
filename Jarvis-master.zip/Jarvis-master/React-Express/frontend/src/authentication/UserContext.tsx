import React, { Component, createContext } from 'react';
import { Subscription } from 'rxjs';
import AuthService from '../services/relay/AuthService';

interface State {
  isAuthenticated: boolean;
}

const UserContext = createContext({ isAuthenticated: false });

export class UserProvider extends Component<{}, State> {
  public state: State = { isAuthenticated: false };

  private userSubscription!: Subscription;

  public componentDidMount() {
    this.userSubscription = AuthService.getUser().subscribe(
      ({ isAuthenticated }) => this.setState({ isAuthenticated }),
    );
  }

  public componentWillUnmount() {
    this.userSubscription.unsubscribe();
  }

  public render() {
    return (
      <UserContext.Provider value={this.state}>
        {this.props.children}
      </UserContext.Provider>
    );
  }
}

export const UserConsumer = UserContext.Consumer;
