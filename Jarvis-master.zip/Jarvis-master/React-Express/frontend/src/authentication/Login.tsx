import { Redirect, RouteComponentProps } from '@reach/router';
import React from 'react';
import { GoogleLogin } from 'react-google-login';
import { GOOGLE_CLIENT_ID } from '../constants';
import AuthService from '../services/relay/AuthService';
import { UserConsumer, UserProvider } from './UserContext';

interface Props extends RouteComponentProps {
  children?: never;
}

export default (_: Props) => (
  <div>
    <h2>Login</h2>
    <UserConsumer>{
      ({ isAuthenticated }: UserProvider['state']) => isAuthenticated
        ? <Redirect noThrow={true} to="/"/>
        : <GoogleLogin
          clientId={GOOGLE_CLIENT_ID}
          buttonText="Login"
          onSuccess={AuthService.login}
          onFailure={() => null}
          cookiePolicy={'single_host_origin'}
        />
    }</UserConsumer>
  </div>
);
