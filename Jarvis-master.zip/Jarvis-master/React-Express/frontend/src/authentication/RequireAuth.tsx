import { Redirect, RouteComponentProps } from '@reach/router';
import React, { ReactNode } from 'react';
import { UserConsumer, UserProvider } from './UserContext';

interface Props extends RouteComponentProps {
  children: ReactNode;
}

export default ({ children }: Props) => (
  <UserConsumer>{
    (value: UserProvider['state']) => value?.isAuthenticated
      ? children
      : <Redirect noThrow={true} to="login"/>
  }</UserConsumer>
);
