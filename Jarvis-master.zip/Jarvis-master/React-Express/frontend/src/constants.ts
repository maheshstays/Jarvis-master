export const NUTAKU_BIZ_DEV = 'Nutaku BizDev';
export const DEVELOPER_PRODUCER = 'Developer Producer';
export const NUTAKU_PRODUCER = 'Nutaku Producer';
export const GOOGLE_CLIENT_ID = '757951978041-tdscpos8h68kohfg4klrmstlp7p91kpa.apps.googleusercontent.com';
export const SESSION_COOKIE_NAME = 'vision.sid';
