switch(process.env.NODE_ENV) {
  case "production": 
    module.exports = {
      "type": "mysql",
      "host": "jarvis-prod-db.cwafwz13jsbv.us-east-1.rds.amazonaws.com",
      "port": 3306,
      "username": "root",
      "password": "Rb.3Wab-%#yT",
      "database": "jarvis_prod_db",
      "entities": ["dist/entities/*.js"],
      "charset": "utf8mb4",
      "logging": true,
      "logger": "file"
    }
    break;
  default:
    module.exports = {
      "type": "mysql",
      "host": "localhost",
      "port": 33060,
      "username": "root",
      "password": "#wh32mzQ5d${",
      "database": "jarvis_dev_db",
      "entities": ["src/entities/*.ts"],
      "charset": "utf8mb4",
      "logging": true, 
    }
}