import { ValidationError } from 'apollo-server-express';
import { ArgumentNode, ASTNode, GraphQLScalarType, Kind } from 'graphql';

export default new GraphQLScalarType({
  description: 'Custom Date scalar type that serializes server\'s dates into numbers and parses them back into JavaScript\'s dates.',
  name: 'Date',
  parseLiteral: (ast: ASTNode): Date => {
    if (ast.kind === Kind.INT) {
      return new Date(Number(ast.value));
    }
    throw new ValidationError(`Expected value of type Date passed as an integer, received ${(ast as ArgumentNode).value} (${ast.kind}) instead. In JavaScript, simply execute Date.getTime().`);
  },
  parseValue: (value: any): Date => {
    if (typeof value === 'number') {
      return new Date(value);
    }
    throw new ValidationError(`Expected value of type Date passed as an integer, received ${value} (${typeof value}) instead. In JavaScript, simply execute Date.getTime().`);
  },
  serialize: (value: Date): number => value.getTime(),
});
