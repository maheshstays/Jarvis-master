import projects from './queries/projects';
import studios from './queries/studios';

export default {
  projects,
  studios,
};
