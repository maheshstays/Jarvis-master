import Context from '../../authentication/Context';

export default async (_0: any, args: { [key: string]: any }, context: Context): Promise<'SUCCESS'> => {
    context.req.headers.id_token = args.token;

    const { user } = await context.authenticate('google-id-token');
    await context.login(user);

    return 'SUCCESS';
};
