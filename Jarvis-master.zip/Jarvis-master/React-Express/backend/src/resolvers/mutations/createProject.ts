import { UserInputError } from 'apollo-server-express';
import Project from '../../entities/Project';
import ProjectMapper from './mappers/ProjectMapper';

export default async (_0: any, args: { [key: string]: any }): Promise<Project> => {
  const project = ProjectMapper.assemble(args.project, args.studioId);

  try {
    await project.save();
  } catch (error) {
    if (error.code === 'ER_NO_REFERENCED_ROW_2') { throw new UserInputError(`Studio with id '${args.studioId}' doesn't exist.`); }
    throw error;
  }

  return project;
};
