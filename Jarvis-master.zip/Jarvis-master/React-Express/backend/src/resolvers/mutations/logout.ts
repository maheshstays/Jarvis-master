import Context from '../../authentication/Context';
import SessionOptions from '../../authentication/SessionOptions';
import { SESSION_COOKIE_NAME } from '../../constants';

export default async (_0: any, _1: { [key: string]: any }, context: Context): Promise<'SUCCESS'> => {
  context.logout();

  await new Promise((resolve) => context.req.session
    ? context.req.session.destroy(resolve)
    : resolve(),
  );

  context.res.cookie(SESSION_COOKIE_NAME, '', {
    ...(new SessionOptions()).cookie,
    expires: new Date(0),
    maxAge: 0,
  });

  return 'SUCCESS';
};
