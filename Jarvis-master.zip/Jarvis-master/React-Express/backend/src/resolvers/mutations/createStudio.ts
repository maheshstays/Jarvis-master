import Studio from '../../entities/Studio';
import StudioMapper from './mappers/StudioMapper';

export default async (_0: any, args: { [key: string]: any }): Promise<Studio> => {
  const studio = StudioMapper.assemble(args.studio);
  await studio.save();

  return studio;
};
