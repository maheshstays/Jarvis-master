import { UserInputError } from 'apollo-server-express';
import { GraphQLResolveInfo } from 'graphql';
import Context from '../../authentication/Context';
import Project from '../../entities/Project';
import SelectionSet from '../utils/SelectionSet';
import ProjectMapper from './mappers/ProjectMapper';

export default async (
  _0: any, args: { [key: string]: any }, _2: Context,
  { operation: { selectionSet } }: GraphQLResolveInfo,
): Promise<Project> => {
  const project = await Project.findWithRelatedData(args.project.id, new SelectionSet(selectionSet, ['updateProject']));
  if (!project) { throw new UserInputError(`Project with id '${args.project.id}' doesn't exist.`); }

  ProjectMapper.apply(project, args.project);
  await project.save();

  return project;
};
