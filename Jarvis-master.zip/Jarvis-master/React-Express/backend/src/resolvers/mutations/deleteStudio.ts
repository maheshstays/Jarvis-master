import Studio from '../../entities/Studio';

export default async (_0: any, args: { [key: string]: any }): Promise<'SUCCESS'> => {
  await Studio.delete(args.studioId);

  return 'SUCCESS';
};
