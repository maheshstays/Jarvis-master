export default abstract class {
  protected static apply(entity: any, input: any): void {
    Object.entries(input).forEach(([key, value]: [string, any]) => {
      if (Object.prototype.toString.call(value) === '[object Object]') {
        this.apply(entity[key] ?? (entity[key] = {}), input[key]);
      } else { entity[key] = value; }
    });
  }
}
