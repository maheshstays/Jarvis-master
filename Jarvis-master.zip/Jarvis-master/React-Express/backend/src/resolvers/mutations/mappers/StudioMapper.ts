import Studio from '../../../entities/Studio';
import StudioAddress from '../../../entities/StudioAddress';
import AbstractMapper from './AbstractMapper';

export default class extends AbstractMapper {
  public static assemble(input: any): Studio {
    const studio = new Studio();
    studio.employees = input.employees;
    studio.foundingDate = input.foundingDate;
    studio.gamesLaunched = input.gamesLaunched;
    studio.hasF2pExperience = input.hasF2pExperience;
    studio.hasLiveOpsExperience = input.hasLiveOpsExperience;
    studio.logoUrl = input.logoUrl;
    studio.name = input.name;
    studio.phoneNumber = input.phoneNumber;
    studio.successfulRating = input.successfulRating;
    studio.successfulTitle = input.successfulTitle;
    studio.successfulUrl = input.successfulUrl;
    studio.websiteUrl = input.websiteUrl;

    if (input.address) {
      const address = new StudioAddress();
      address.city = input.address.city;
      address.country = input.address.country;
      address.state = input.address.state;
      address.street = input.address.street;
      address.zipcode = input.address.zipcode;

      studio.address = address;
    }

    return studio;
  }

  public static apply(studio: Studio, input: any) {
    super.apply(studio, input);
  }
}
