import Project from '../../../entities/Project';
import Studio from '../../../entities/Studio';
import AbstractMapper from './AbstractMapper';

export default class extends AbstractMapper {
  public static assemble(input: any, studioId: number): Project {
    const project = new Project();
    project.managedBy = input.managedBy;
    project.name = input.name;
    project.thumbnailUrl = input.thumbnailUrl;
    project.studio = { id: studioId } as Studio;

    return project;
  }

  public static apply(project: Project, input: any) {
    super.apply(project, input);
  }
}
