import { UserInputError } from 'apollo-server-express';
import { GraphQLResolveInfo } from 'graphql';
import Context from '../../authentication/Context';
import Studio from '../../entities/Studio';
import SelectionSet from '../utils/SelectionSet';
import StudioMapper from './mappers/StudioMapper';

export default async (
  _0: any, args: { [key: string]: any }, _2: Context,
  { operation: { selectionSet } }: GraphQLResolveInfo,
): Promise<Studio> => {
  const studio = await Studio.findWithRelatedData(args.studio.id, new SelectionSet(selectionSet, ['updateStudio']), ['address']);
  if (!studio) { throw new UserInputError(`Studio with id '${args.studio.id}' doesn't exist.`); }

  StudioMapper.apply(studio, args.studio);
  await studio.save();

  return studio;
};
