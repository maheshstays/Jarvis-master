import Project from '../../entities/Project';

export default async (_0: any, args: { [key: string]: any }): Promise<'SUCCESS'> => {
  await Project.delete(args.projectId);

  return 'SUCCESS';
};
