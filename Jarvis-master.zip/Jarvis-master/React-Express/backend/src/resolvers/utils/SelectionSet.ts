import { FieldNode, SelectionNode, SelectionSetNode } from 'graphql';

export default class {
  private selectionSet: SelectionSetNode;

  constructor(selectionSet: SelectionSetNode, path: string[]) {
    this.selectionSet = selectionSet;

    path.forEach((element: string) => {
      const subField = this.find(element);

      if (subField && subField.selectionSet) {
        this.selectionSet = subField.selectionSet;
      } else {
        throw new Error('Invalid SelectionSet path argument');
      }
    });
  }

  public isSelected(field: string): boolean {
    return !!this.find(field);
  }

  private find(field: string): FieldNode | undefined {
    return this.selectionSet.selections.find((selection: SelectionNode) =>
      (selection as FieldNode).name?.value === field,
    ) as FieldNode | undefined;
  }
}
