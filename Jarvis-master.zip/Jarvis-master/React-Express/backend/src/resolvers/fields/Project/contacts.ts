import Contact from '../../../domain/Contact';
import PermissionProject from '../../../entities/PermissionProject';
import Project from '../../../entities/Project';

export default (source: Project) => source.permissions?.map((permission: PermissionProject) =>
  new Contact({ email: permission.domainEmail, role: permission.role }),
) ?? [];
