import Contact from '../../../domain/Contact';
import PermissionStudio from '../../../entities/PermissionStudio';
import Studio from '../../../entities/Studio';

export default (source: Studio) => source.permissions?.map((permission: PermissionStudio) =>
  new Contact({ email: permission.domainEmail, role: permission.role }),
) ?? [];
