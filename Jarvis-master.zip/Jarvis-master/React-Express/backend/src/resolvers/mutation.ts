import createProject from './mutations/createProject';
import createStudio from './mutations/createStudio';
import deleteProject from './mutations/deleteProject';
import deleteStudio from './mutations/deleteStudio';
import login from './mutations/login';
import logout from './mutations/logout';
import updateProject from './mutations/updateProject';
import updateStudio from './mutations/updateStudio';

export default {
  createProject,
  createStudio,
  deleteProject,
  deleteStudio,
  login,
  logout,
  updateProject,
  updateStudio,
};
