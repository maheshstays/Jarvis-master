import { GraphQLResolveInfo } from 'graphql';
import Context from '../../authentication/Context';
import Studio from '../../entities/Studio';
import SelectionSet from '../utils/SelectionSet';

export default async (
  _0: any, _1: { [key: string]: any }, _2: Context, { operation: { selectionSet }}: GraphQLResolveInfo,
): Promise<Studio[]>  => await Studio.findAllWithRelatedData(new SelectionSet(selectionSet, ['studios']));
