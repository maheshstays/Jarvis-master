import { GraphQLResolveInfo } from 'graphql';
import Context from '../../authentication/Context';
import Project from '../../entities/Project';
import SelectionSet from '../utils/SelectionSet';

export default async (
  _0: any, args: { [key: string]: any }, _2: Context, { operation: { selectionSet }}: GraphQLResolveInfo,
): Promise<Project[]> => await Project.findAllWithRelatedData(
  args.studioName,
  new SelectionSet(selectionSet, ['projects']),
);
