import { TypeormStore } from 'connect-typeorm';
import { getRepository } from 'typeorm';

import { SESSION_COOKIE_DOMAIN, SESSION_COOKIE_NAME } from '../constants';
import Session from '../entities/Session';

export default class {
  public cookie = {
    domain: process.env.NODE_ENV === 'production' ? SESSION_COOKIE_DOMAIN : undefined,
    httpOnly: false,
    maxAge: 1800000,
    sameSite: true,
    secure: process.env.NODE_ENV === 'production' ? true : undefined,
  };

  public name = SESSION_COOKIE_NAME;

  public proxy = true;

  public resave = false;

  public rolling = true;

  public saveUninitialized = false;

  public secret = 'wqt@9@p.3b*xU$qR';

  public store = new TypeormStore({
      cleanupLimit: 10,
      limitSubquery: false,
    }).connect(getRepository(Session));

  public unset = 'destroy';
}
