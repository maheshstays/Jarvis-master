import { AuthenticationError } from 'apollo-server-express';
import passport from 'passport';
import GoogleIdTokenStrategy from 'passport-google-id-token';

import { AUTHENTICATION_HOSTED_DOMAIN, GOOGLE_CLIENT_ID } from '../constants';
import User from '../entities/User';

type DoneCallback<T> = (error: Error | null, payload?: T | false, info?: { message: string }) => void;

interface JWT {
  header: {
    alg: string;
    kid: string;
    typ: string;
  };
  payload: {
    iss: string;
    azp: string;
    aud: string;
    sub: string;
    hd: string;
    email: string;
    email_verified: boolean;
    at_hash: string;
    name: string;
    picture: string;
    given_name: string;
    family_name: string;
    locale: string;
    iat: number;
    exp: number;
    jti: string;
  };
  signature: string;
}

passport.use(new GoogleIdTokenStrategy(
  { clientID: GOOGLE_CLIENT_ID },
  async (token: JWT, googleId: string, done: DoneCallback<Express.User>) => {
    if (token.payload.hd !== AUTHENTICATION_HOSTED_DOMAIN) {
      return done(new AuthenticationError(''));
    }

    const user = new User();
    user.id = googleId;
    user.domainEmail = token.payload.email;

    try {
      await user.save();
      return done(null, user);
    } catch {
      return done(new Error('ERR_001')); // Reason: some problems occurred while connecting to the database
    }
  },
));

passport.serializeUser((user: Express.User, done: DoneCallback<string>) => {
  done(null, user.id);
});

passport.deserializeUser(async (id: string, done: DoneCallback<Express.User>) => {
  const user = await User.findOne({ id });
  return done(null, user ?? false);
});
