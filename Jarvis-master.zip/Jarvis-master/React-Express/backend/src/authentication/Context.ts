import { AuthenticationError } from 'apollo-server-express';
import { Request, Response } from 'express';
import passport from 'passport';

export interface ExpressContext {
  req: Request;
  res: Response;
  [key: string]: any;
}

interface AuthenticateReturn {
  user: Express.User;
}

export default class {
  public isAuthenticated: () => boolean;
  public isUnauthenticated: () => boolean;
  public getUser: () => Express.User | undefined;
  public authenticate: (name: string, options?: object) => Promise<AuthenticateReturn>;
  public login: (user: Express.User, options?: object) => Promise<void>;
  public logout: () => void;
  public req: Request;
  public res: Response;
  public others: { [key: string]: any };

  constructor(context: ExpressContext) {
    const { req, res, ...others } = context;

    this.isAuthenticated = () => req.isAuthenticated();
    this.isUnauthenticated = () => req.isUnauthenticated();
    this.getUser = () => req.user;
    this.authenticate =
      (name: string, options?: object) => this.promisifiedAuthenticate(req, res, name, options);
    this.login = (user: Express.User, options?: object) => this.promisifiedLogin(req, user, options);
    this.logout = () => req.logout();
    this.req = req;
    this.res = res;
    this.others = others;
  }

  private promisifiedAuthenticate(req: Request, res: Response, name: string, options?: object) {
    return new Promise<AuthenticateReturn>((resolve, reject) => {
      const done = (error: Error | null, user: Express.User | false) => {
        if (error) {
          reject(new AuthenticationError(''));
        } else if (!user) {
          reject(new AuthenticationError(''));
        } else {
          resolve({ user });
        }
      };

      let authenticateFn;
      if (options) {
        authenticateFn = passport.authenticate(name, options, done);
      } else {
        authenticateFn = passport.authenticate(name, done);
      }

      return authenticateFn(req, res);
    });
  }

  private promisifiedLogin(req: Request, user: Express.User, options?: object) {
    return new Promise<void>((resolve, reject) => {
      const done = (error?: Error) => {
        if (error) {
          reject(new Error('ERR_002')); // Reason: passport.initialize() middleware not in use
                                        //         or done callback not passed to req.login
        } else {
          resolve();
        }
      };

      if (options) {
        req.login(user, options, done);
      } else {
        req.login(user, done);
      }
    });
  }
}
