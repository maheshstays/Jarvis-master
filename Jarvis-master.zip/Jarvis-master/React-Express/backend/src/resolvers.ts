import { IResolvers } from 'graphql-tools';
import ProjectContacts from './resolvers/fields/Project/contacts';
import StudioContacts from './resolvers/fields/Studio/contacts';
import Mutation from './resolvers/mutation';
import Query from './resolvers/query';
import Date from './resolvers/scalars/Date';

const resolvers: IResolvers = {
  Date,
  Mutation,
  Project: {
    contacts: ProjectContacts,
  },
  Query,
  Studio: {
    contacts: StudioContacts,
  },
};

export default resolvers;
