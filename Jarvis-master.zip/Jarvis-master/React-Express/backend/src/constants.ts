export const AUTHENTICATION_HOSTED_DOMAIN = 'ntku.net';
export const GOOGLE_CLIENT_ID = '757951978041-tdscpos8h68kohfg4klrmstlp7p91kpa.apps.googleusercontent.com';
export const GRAPHQL_PATH = '/graphql';
export const SERVER_PORT = 3001;
export const SESSION_COOKIE_DOMAIN = '.vision.ntku.net';
export const SESSION_COOKIE_NAME = 'vision.sid';
export const CORS_ORIGIN = process.env.NODE_ENV === 'production'
  ? ['https://vision.ntku.net', 'https://www.vision.ntku.net']
  : 'http://localhost:3000';
