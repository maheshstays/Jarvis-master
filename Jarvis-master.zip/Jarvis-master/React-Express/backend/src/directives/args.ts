import { SchemaDirectiveVisitor } from 'apollo-server-express';
import {
  defaultFieldResolver,
  DirectiveNode,
  FieldDefinitionNode,
  getNamedType,
  GraphQLArgument,
  GraphQLField,
  GraphQLInputFieldMap,
  GraphQLInputObjectType,
  GraphQLNamedType,
  GraphQLObjectType,
  GraphQLResolveInfo,
  GraphQLSchema,
  InputValueDefinitionNode,
  Kind,
  ListValueNode,
  StringValueNode,
  ValueNode,
} from 'graphql';
import Context from '../authentication/Context';
import omittableNonNull from './omittableNonNull';
import uid from './uid';

const ARGS_DIRECTIVE = 'args';

const DIRECTIVE_TRANSFORMERS: {
  [directive: string]: (value: any, name: string) => Promise<any>;
} = {
  omittableNonNull: omittableNonNull.parseOmittableNonNull,
  uid: uid.parseUid,
};

export default class Args extends SchemaDirectiveVisitor {
  private static directives: string[] = [];

  public visitSchema(schema: GraphQLSchema) {
    const argsDirective = schema.getDirective(ARGS_DIRECTIVE)?.astNode;
    if (!argsDirective) { return; }

    const managedDirectives = argsDirective.arguments?.find((argument: InputValueDefinitionNode) =>
      argument.name.value === 'directives',
    );

    (managedDirectives?.defaultValue as ListValueNode)?.values.forEach((value: ValueNode) => {
      const directive = (value as StringValueNode).value;
      if (directive) { Args.directives.push(directive); }
    });

    const types = Object.values(schema.getTypeMap());

    types
      .filter((type: GraphQLNamedType) => type.astNode?.kind === Kind.OBJECT_TYPE_DEFINITION)
      .map((type: GraphQLNamedType) => type as GraphQLObjectType)
      .forEach((type: GraphQLObjectType) => {
        const fields = type.astNode?.fields;

        if (fields) {
          fields.forEach((field: FieldDefinitionNode) => {
            const args = field.arguments;

            if (args) {
              args.forEach((arg: InputValueDefinitionNode) => {
                const directives = arg.directives;

                if (!this.containsDirective(ARGS_DIRECTIVE, directives)) {
                  (directives as unknown as DirectiveNode[]).push({
                    arguments: [],
                    kind: Kind.DIRECTIVE,
                    name: argsDirective.name,
                  });
                }
              });
            }
          });
        }
      });
  }

  public visitArgumentDefinition(argument: GraphQLArgument, { field }: { field: GraphQLField<any, any> }) {
    const type = getNamedType(argument.type);

    if (type instanceof GraphQLInputObjectType) {
      const { resolve = defaultFieldResolver } = field;

      field.resolve = async (source: any, args: { [key: string]: any }, context: Context, info: GraphQLResolveInfo) => {
        await this.applyDirectiveTransformers(type.getFields(), args[argument.name]);
        return resolve.apply(this, [source, args, context, info]);
      };
    }
  }

  private containsDirective(name: string, directives?: readonly DirectiveNode[]): boolean {
    return !!directives && !!directives.find((directive: DirectiveNode) => directive.name.value === name);
  }

  private async applyDirectiveTransformers(fields: GraphQLInputFieldMap, args: { [key: string]: any }) {
    for (const [name, field] of Object.entries(fields)) {
      for (const directive of Args.directives) {
        if (this.containsDirective(directive, field.astNode?.directives)) {
          const transformedValue = await DIRECTIVE_TRANSFORMERS[directive](args[name], name);
          if (transformedValue !== undefined) { args[name] = transformedValue; }
        }
      }

      const type = getNamedType(field.type);
      if (type instanceof GraphQLInputObjectType) {
        await this.applyDirectiveTransformers(type.getFields(), args[name]);
      }
    }
  }
}
