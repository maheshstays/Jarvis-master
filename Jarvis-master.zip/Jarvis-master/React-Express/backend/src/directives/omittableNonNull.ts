import { SchemaDirectiveVisitor, ValidationError } from 'apollo-server-express';
import { GraphQLInputField, GraphQLNonNull, GraphQLScalarType } from 'graphql';

export default class OmittableNonNull extends SchemaDirectiveVisitor {
  public static async parseOmittableNonNull(value: any, name: string): Promise<any> {
    if (value === null) {
      throw new ValidationError(`Field with name '${name}' cannot be null if specified.`);
    }

    return Promise.resolve(value);
  }

  public visitInputFieldDefinition(field: GraphQLInputField) {
    if (field.type instanceof GraphQLNonNull) {
      throw new ValidationError('Directive @omittableNonNull should not be used with GraphQLNonNull type (!).');
    }

    if (!(field.type instanceof GraphQLScalarType)) {
      throw new ValidationError('Directive @omittableNonNull should only be used with GraphQLScalar type.');
    }
  }
}
