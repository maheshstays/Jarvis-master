import { AuthenticationError, ForbiddenError, SchemaDirectiveVisitor } from 'apollo-server-express';
import {
  defaultFieldResolver,
  DirectiveNode,
  GraphQLField,
  GraphQLInterfaceType,
  GraphQLNamedType,
  GraphQLObjectType,
  GraphQLResolveInfo,
  GraphQLSchema,
  Kind,
} from 'graphql';

import Context from '../authentication/Context';

type ExtendedGraphQLField = GraphQLField<any, any> & { requires?: Role[] };
type ExtendedGraphQLObjectType =
  (GraphQLObjectType | GraphQLInterfaceType) &
  { authenticationEnforced?: boolean, requires?: Role[] };

enum Role {
  ADMIN = 'ADMIN', KNOWN = 'KNOWN', ANY = 'ANY', UNKNOWN = 'UNKNOWN',
}

const AUTH_DIRECTIVE = 'auth';

export default class extends SchemaDirectiveVisitor {
  public visitSchema(schema: GraphQLSchema) {
    const authDirective = schema.getDirective(AUTH_DIRECTIVE)?.astNode;
    if (!authDirective) { return; }

    const types = Object.values(schema.getTypeMap());

    types
      .filter((type: GraphQLNamedType) => type.astNode?.kind === Kind.OBJECT_TYPE_DEFINITION)
      .forEach((type: GraphQLNamedType) => {
        if (
          type.astNode?.directives &&
          !type.astNode.directives.find((directive: DirectiveNode) => directive.name.value === AUTH_DIRECTIVE)
        ) {
          (type.astNode.directives as unknown as DirectiveNode[]).push({
            arguments: [],
            kind: Kind.DIRECTIVE,
            name: authDirective.name,
          });
        }
    });
  }

  public visitObject(type: GraphQLObjectType) {
    this.enforceAuthenticationOnFields(type);
    (type as unknown as ExtendedGraphQLObjectType).requires = this.args.requires;
  }

  public visitFieldDefinition(
    field: GraphQLField<any, any>,
    details: { objectType: GraphQLObjectType | GraphQLInterfaceType },
  ) {
    this.enforceAuthenticationOnFields(details.objectType);
    (field as unknown as ExtendedGraphQLField).requires = this.args.requires;
  }

  private enforceAuthenticationOnFields(type: ExtendedGraphQLObjectType) {
    if (type.authenticationEnforced) { return; }
    type.authenticationEnforced = true;

    const fields = Object.values(type.getFields());

    fields.forEach((field: ExtendedGraphQLField) => {
      const { resolve = defaultFieldResolver } = field;

      field.resolve = (source: any, args: { [key: string]: any }, context: Context, info: GraphQLResolveInfo) => {
        const requires = field.requires || type.requires;

        if (requires) {
          const actualRole = context.isAuthenticated()
            ? Role.ADMIN // TO DO: Get role from database for context.getUser()
            : Role.UNKNOWN;

          if (
            !requires.includes(Role.UNKNOWN) &&
            !requires.includes(Role.ANY) &&
            actualRole === Role.UNKNOWN
          ) {
            throw new AuthenticationError('');
          }  else if (
            (actualRole !== Role.ADMIN || (actualRole === Role.ADMIN && requires.includes(Role.UNKNOWN))) &&
            !requires.includes(Role.ANY) &&
            !requires.includes(actualRole) &&
            !(requires.includes(Role.KNOWN) && actualRole !== Role.UNKNOWN)
          ) {
            throw new ForbiddenError('');
          }
        }

        return resolve.apply(this, [source, args, context, info]);
      };
    });
  }
}
