import { SchemaDirectiveVisitor, ValidationError } from 'apollo-server-express';
import {
  defaultFieldResolver,
  getNamedType,
  GraphQLArgument,
  GraphQLField,
  GraphQLID,
  GraphQLInputField,
  GraphQLInputObjectType,
  GraphQLInputType,
  GraphQLInterfaceType,
  GraphQLObjectType,
  GraphQLOutputType,
  GraphQLResolveInfo,
} from 'graphql';
import { getConnectionOptions } from 'typeorm';
import Context from '../authentication/Context';

export default class UID extends SchemaDirectiveVisitor {
  public static async parseUid(value: string, name: string): Promise<string | number> {
    if (await UID.shouldApply()) {
      const match = value.match(/_(\d+)$/);

      if (match && match[1]) {
        return Number(match[1]);
      }

      throw new ValidationError(`Field with name '${name}' is not a valid MySQL/MariaDB generated UID.`);
    }

    return value;
  }

  private static ensureAppliedOnId(type: GraphQLInputType | GraphQLOutputType, name: string, parent?: string) {
    const namedType = getNamedType(type);

    if (namedType !== GraphQLID) {
      throw new ValidationError(`Field or argument '${name}' ${parent ? `of object ${parent} ` : ''}must be of type GraphQLID. Found type ${namedType.name} instead.`);
    }
  }

  private static async shouldApply(): Promise<boolean> {
    const options = await getConnectionOptions();
    return options.type === 'mysql' || options.type === 'mariadb';
  }

  public visitInputFieldDefinition(field: GraphQLInputField, { objectType }: { objectType: GraphQLInputObjectType }) {
    UID.ensureAppliedOnId(field.type, field.name, objectType.name);
  }

  public visitFieldDefinition(
    field: GraphQLField<any, any>,
    { objectType }: { objectType: GraphQLObjectType | GraphQLInterfaceType },
  ) {
    UID.ensureAppliedOnId(field.type, field.name, objectType.name);

    field.resolve = async (source: any) => {
      if (await UID.shouldApply()) {
        return `${objectType.name}_${source.id}`;
      }

      return `${source.id}`;
    };
  }

  public visitArgumentDefinition(argument: GraphQLArgument, { field }: { field: GraphQLField<any, any> }) {
    UID.ensureAppliedOnId(argument.type, argument.name);

    const { resolve = defaultFieldResolver } = field;
    field.resolve = async (source: any, args: { [key: string]: any }, context: Context, info: GraphQLResolveInfo) =>
      resolve.apply(this, [
        source,
        {
          ...args,
          [argument.name]: await UID.parseUid(args[argument.name], argument.name),
        },
        context,
        info,
      ]);
  }
}
