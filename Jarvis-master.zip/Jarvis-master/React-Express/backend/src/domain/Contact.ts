import Role from '../entities/Role';

interface ContactArgs {
  email: string;
  name?: string;
  role: Role;
  skype?: string;
}

export default class {
  public readonly email: string;
  public readonly name?: string;
  public readonly role: Role;
  public readonly skype?: string;

  constructor(args: ContactArgs) {
    this.email = args.email;
    this.name = args.name;
    this.role = args.role;
    this.skype = args.skype;
  }
}
