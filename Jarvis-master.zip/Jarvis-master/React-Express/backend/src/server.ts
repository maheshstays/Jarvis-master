import { ApolloServer } from 'apollo-server-express';
import compression from 'compression';
import express from 'express';
import sessions from 'express-session';
import depthLimit from 'graphql-depth-limit';
import { createServer } from 'http';
import passport from 'passport';
import 'reflect-metadata';
import { createConnection } from 'typeorm';

import Context, { ExpressContext } from './authentication/Context';
import './authentication/passport';
import SessionOptions from './authentication/SessionOptions';
import { CORS_ORIGIN, GRAPHQL_PATH, SERVER_PORT } from './constants';
import schema from './schema';

createConnection().then(() => {
  const app = express();
  app.use(compression());
  app.use(sessions(new SessionOptions()));
  app.use(passport.initialize());
  app.use(passport.session());

  const apollo = new ApolloServer({
    context: (context: ExpressContext) => new Context(context),
    schema,
    validationRules: [ depthLimit(7) ],
  });
  apollo.applyMiddleware({ app, cors: { credentials: true, origin: CORS_ORIGIN }});
  apollo.applyMiddleware({ app, path: GRAPHQL_PATH });

  createServer(app).listen(
    { port: SERVER_PORT },
    (): void => console.log(`GraphQL API is now running on http://localhost:${SERVER_PORT}${GRAPHQL_PATH}`),
  );
}).catch((error: Error) => {
  console.error(error);
});
