import { GraphQLSchema } from 'graphql';
import 'graphql-import-node';
import { makeExecutableSchema } from 'graphql-tools';

import schemaDirectives from './directives';
import resolvers from './resolvers';
import * as typeDefs from './schema/schema.graphql';

const schema: GraphQLSchema = makeExecutableSchema({
  resolvers,
  schemaDirectives,
  typeDefs,
});

export default schema;
