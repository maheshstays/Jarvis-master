
import { BaseEntity, Column, Entity, PrimaryGeneratedColumn } from 'typeorm';

@Entity()
export default class Comment extends BaseEntity {
  @PrimaryGeneratedColumn()
  public id!: number;

  @Column()
  public author!: string;

  @Column()
  public date!: Date;

  @Column()
  public text!: string;
}
