import {
  BaseEntity, Column, Entity, JoinTable, ManyToMany, OneToMany, OneToOne, PrimaryGeneratedColumn, SelectQueryBuilder,
} from 'typeorm';
import SelectionSet from '../resolvers/utils/SelectionSet';
import Comment from './Comment';
import PermissionProject from './PermissionProject';
import PermissionStudio from './PermissionStudio';
import Project from './Project';
import Role from './Role';
import StudioAddress from './StudioAddress';

@Entity()
export default class Studio extends BaseEntity {
  public static async findWithRelatedData(
    id: number, selectionSet: SelectionSet, relations?: string[],
  ): Promise<Studio | undefined> {
    return this.buildQuery(selectionSet, relations ?? []).where(`${Studio.name}.id = ${id}`).getOne();
  }

  public static async findAllWithRelatedData(selectionSet: SelectionSet, relations?: string[]): Promise<Studio[]> {
    return this.buildQuery(selectionSet, relations ?? []).getMany();
  }

  private static buildQuery(selectionSet: SelectionSet, relations: string[]): SelectQueryBuilder<Studio> {
    const builder = this.createQueryBuilder();

    if (selectionSet.isSelected('address') || relations.includes('address')) {
      builder
        .leftJoinAndSelect(
          `${Studio.name}.address`,
          StudioAddress.name,
        );
    }

    if (selectionSet.isSelected('contacts') || relations.includes('contacts')) {
      builder
        .leftJoinAndSelect(
          `${Studio.name}.permissions`,
          PermissionStudio.name,
        )
        .leftJoinAndSelect(
          `${PermissionStudio.name}.role`,
          `${PermissionStudio.name}_${Role.name}`,
        );
    }

    if (selectionSet.isSelected('comments') || relations.includes('comments')) {
      builder
        .leftJoinAndSelect(
          `${Studio.name}.comments`,
          Comment.name,
        );
    }

    if (selectionSet.isSelected('experienceComments') || relations.includes('experienceComments')) {
      builder
        .leftJoinAndSelect(
          `${Studio.name}.experienceComments`,
          `Experience${Comment.name}`,
        );
    }

    if (selectionSet.isSelected('projects') || relations.includes('projects')) {
      builder
        .leftJoinAndSelect(
          `${Studio.name}.projects`,
          `${Project.name}`,
        )
        .leftJoinAndSelect(
          `${Project.name}.permissions`,
          `${Project.name}_${PermissionProject.name}`,
        )
        .leftJoinAndSelect(
          `${Project.name}_${PermissionProject.name}.role`,
          `${Project.name}_${PermissionProject.name}_${Role.name}`,
        ); // TO DO: SelectionSet mecanism should be reviewed to support granularity in deeper nesting levels
    }

    return builder;
  }

  @PrimaryGeneratedColumn()
  public id!: number;

  @Column()
  public employees!: number;

  @Column({ name: 'founding_date' })
  public foundingDate!: Date;

  @Column({ name: 'games_launched' })
  public gamesLaunched!: number;

  @Column({ name: 'has_f2p_experience' })
  public hasF2pExperience!: boolean;

  @Column({ name: 'has_live_ops_experience' })
  public hasLiveOpsExperience!: boolean;

  @Column({ name: 'logo_url' })
  public logoUrl!: string;

  @Column()
  public name!: string;

  @Column({ name: 'phone_number' })
  public phoneNumber!: string;

  @Column({ name: 'successful_rating' })
  public successfulRating!: number;

  @Column({ name: 'successful_title' })
  public successfulTitle!: string;

  @Column({ name: 'successful_url' })
  public successfulUrl!: string;

  @Column({ name: 'website_url' })
  public websiteUrl!: string;

  @OneToOne(() => StudioAddress, (address) => address.studio, { cascade: true })
  public address!: StudioAddress;

  @ManyToMany(() => Comment)
  @JoinTable({ name: 'studio_comment', joinColumn: { name: 'studio_id' }, inverseJoinColumn: { name: 'comment_id' } })
  public comments!: Comment[];

  @ManyToMany(() => Comment)
  @JoinTable({ name: 'studio_experience_comment', joinColumn: { name: 'studio_id' }, inverseJoinColumn: { name: 'comment_id' } })
  public experienceComments!: Comment[];

  @OneToMany(() => PermissionStudio, (permission) => permission.studio)
  public permissions!: PermissionStudio[];

  @OneToMany(() => Project, (project) => project.studio)
  public projects!: Project[];
}
