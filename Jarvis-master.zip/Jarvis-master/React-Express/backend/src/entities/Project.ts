import { BaseEntity, Column, Entity, JoinColumn, ManyToOne, OneToMany, PrimaryGeneratedColumn, SelectQueryBuilder } from 'typeorm';
import SelectionSet from '../resolvers/utils/SelectionSet';
import PermissionProject from './PermissionProject';
import Role from './Role';
import Studio from './Studio';

@Entity()
export default class Project extends BaseEntity {
  public static async findWithRelatedData(
    id: number, selectionSet: SelectionSet, relations?: string[],
  ): Promise<Project | undefined> {
    return this.buildQuery(selectionSet, relations ?? []).where(`${Project.name}.id = ${id}`).getOne();
  }

  public static async findAllWithRelatedData(
    studioName: string, selectionSet: SelectionSet, relations?: string[],
  ): Promise<Project[]> {
    return this.buildQuery(selectionSet, relations ?? [])
      .leftJoin(
        `${Project.name}.studio`,
        Studio.name,
      )
      .where(`${Studio.name}.name = "${studioName}"`)
      .getMany();
  }

  private static buildQuery(selectionSet: SelectionSet, relations: string[]): SelectQueryBuilder<Project> {
    const builder = this.createQueryBuilder();

    if (selectionSet.isSelected('contacts') || relations.includes('contacts')) {
      builder
        .leftJoinAndSelect(
          `${Project.name}.permissions`,
          PermissionProject.name,
        )
        .leftJoinAndSelect(
          `${PermissionProject.name}.role`,
          `${PermissionProject.name}_${Role.name}`,
        );
    }

    return builder;
  }

  @PrimaryGeneratedColumn()
  public id!: number;

  @ManyToOne(() => Studio, (studio) => studio.projects)
  @JoinColumn({ name: 'studio_id' })
  public studio!: Studio;

  @Column({ name: 'managed_by' })
  public managedBy!: string;

  @Column()
  public name!: string;

  @Column({ name: 'thumbnail_url' })
  public thumbnailUrl!: string;

  @OneToMany(() => PermissionProject, (permission) => permission.project)
  public permissions!: PermissionProject[];
}
