import { BaseEntity, Column, Entity, JoinColumn, OneToOne, PrimaryGeneratedColumn } from 'typeorm';
import Studio from './Studio';

@Entity()
export default class StudioAddress extends BaseEntity {
  @PrimaryGeneratedColumn()
  public id!: number;

  @OneToOne(() => Studio, (studio) => studio.address)
  @JoinColumn({ name: 'studio_id' })
  public studio!: Studio;

  @Column()
  public city!: string;

  @Column()
  public country!: string;

  @Column()
  public state!: string;

  @Column()
  public street!: string;

  @Column()
  public zipcode!: string;
}
