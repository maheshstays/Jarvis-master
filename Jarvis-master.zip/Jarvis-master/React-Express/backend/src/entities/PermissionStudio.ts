import { BaseEntity, Entity, JoinColumn, ManyToOne, OneToOne, PrimaryColumn } from 'typeorm';
import Role from './Role';
import Studio from './Studio';

@Entity()
export default class PermissionStudio extends BaseEntity {
  @PrimaryColumn({ name: 'domain_email' })
  public domainEmail!: string;

  @PrimaryColumn({ name: 'role_id' })
  public roleId!: number;

  @OneToOne(() => Role)
  @JoinColumn({ name: 'role_id' })
  public role!: Role;

  @PrimaryColumn({ name: 'studio_id' })
  public studioId!: number;

  @ManyToOne(() => Studio, (studio) => studio.permissions)
  @JoinColumn({ name: 'studio_id' })
  public studio!: Studio;
}
