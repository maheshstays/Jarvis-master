import { ISession } from 'connect-typeorm';
import { Column, Entity, PrimaryColumn } from 'typeorm';

@Entity()
export default class Session implements ISession {
  @Column({ name: 'expired_at' })
  public expiredAt: number = Date.now();

  @PrimaryColumn()
  public id: string = '';

  @Column()
  public json: string = '';
}
