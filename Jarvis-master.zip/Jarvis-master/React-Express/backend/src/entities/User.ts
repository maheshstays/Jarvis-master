import { BaseEntity, Column, Entity, PrimaryColumn } from 'typeorm';

declare global {
  namespace Express {
    // tslint:disable-next-line no-empty-interface
    interface User extends JarvisUser {}
  }
}

type JarvisUser = User;

@Entity()
export default class User extends BaseEntity {
  @PrimaryColumn()
  public id!: string;

  @Column({ name: 'domain_email' })
  public domainEmail!: string;
}
