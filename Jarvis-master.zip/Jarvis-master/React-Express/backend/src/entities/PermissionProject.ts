import { BaseEntity, Entity, JoinColumn, ManyToOne, OneToOne, PrimaryColumn } from 'typeorm';
import Project from './Project';
import Role from './Role';

@Entity()
export default class PermissionProject extends BaseEntity {
  @PrimaryColumn({ name: 'domain_email' })
  public domainEmail!: string;

  @PrimaryColumn({ name: 'role_id' })
  public roleId!: number;

  @OneToOne(() => Role)
  @JoinColumn({ name: 'role_id' })
  public role!: Role;

  @PrimaryColumn({ name: 'project_id' })
  public projectId!: number;

  @ManyToOne(() => Project, (project) => project.permissions)
  @JoinColumn({ name: 'project_id' })
  public project!: Project;
}
