import { ApolloError } from 'apollo-server-express';

export function redirect(
  { path, session = false }: { path: string, session?: boolean },
) {
  throw new ApolloError(path, 'REDIRECTION', { session });
}
