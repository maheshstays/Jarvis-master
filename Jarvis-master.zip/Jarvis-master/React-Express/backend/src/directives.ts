import { SchemaDirectiveVisitor } from 'apollo-server-express';
import args from './directives/args';
import auth from './directives/auth';
import omittableNonNull from './directives/omittableNonNull';
import uid from './directives/uid';

const schemaDirectives: { [name: string]: typeof SchemaDirectiveVisitor } = {
  args,
  auth,
  omittableNonNull,
  uid,
};

export default schemaDirectives;
