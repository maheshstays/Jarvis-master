-- // create user
-- Migration SQL that makes the change goes here.

CREATE TABLE user (
  id VARCHAR(128) NOT NULL,
  domain_email VARCHAR(128) NOT NULL UNIQUE,
  PRIMARY KEY(id),
  INDEX (domain_email)
);

-- //@UNDO
-- SQL to undo the change goes here.

DROP TABLE user;
