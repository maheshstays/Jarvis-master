-- // create studio and contacts
-- Migration SQL that makes the change goes here.

CREATE TABLE studio (
  id INT NOT NULL AUTO_INCREMENT, 
  logo_url VARCHAR(255), 
  name VARCHAR(128) NOT NULL UNIQUE, 
  website_url VARCHAR(255), 
  PRIMARY KEY(id)
);

CREATE TABLE role (
  id INT NOT NULL AUTO_INCREMENT,
  name VARCHAR(128) NOT NULL UNIQUE,
  PRIMARY KEY(id)
);

CREATE TABLE permission_studio (
  domain_email VARCHAR(128) NOT NULL,
  role_id INT NOT NULL,
  studio_id INT NOT NULL,   
  PRIMARY KEY(domain_email, role_id, studio_id),
  FOREIGN KEY(studio_id) REFERENCES studio(id) ON DELETE CASCADE,
  FOREIGN KEY(role_id) REFERENCES role(id) ON DELETE CASCADE
);

-- //@UNDO
-- SQL to undo the change goes here.

DROP TABLE permission_studio;
DROP TABLE role;
DROP TABLE studio;

