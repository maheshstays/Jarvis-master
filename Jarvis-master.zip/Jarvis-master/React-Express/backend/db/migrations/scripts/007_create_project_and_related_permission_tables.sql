-- // create project and related permission tables
-- Migration SQL that makes the change goes here.

CREATE TABLE project (
  id INT NOT NULL AUTO_INCREMENT,
  studio_id INT NOT NULL,
  managed_by VARCHAR(128),
  name VARCHAR(128) NOT NULL,
  thumbnail_url VARCHAR(512),
  UNIQUE name_per_studio (name, studio_id),
  PRIMARY KEY(id),
  FOREIGN KEY(studio_id) REFERENCES studio(id) ON DELETE CASCADE
);

CREATE TABLE permission_project (
  domain_email VARCHAR(128) NOT NULL,
  role_id INT NOT NULL,
  project_id INT NOT NULL,   
  PRIMARY KEY(domain_email, role_id, project_id),
  FOREIGN KEY(project_id) REFERENCES project(id) ON DELETE CASCADE,
  FOREIGN KEY(role_id) REFERENCES role(id) ON DELETE CASCADE
);

-- //@UNDO
-- SQL to undo the change goes here.

DROP TABLE permission_project;
DROP TABLE project;
