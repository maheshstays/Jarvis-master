-- // create session
-- Migration SQL that makes the change goes here.

CREATE TABLE session (
  id VARCHAR(255) NOT NULL,
  expired_at BIGINT NOT NULL,
  json TEXT NOT NULL,
  PRIMARY KEY(id),
  INDEX (expired_at)
);

-- //@UNDO
-- SQL to undo the change goes here.

DROP TABLE session;
