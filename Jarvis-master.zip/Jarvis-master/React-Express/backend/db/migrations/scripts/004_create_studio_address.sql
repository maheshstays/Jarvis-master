-- // create studio address
-- Migration SQL that makes the change goes here.

CREATE TABLE studio_address (
  id INT NOT NULL AUTO_INCREMENT,
  studio_id INT NOT NULL,
  city VARCHAR(128),
  country VARCHAR(128),
  state VARCHAR(128),
  street VARCHAR(128),
  zipcode VARCHAR(128),
  PRIMARY KEY(id),
  FOREIGN KEY(studio_id) REFERENCES studio(id) ON DELETE CASCADE
);

-- //@UNDO
-- SQL to undo the change goes here.

DROP TABLE studio_address;
