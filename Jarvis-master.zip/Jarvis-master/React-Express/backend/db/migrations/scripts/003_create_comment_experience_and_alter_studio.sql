-- // create comment experience and alter studio
-- Migration SQL that makes the change goes here.

CREATE TABLE comment (
  id INT NOT NULL AUTO_INCREMENT,
  author VARCHAR(128) NOT NULL,
  date DATE NOT NULL,
  text VARCHAR(512),
  PRIMARY KEY (id)
);

CREATE TABLE studio_comment (
  comment_id INT NOT NULL,
  studio_id INT NOT NULL,
  PRIMARY KEY(comment_id),
  FOREIGN KEY(studio_id) REFERENCES studio(id) ON DELETE CASCADE,
  FOREIGN KEY(comment_id) REFERENCES comment(id) ON DELETE CASCADE
);

CREATE TABLE studio_experience_comment (
  comment_id INT NOT NULL,
  studio_id INT NOT NULL,
  PRIMARY KEY(comment_id),
  FOREIGN KEY(studio_id) REFERENCES studio(id) ON DELETE CASCADE,
  FOREIGN KEY(comment_id) REFERENCES comment(id) ON DELETE CASCADE
);

ALTER TABLE studio
  ADD employees INT,
  ADD founding_date DATE,
  ADD games_launched TINYINT,
  ADD has_f2p_experience BOOLEAN NOT NULL DEFAULT FALSE,
  ADD has_live_ops_experience BOOLEAN NOT NULL DEFAULT FALSE,
  ADD phone_number VARCHAR(64),
  ADD successful_title VARCHAR(128),
  ADD successful_url VARCHAR(256),
  ADD successful_rating TINYINT;

-- //@UNDO
-- SQL to undo the change goes here.

ALTER TABLE studio
  DROP employees,
  DROP founding_date,
  DROP games_launched,
  DROP has_live_ops_experience,
  DROP has_f2p_experience,
  DROP phone_number,
  DROP successful_title,
  DROP successful_url,
  DROP successful_rating;
DROP TABLE studio_experience_comment;
DROP TABLE studio_comment;
DROP TABLE comment;
