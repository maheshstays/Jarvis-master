# JARVIS

The project is currently being ported from Google Script to React & Express and those two versions can be found in their respective folders.

## Version with React and Express

### Technology Stack

#### `Frontend`

* [React / JSX:](https://egghead.io/courses/the-beginner-s-guide-to-react) The framework used to develop our frontend.
* [Relay:](https://relay.dev/docs) The client used to call the GraphQL API of our backend.

#### `Backend`

* [Docker:](https://docs.docker.com/toolbox/toolbox_install_windows/) The development environment that encapsulates our local databases.
* [ExpressJS:](https://expressjs.com/fr/guide/routing.html) The framework used to develop our backend server.
* [ApolloServer:](https://www.apollographql.com/docs/apollo-server/getting-started/) An addition to ExpressJS to develop a GraphQL API.
* [GraphQL:](https://graphql.org/learn/) The type of API that we develop, the successor of REST.
* [TypeORM:](https://typeorm.io/#/) The tool handling the connection to the database and the composition of queries to it.

#### `Both`

* [Node / NPM:](https://nodejs.org/en/docs/) The development environment for executing our scripts and the installation of our external dependencies.
* [TypeScript:](https://www.typescriptlang.org/docs/home.html) (The language used to develop, a superset of JavaScript making the language typed) It's possible that other technologies are documented in JavaScript, but we code in TypeScript.

### Development

You must have Docker installed and configured on your machine in order to run the local development dockerized database.

#### Windows development requirements

If you're on Windows, make sure your npm commands are ran with bash. We can use Git's bash.

```shell
npm config set script-shell "C:\\Program Files\\Git\\bin\\bash.exe"
```

Idealy, this would be the same bash CLI you're using for VSCode. You can find this setting if you go in `File > Preferences > Settings` and then search for `terminal.integrated.shell.windows`. This is useful because runing commands from VSCode's command line will keep logs for errors and won't close by itself.

#### Running the backend

##### Windows backend requirements

If you're using VirtualBox as a virtualization engine for Docker (especially if you're on Windows Home), the docker's machine IP address isn't the same as your host machine localhost address. You have to port-forward every port you want to access from your host machine. For this project, you have to forward the port 33060. In VirtualBox, for the default VM, go to `Setting > Network, Advanced > Port Forwarding`. From there, add a new rule with the TCP protocol, 127.0.0.1 as a host IP, then set 33060 for both Host Port and Guest Port. You don't have to set the Guest IP or restart the VM.

___

From the `backend` folder, first create and start the local database container:

```shell
npm run db:dev
```

If it was already running, it will be stopped, then removed before being recreated and restarted again.

Then, once the health status of the database becomes `healthy`, you can run all the migrations from the `db/migrations/scripts` folder by running that command:

```shell
npm run db:migration:dev:up
```

And optionally, the data seeds by running that command:

```shell
npm run db:seed:dev
```

Finally, run the server in development mode:

```shell
npm install
npm start
```

In order to run the tests suite, execute:

```shell
npm test
```

#### Running the frontend

From the `frontend` folder, simply run:

```shell
npm install
npm start
```

In order to run the tests suite, execute:

```shell
npm test
```

### Deployments

You should never deploy the frontend or the backend manually since a CI/CD pipeline is setup to do it automatically when a new commit enters the `master` branch.

Frontend: `https://vision.ntku.net`  
Backend: `https://api.vision.ntku.net`

* GraphiQL interface at `/graphql` (GET - development only)
* GraphQL API at `/graphql` (POST)

### Database migrations

#### Windows migrations requirements

If you're using VirtualBox as a virtualization engine for Docker (especially if you're on Windows Home) and you have to mount a directory from your host machine to the VM, you will have to create a shared folder in VirtualBox to access it. For the migrations, you will need to mount the `backend/db/migrations` folder as a VirtualBox shared folder. We recommend setting it to `jarvis/migrations` in the default VM settings. Make it "Auto-mount" and "Make Permanent". You will have to restart the default VM.

___

In order to execute migrations or rollbacks, you must have Docker installed and configured on your machine.

If needed, connection informations for development or production databases are written in `backend/ormconfig.js`.

To get the actual migrations status, run either:

```shell
npm run db:migration:dev:status
npm run db:migration:prod:status
```

To migrate, run either:

```shell
// To apply all pending migrations
npm run db:migration:dev:up
npm run db:migration:prod:up

// To apply only the N (number) first pending migrations
npm run db:migration:dev:up N
npm run db:migration:prod:up N
```

To rollback, run either:

```shell
// To rollback the last migration
npm run db:migration:dev:down
npm run db:migration:prod:down

// To rollback the N (number) last migrations
npm run db:migration:dev:down N
npm run db:migration:prod:down N
```

To create a new migration, run:

```shell
npm run db:migration:new "commit message starting with a lowercase letter"
```

To apply seed/minimal data, run either:

```shell
npm run db:seed:dev
npm run db:seed:prod
```
